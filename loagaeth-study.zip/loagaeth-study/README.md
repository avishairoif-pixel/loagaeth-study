# John Dee's Liber Loagaeth: A Study of Its Formal Organisation, Transmission and the Limits of Meaning

Data, code and results for the study by Avishai Roif (2026).

The study asks what can be established about the letter tables of Liber Loagaeth (British Library, Sloane MS 3189, 1583) without assuming that they are a language or that they are meaningless. It separates three questions (is the text organised, how was it produced, does it carry meaning) and tests every measure against controls: Latin, English and consonantal Hebrew in the same format, recorded glossolalia, and computational generators calibrated without access to the test material.

## Layout

| Path | Contents |
|---|---|
| `data/loagaeth/` | Tables parsed from Peterson's edition (`grids.json` and variants), the table of dated diary anchors (`diary_anchors.csv`) |
| `data/` | Control word lists (Latin, Aramaic) and third-party material listed in `DATA_RIGHTS.md` |
| `scripts/loagaeth/` | All analyses of Loagaeth (one script per test) |
| `scripts/sigil/`, `scripts/soyga/` | Sigillum Dei Aemeth and Book of Soyga tests |
| `results/` | Outputs of every script, including `results/loagaeth_rows_raw_and_normalized.csv` |
| `review/` | Files prepared for the AI-assisted re-check of R6 and the simulations (metrics, p-value code, 200 simulations per generator, run configuration) |
| `LEDGER_he.md` | Ledger of findings (in Hebrew): every claim, its status, and the script that supports it |

## Running

All scripts are run from the repository root with Python 3 (numpy, pandas, scipy, scikit-learn, morfessor 2.0.6):

```
python3 scripts/loagaeth/markov_tables.py
```

Some control corpora are not included and are read from local paths that must be adjusted before running: Latin texts of Erasmus (The Latin Library), Hebrew Genesis and Jeremiah (Westminster Leningrad Codex, Open Scriptures morphhb), Casaubon's *True & Faithful Relation* (1659), and an OCR text of Whitby's thesis (vol. 2). The paths appear at the top of the scripts that use them.

## Reproducibility

Random seeds are fixed in every script. The ledger links each claim to its script and output. Tests specified after the data had been examined are marked as exploratory.

## Rights

Code: MIT License (see `LICENSE`). Results and the diary anchor table: CC BY 4.0. Third-party material is listed in `DATA_RIGHTS.md` and must not be redistributed without the permission of its owners.
