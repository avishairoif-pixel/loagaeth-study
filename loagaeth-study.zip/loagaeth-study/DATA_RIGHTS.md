# Third-party material

This repository is kept private. The following files contain or derive directly from material owned by others. They are included only so that the analyses can be reproduced. Before the repository is made public, they must be removed or permission must be obtained.

| File | Source | Note |
|---|---|---|
| `data/loagaeth/peterson_sl3189.txt` | Joseph H. Peterson, ed., *Liber Loagaeth* (Esoteric Archives, 1998, updated 2023) | Full text of a copyrighted edition |
| `data/loagaeth/grids.json`, `grids_u_as_a.json`, `grids_uv_merged.json`, `squares.json`, `diamonds.json`, `tilde_grids.json` | Derived from Peterson's edition | Parsed transcription |
| `results/loagaeth_rows_raw_and_normalized.csv` | Derived from Peterson's edition | Contains his raw readings |
| `data/loagaeth/sl3189_f15r-f15v_screenshot.png` | British Library, Sloane MS 3189, fols. 15r–15v | Image of a manuscript |
| `data/glossolalia/atkins2014_ipa.txt` | L. Patrick Atkins, "Phonetic Descriptions of Glossolalia" (MA thesis, George Mason University, 2014) | IPA transcriptions |
| `data/reeds_soyga.txt` | Jim Reeds, "John Dee and the Magic Tables in the Book of Soyga" | Text of a published study |
| `data/zubair/` | Files distributed with Zubair's Zenodo records | Not verified; used only for comparison |
