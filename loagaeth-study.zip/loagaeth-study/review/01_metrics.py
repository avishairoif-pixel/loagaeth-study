# קובץ: review/01_metrics.py
# קוד המדדים, מועתק כלשונו (בלי עריכה) משני קבצי המקור.
# חלק א: scripts/loagaeth/markov_tables.py, שורות 59-83
# D4, R6 (rep), MIex (mi_d), REUSE (grams), SLOPE, והפונקציה battery שמפעילה את כולם
import re, statistics
import numpy as np
AL = "abcdefghijklmnopqrstuvwxyz"; IX = {c: i for i, c in enumerate(AL)}

def side_text(R): return ''.join(re.sub(r'[^a-z]', '', r) for r in R)
def D4(t, L=400): return statistics.mean(len({t[i+j:i+j+4] for j in range(L-3)}) for i in range(0, len(t)-L+1, L))
def rep(s, n=6, back=300):
    cov = [0]*len(s)
    for i in range(n, len(s)-n+1):
        if s[i:i+n] in s[max(0, i-back):i+n-1]:
            for j in range(i, i+n): cov[j] = 1
    return sum(cov)/len(s)
def R6(t, L=400): return statistics.mean(rep(t[i:i+L]) for i in range(0, len(t)-L+1, L))
def mi_d(a, d):
    x, y = a[:-d], a[d:]; j = np.bincount(x*26 + y, minlength=676).reshape(26, 26) / len(x)
    px, py = j.sum(1), j.sum(0); nz = j > 0
    return float((j[nz] * np.log2(j[nz] / np.outer(px, py)[nz])).sum())
def MIex(t, rng):
    a = np.array([IX[c] for c in t]); out = []
    for d in range(2, 9):
        sh = [mi_d(rng.permutation(a), d) for _ in range(5)]; out.append(mi_d(a, d) - statistics.mean(sh))
    return statistics.mean(out)
def grams(t, n=5): return {t[i:i+n] for i in range(len(t)-n+1)}
def battery(sides, rng):
    T = [side_text(R) for R in sides]
    d4 = [D4(t) for t in T]
    reuse = [len(grams(T[i]) & (grams(T[i-1]) | grams(T[i-2]) | grams(T[i-3]))) / len(grams(T[i])) for i in range(3, len(T))]
    return {'D4': statistics.mean(d4), 'R6': statistics.mean(R6(t) for t in T), 'MIex': statistics.mean(MIex(t, rng) for t in T),
            'REUSE': statistics.mean(reuse), 'SLOPE': float(np.polyfit(range(len(d4)), d4, 1)[0])}

# חלק ב: scripts/loagaeth/repeat_distance_map.py, שורות 25-45
# מרחקי חזרה (profile) ואיחוד חזרות חופפות למקטעים (בתוך profile, ו-seglen)
def stream(sides):
    """letters with (side, row) labels; '?' removed"""
    L, S, R = [], [], []
    for si, side in enumerate(sides):
        for ri, r in enumerate(side):
            for c in r:
                if c.isalpha(): L.append(c); S.append(si); R.append((si, ri))
    return ''.join(L), S, R
BINS = [('same row', None), ('same side, 1-6 rows back', None), ('same side, >6 rows back', None), ('previous side', None), ('2+ sides back', None)]
def profile(sides, n=6):
    t, S, R = stream(sides); last = {}; cnt = [0]*5; covered = [0]*len(t)
    for i in range(len(t)-n+1):
        g = t[i:i+n]
        if g in last:
            j = last[g]
            if R[j] == R[i]: b = 0
            elif S[j] == S[i]: b = 1 if R[i][1] - R[j][1] <= 6 else 2
            else: b = 3 if S[i] - S[j] == 1 else 4
            cnt[b] += 1
            for k in range(i, i+n): covered[k] = 1
        last[g] = i
    segs, run = [], 0
    for c in covered + [0]:
        if c: run += 1
        elif run: segs.append(run); run = 0
    per = 1000 / len(t)
    return [c*per for c in cnt], segs, len(t)
def seglen(segs):
    return [sum(1 for s in segs if lo <= s <= hi) for lo, hi in ((6, 7), (8, 10), (11, 15), (16, 999))]
