# קובץ: review/02_pvalue.py
# מועתק כלשונו מ-scripts/loagaeth/markov_tables.py, שורות 90-101. הקטע זהה ב-markov_cache_tables.py,
# פרט ליצירת ההדמיות: שם sims = [battery(gen_block(real_sides, rng), rng) for _ in range(200)].
# הגדרה: b = מספר ההדמיות בזנב הקטן (min של ספירת >= ו-<=); p = min(1, 2(b+1)/201). רצפה: 0.00995.

for variant in ('raw', 'u restored to a'):
    real_sides = [[(r.replace('u', 'a') if (variant != 'raw' and p in REG) else r) for r in rows[p]] for p in TE]
    real = battery(real_sides, rng)
    sims = [battery([[M.gen(r, rng) for r in R] for R in real_sides], rng) for _ in range(200)]
    _tag = 'raw' if variant == 'raw' else 'u_as_a'
    pd.DataFrame([dict(sim='REAL', **real)] + [dict(sim=i+1, **x) for i, x in enumerate(sims)]).to_csv(f'results/lexicon/sims_{SCRIPT}_{_tag}.csv', index=False)
    print(f'\n=== test block, {variant} (200 synthetic sets) ===')
    print(f'{"measure":7s} {"real":>9s} {"synthetic median":>17s} {"2.5-97.5%":>22s} {"two-sided p":>12s} {"sims >= real":>13s} {"sims <= real":>13s}')
    for m in real:
        v = np.array([s[m] for s in sims]); b = min((v >= real[m]).sum(), (v <= real[m]).sum()); p = min(1.0, 2*(b + 1)/201)
        print(f'{m:7s} {real[m]:9.4f} {np.median(v):17.4f} {np.percentile(v, 2.5):10.4f}..{np.percentile(v, 97.5):9.4f} {p:12.4f} {int((v >= real[m]).sum()):13d} {int((v <= real[m]).sum()):13d}')

