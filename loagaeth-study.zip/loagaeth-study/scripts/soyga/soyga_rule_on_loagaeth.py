"""Apply Reeds' Soyga rule to the REAL Loagaeth leaves (Peterson transcription, leaves 2a-25a),
plus an upper bound: the best f fitted separately to each leaf. Run from the project root."""
import json
from collections import Counter
A = 'abcdefghiklmnopqrstuxyz'; idx = {c: i for i, c in enumerate(A)}
F = {'a':2,'b':2,'c':3,'d':5,'e':14,'f':2,'g':6,'h':5,'i':14,'k':15,'l':20,'m':22,'n':14,
     'o':8,'p':13,'q':20,'r':11,'s':8,'t':8,'u':15,'x':15,'y':15,'z':2}
D = json.load(open('data/loagaeth/grids.json'))['leaves']
ok = tot = bo = 0; per = {}
for k in [f'{n}{s}' for n in range(2, 26) for s in 'ab']:
    g = [r[:49] for r in D.get(k, []) if len(r) >= 49]
    if len(g) < 40: continue
    o = n = 0; shifts = {w: Counter() for w in A}
    for i in range(1, len(g)):
        for j in range(1, 49):
            N, W, X = g[i-1][j], g[i][j-1], g[i][j]
            if N in idx and W in idx and X in idx:
                n += 1; o += (idx[N] + F[W]) % 23 == idx[X]; shifts[W][(idx[X] - idx[N]) % 23] += 1
    ok += o; tot += n; bo += sum(max(c.values()) for c in shifts.values() if c); per[k] = o / n
print(f"Reeds' rule on {len(per)} real Loagaeth leaves: {ok}/{tot} = {ok/tot:.2%}  (chance 4.35%)")
print(f"  leaf 2a: {per['2a']:.2%}  (Zubair 2026 reports 2.99% for leaf 2a)")
print(f"  best f fitted to each leaf separately (in-sample upper bound): {bo/tot:.1%}")
