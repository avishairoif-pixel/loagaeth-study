"""Verify Reeds' (1996) Soyga rule X = N + f(W) (mod 23) directly on the Soyga tables
transcribed by Peterson in his edition of Sloane MS 3189, and compare Zubair's f-table.
f values: Reeds 1996, Table II (data/reeds_soyga.txt). Run from the project root."""
import json, csv
A = 'abcdefghiklmnopqrstuxyz'; idx = {c: i for i, c in enumerate(A)}
REEDS_F = {'a':2,'b':2,'c':3,'d':5,'e':14,'f':2,'g':6,'h':5,'i':14,'k':15,'l':20,'m':22,'n':14,
           'o':8,'p':13,'q':20,'r':11,'s':8,'t':8,'u':15,'x':15,'y':15,'z':2}
# 1) Zubair's f-table vs Reeds: f is a SHIFT (number of letters to count), so compare numbers
z = {}
for row in csv.reader(open('data/zubair/CSV1_FORMULA_DEFINITION.csv')):
    if len(row) >= 4 and len(row[0]) == 1 and row[1].isdigit(): z[row[0].lower()] = int(row[3])
same = [k for k in A if z.get(k) == REEDS_F[k]]
print(f"Zubair f-table vs Reeds Table II: {len(same)}/23 shift values identical")
# 2) the rule itself, on the Soyga tables in Peterson's transcription
S = json.load(open('data/loagaeth/grids.json'))['soyga']
for name, t in S.items():
    if not t: continue
    g = [r.lower() for r in t]; ok = tot = 0
    for i in range(1, len(g)):
        for j in range(1, min(len(g[i]), len(g[i-1]))):
            N, W, X = g[i-1][j], g[i][j-1], g[i][j]
            if N in idx and W in idx and X in idx: tot += 1; ok += (idx[N] + REEDS_F[W]) % 23 == idx[X]
    print(f"  {name:16} rule holds in {ok}/{tot} cells = {ok/tot:.1%}   (chance 4.3%)")
