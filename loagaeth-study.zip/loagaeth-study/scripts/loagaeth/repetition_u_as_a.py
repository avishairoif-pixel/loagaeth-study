"""Exact local repetition (R6, R10 as in glossolalia_compare.py) per leaf, before and after restoring u -> a
in the u-regime leaves (21a, 23a, 23b, 24a, 24b; B38). Control: the same u->a merge applied to all other
leaves (merging letters by itself raises repetition), so the effect of the restoration = delta in the regime
leaves minus delta in the control leaves. Chunks of 400 letters, rows >= 49, first 49 letters."""
import re, json, statistics, random
def rep(s, n, back=300):
    cov = [0]*len(s)
    for i in range(n, len(s)-n+1):
        if s[i:i+n] in s[max(0, i-back):i+n-1]:
            for j in range(i, i+n): cov[j] = 1
    return sum(cov)/len(s)
D = json.load(open('data/loagaeth/grids.json'))['leaves']
REG = ['21a', '23a', '23b', '24a', '24b']
def leaf(k): return ''.join(r[:49] for r in D[k] if len(r) >= 49)
keys = [k for k in D if re.fullmatch(r'(\d+)[ab]', k) and 2 <= int(k[:-1]) <= 25 and len(leaf(k)) >= 1500]
def ch(s, L=400): return [s[i:i+L] for i in range(0, len(s)-L+1, L)]
def score(s, n): c = ch(s); return statistics.mean(rep(x, n) for x in c)
rows = []
for k in keys:
    s = leaf(k); m = s.replace('u', 'a')
    rows.append((k, k in REG, score(s, 6), score(m, 6), score(s, 10), score(m, 10), s.count('u')/len(s)))
print(f'{"leaf":5s} {"regime":6s} {"R6":>6s} {"R6 u->a":>8s} {"R10":>6s} {"R10 u->a":>9s} {"u share":>8s}')
for r in rows: print(f'{r[0]:5s} {str(r[1]):6s} {r[2]:6.3f} {r[3]:8.3f} {r[4]:6.3f} {r[5]:9.3f} {r[6]:8.3f}')
def summ(sel, i, j): v = [r[j]-r[i] for r in rows if r[1] == sel]; return statistics.mean(v), v
for name, i, j in (('R6', 2, 3), ('R10', 4, 5)):
    dr, vr = summ(True, i, j); dc, vc = summ(False, i, j)
    obs = dr - dc
    # permutation: which 5 leaves are labelled 'regime'
    allv = vr + vc; random.seed(1); ge = 0; N = 10000
    for _ in range(N):
        random.shuffle(allv); ge += (statistics.mean(allv[:5]) - statistics.mean(allv[5:])) >= obs
    print(f'\n{name}: mean rise after u->a, regime leaves {dr:+.3f}, other leaves {dc:+.3f}; difference {obs:+.3f}, permutation p={(ge+1)/(N+1):.4f}')
    print(f'{name} level: regime before {statistics.mean(r[i] for r in rows if r[1]):.3f} after {statistics.mean(r[j] for r in rows if r[1]):.3f}; other leaves before {statistics.mean(r[i] for r in rows if not r[1]):.3f}')
print('\nreference (glossolalia_compare.txt): glossolalia R6 0.16-0.54, R10 0.03-0.27; Loagaeth tables median R6 0.07, R10 0.00')

# Control 2: does merging ANY letter of similar frequency into 'a' raise R6 as much? (regime leaves only)
from collections import Counter
R = ''.join(leaf(k) for k in REG); fr = Counter(R); n = len(R)
print('\nControl 2, regime leaves: R6 rise when letter x is merged into a (u = the restoration)')
base = statistics.mean(score(leaf(k), 6) for k in REG)
res = {}
for x, c in fr.most_common():
    if x == 'a' or not (0.02 <= c/n <= 0.12): continue
    res[x] = statistics.mean(score(leaf(k).replace(x, 'a'), 6) for k in REG) - base
for x, d in sorted(res.items(), key=lambda t: -t[1]): print(f'  {x} (share {fr[x]/n:.3f}): {d:+.3f}')
# Control 3: trend. R6 rises with leaf position; fit on non-regime leaves, residuals of regime leaves
import numpy as np
pos = {k: i for i, k in enumerate(keys)}
X = np.array([pos[r[0]] for r in rows if not r[1]]); Y = np.array([r[2] for r in rows if not r[1]])
b, a0 = np.polyfit(X, Y, 1); sd = np.std(Y - (a0 + b*X))
print('\nControl 3, residual from the linear trend of the other leaves (in SD units):')
for r in rows:
    if r[1]: e = a0 + b*pos[r[0]]; print(f'  {r[0]}: expected {e:.3f}; before {r[2]:.3f} ({(r[2]-e)/sd:+.1f} SD); after {r[3]:.3f} ({(r[3]-e)/sd:+.1f} SD)')
