"""Letter-frequency skew: is Loagaeth's 'a' (about 20% in leaf 1a) a glossolalia-like concentration?
(Anderson 1972 / Wolfram 1966: glossolalia uses a few sounds very often; frequencies lack the gradual decline of language.)
Measures per text: share of the most frequent letter, of the top 3, vowel share, letter entropy H1,
and the gradient of the rank-frequency curve (slope of log share vs rank, ranks 1-10)."""
import re, sys, math, json, glob
from collections import Counter
sys.path.insert(0, 'scripts/loagaeth')
exec(open('scripts/loagaeth/glossolalia_compare.py').read().split('corp = {')[0])   # G (glossolalia), leaf1, tables, T, lat
s1a = None
L = open('data/loagaeth/peterson_sl3189.txt', encoding='utf-8', errors='replace').read().split('\n')
a, b = next(i for i, l in enumerate(L) if l.startswith('[LEAF 1a]')), next(i for i, l in enumerate(L) if l.startswith('[LEAF 1b]'))
def stats(s):
    c = Counter(s); n = len(s); r = [v / n for _, v in c.most_common()]
    H = -sum(p * math.log2(p) for p in r)
    k = min(10, len(r)); xs = list(range(1, k + 1)); ys = [math.log(r[i - 1]) for i in xs]
    mx, my = sum(xs) / k, sum(ys) / k
    slope = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sum((x - mx) ** 2 for x in xs)
    top = c.most_common(3)
    return f'{top[0][0]} {100*r[0]:4.1f}%  top3 {100*sum(r[:3]):4.1f}% ({"".join(t[0] for t in top)})  vowels {100*sum(c[x] for x in "aeiouy")/n:4.1f}%  H1 {H:.2f}  slope {slope:+.3f}'
texts = {'glossolalia Charlie': G['Charlie'], 'glossolalia Jill': G['Jill'], 'glossolalia Karen': G['Karen'],
         'Loagaeth leaf 1 (calls)': ''.join(leaf1), 'Loagaeth tables 2a-25a': tables,
         'English (Casaubon)': T.eng[5000:60000], 'Latin (Erasmus)': lat[5000:60000]}
for k, s in texts.items(): print(f'{k:26s} {stats(s)}')
