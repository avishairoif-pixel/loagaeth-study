"""Row-level hidden-Markov sieve (leaf means removed, so the book-wide drift does not count).
Finds a stable background regime and brief excursions; lists every excursion. Run from project root."""
import numpy as np, csv, random
from collections import defaultdict, Counter
exec(open('scripts/loagaeth/hmm_sieve.py').read().split('# ---- real ----')[0])
def rowfeat(s):
    return np.array([[sum(LG[(a, b)] for a, b in zip(w, w[1:])) / 48, sum(c in V for c in w) / 49]
                     for w in (s[i:i+49] for i in range(0, len(s) - 48, 49))])
keys = list(streams); Xs = [rowfeat(streams[k]) for k in keys]; lens = [len(x) for x in Xs]
Xc = [x - x.mean(0) for x in Xs]; Z = np.vstack(Xc); sdv = Z.std(0); Z = Z / sdv
two = GaussianHMM(2, covariance_type='diag', n_iter=200, random_state=0, init_params='mc', params='stmc')
two.startprob_ = np.array([.5, .5]); two.transmat_ = np.array([[.9, .1], [.1, .9]]); two.fit(Z, lens)
st = two.predict(Z, lens); rare = int(np.argmin(np.bincount(st)))
m = two.means_ * sdv; v = np.sqrt(np.array([np.diag(c) for c in two.covars_])) * sdv
print(f'background state: {np.mean(st != rare):.0%} of rows; text-likeness offset {m[1-rare,0]:+.2f} (sd {v[1-rare,0]:.2f}), vowel offset {m[1-rare,1]:+.3f}')
print(f'excursion state : {np.mean(st == rare):.0%} of rows; text-likeness offset {m[rare,0]:+.2f} (sd {v[rare,0]:.2f}), vowel offset {m[rare,1]:+.3f}; mean length {1/(1-two.transmat_[rare,rare]):.1f} rows')
out = []; i = 0
for k, L in zip(keys, lens):
    s = st[i:i+L]; j = 0
    while j < L:
        if s[j] == rare:
            e = j
            while e + 1 < L and s[e+1] == rare: e += 1
            seg_rows = [streams[k][r*49:(r+1)*49] for r in range(j, e + 1)]
            out.append([k, j + 1, e + 1, e - j + 1, round(float(Xc[keys.index(k)][j:e+1, 0].mean()), 2), ' / '.join(seg_rows)])
            j = e + 1
        else: j += 1
    i += L
with open('results/lexicon/hmm_row_excursions.csv', 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['leaf', 'first_row', 'last_row', 'n_rows', 'text_likeness_offset', 'rows']); w.writerows(out)
print(f'{len(out)} excursions; by leaf: ' + ' '.join(f'{k}:{sum(1 for x in out if x[0]==k)}' for k in keys if any(x[0] == k for x in out)))
rowpos = Counter(r for x in out for r in range(x[1], x[2] + 1)); print('rows in excursions by row-position band (1-10, 11-20, ...):', [sum(rowpos[r] for r in range(b, b + 10)) for b in (1, 11, 21, 31, 41)])
print('examples (strongest offset first):')
for x in sorted(out, key=lambda x: x[4])[:5]: print(f'   {x[0]} rows {x[1]}-{x[2]} offset {x[4]:+.2f}: {x[5][:150]}')
