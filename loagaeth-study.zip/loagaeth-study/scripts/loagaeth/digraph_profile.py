"""English-type digraphs (th, ch, ph, sh, gh, wh, ck) per 1,000 letter pairs in Loagaeth (tables 2a-25a, raw, rows
read without crossing rows; leaf 1 words) against English (Casaubon 1659), Latin (Erasmus) and consonantal Hebrew
transliterated to Latin letters is not comparable and is omitted. Also the share of h that follows c, p, t or s."""
import re, sys, glob
import pandas as pd
sys.path.insert(0, 'scripts/loagaeth')
import leaf7b_transposition as T
exec(open('scripts/loagaeth/lexicon.py').read().split('# (B)')[0])
d = pd.read_csv('results/loagaeth_rows_raw_and_normalized.csv', dtype=str); s = d[d.used_in_sequence_tests == 'yes']
tab = [re.sub(r'[^a-z]', '', r) for r in s.letters_used_first_49]
lf1 = leaf1
eng = re.findall(r'[a-z]+', T._raw.lower())
lat = re.findall(r'[a-z]+', ' '.join(open(f, errors='replace').read() for f in sorted(glob.glob('/home/claude/dl_latin/ll/erasmus/*.txt'))).lower())
DG = ['th', 'ch', 'ph', 'sh', 'gh', 'wh', 'ck']
def prof(units):
    pairs = sum(max(0, len(u)-1) for u in units); out = {}
    for g in DG: out[g] = 1000 * sum(u.count(g) for u in units) / pairs
    h = sum(u.count('h') for u in units); hc = sum(len(re.findall(r'(?<=[cpts])h', u)) for u in units)
    out['h after c/p/t/s'] = hc / h if h else 0
    return out
rows = {'Loagaeth tables': tab, 'Loagaeth leaf 1': lf1, 'English (Casaubon)': eng[:200000], 'Latin (Erasmus)': lat[:200000]}
print(f'{"text":20s} ' + ' '.join(f'{g:>6s}' for g in DG) + '   share of h after c/p/t/s')
for k, u in rows.items():
    p = prof(u); print(f'{k:20s} ' + ' '.join(f'{p[g]:6.1f}' for g in DG) + f'   {p["h after c/p/t/s"]:.2f}')
