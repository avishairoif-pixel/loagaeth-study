"""Third control language, typologically different: Hebrew Genesis + Jeremiah (WLC), consonants only (no vowel points),
22 letters mapped one-to-one to a..v (final forms merged). Same pseudo-table format, chronological split and
3 random splits."""
import sys, re, random, unicodedata
sys.path.insert(0, 'scripts/loagaeth')
exec(open('scripts/loagaeth/markov_orders.py').read().split("print(f'{\"text\":44s}")[0])
raw = open('/home/claude/dl_latin/Gen.xml', encoding='utf-8').read() + open('/home/claude/dl_latin/Jer.xml', encoding='utf-8').read()
heb = ''.join(''.join(c for c in unicodedata.normalize('NFD', w) if 'א' <= c <= 'ת') for w in re.findall(r'<w [^>]*>([^<]+)</w>', raw))
fin = {'ך': 'כ', 'ם': 'מ', 'ן': 'נ', 'ף': 'פ', 'ץ': 'צ'}; heb = ''.join(fin.get(c, c) for c in heb)
abc = sorted(set(heb)); mp = {c: 'abcdefghijklmnopqrstuvwxyz'[i] for i, c in enumerate(abc)}
t = ''.join(mp[c] for c in heb); print(len(abc), 'letters;', len(t), 'letters of text; need', sum(49*len(L0[p]) for p in pages))
assert len(t) >= sum(49*len(L0[p]) for p in pages), 'text too short: no duplication allowed'
R = cut(t)
for label, split in [('chronological', (TR, DEV, TE))] + [(f'random {sd}', None) for sd in (1, 2, 3)]:
    if split is None:
        ps = pages[:]; random.Random(int(label[-1])).shuffle(ps); split = (ps[:27], ps[27:36], ps[36:])
    tr = [r for p in split[0] for r in R[p]]; dv = [r for p in split[1] for r in R[p]]; te = [r for p in split[2] for r in R[p]]
    H = []
    for k in range(6):
        a = min((CM(k, a).fit(tr).bits(dv), a) for a in (0.1, 1.0, 10.0))[1]; H.append(CM(k, a).fit(tr + dv).bits(te))
    print(f'Hebrew Gen+Jer, {label:14s} ' + ' '.join(f'{h:6.3f}' for h in H) + f'   best k {H.index(min(H))}')
