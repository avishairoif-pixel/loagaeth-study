"""Register Peterson's transcription of leaf 7b onto a low-resolution image of Sloane 3189 f.15v,
using letter shapes that survive at ~15 px per cell: ascenders (b d f h k l) put ink high in the cell,
descenders (g p q y) put ink low. Fit the grid (origin, cell size) that maximises the correlation.
Then: is the match in rows 16-21 (the English-profile block) as good as in the other rows?"""
import re, sys, numpy as np
from PIL import Image
IMG = sys.argv[1] if len(sys.argv) > 1 else '/mnt/user-data/uploads/77da4440-image.png'
X0, X1 = (990, 1735)
L = open('/home/claude/dee_research/data/loagaeth/peterson_sl3189.txt', encoding='utf-8', errors='replace').read().split('\n')
start = next(i for i, l in enumerate(L) if l.startswith('[LEAF 7b]')) + 3
ROWS = [re.sub(r'[^a-z?]', '', L[start + r].lower()) for r in range(49)]
assert ROWS[15].startswith('adramvahofat'), ROWS[15][:20]
ASC, DESC = set('bdfhkl'), set('gpqy')
def pred(ch): return 1.0 if ch in ASC else (-1.0 if ch in DESC else 0.0)
im = 255 - np.array(Image.open(IMG).convert('L')).astype(float)
page = im[:, X0:X1]
def cellfeat(x0, y0, dx, dy, rot=0.0):
    F = np.full((49, 49), np.nan)
    for r in range(49):
        for c in range(49):
            cx = x0 + (c + .5) * dx; cy = y0 + (r + .5) * dy + rot * (c - 24) * dx
            ya, yb = int(cy - dy * .75), int(cy + dy * .75); xa, xb = int(cx - dx * .3), int(cx + dx * .3)
            if ya < 0 or yb > page.shape[0] or xa < 0 or xb > page.shape[1]: continue
            blk = page[ya:yb, xa:xb]; h = blk.shape[0]
            top, bot = blk[:h // 3].mean(), blk[-h // 3:].mean()
            F[r, c] = top - bot
    return F
def corr(F, rows=range(49)):
    a, b = [], []
    for r in rows:
        if len(ROWS[r]) != 49: continue
        for c in range(49):
            if not np.isnan(F[r, c]): a.append(F[r, c] - np.nanmean(F[r])); b.append(pred(ROWS[r][c]))
    return np.corrcoef(a, b)[0, 1], len(a)
if __name__ == '__main__':
    best = (-1,)
    for dx in np.arange(14.4, 15.4, .1):
        for dy in np.arange(14.6, 15.6, .1):
            for x0 in range(0, 16, 2):
                for y0 in range(0, 16, 2):
                    F = cellfeat(x0, y0, dx, dy); r, n = corr(F)
                    if r > best[0]: best = (r, n, x0, y0, dx, dy)
    r, n, x0, y0, dx, dy = best
    for rot in (-.006, -.003, 0, .003, .006):
        F = cellfeat(x0, y0, dx, dy, rot); rr, _ = corr(F)
        if rr > r: r, best = rr, (rr, n, x0, y0, dx, dy, rot)
    print('best grid:', best)
    rot = best[6] if len(best) > 6 else 0
    F = cellfeat(x0, y0, dx, dy, rot)
    # null: same grid, transcription rows shifted against the image
    print(f'overall correlation {corr(F)[0]:.3f} (n={corr(F)[1]})')
    np.save('/home/claude/7b_F.npy', F)
    print('per-row correlation (transcription row r vs image row r) and vs neighbours r-1, r+1:')
    for r in range(49):
        if len(ROWS[r]) != 49: print(f'{r+1:2d}  (length {len(ROWS[r])}, skipped)'); continue
        def rc(img_r):
            if not 0 <= img_r < 49: return float('nan')
            f = F[img_r] - np.nanmean(F[img_r]); p = np.array([pred(ch) for ch in ROWS[r]]); ok = ~np.isnan(f)
            return np.corrcoef(f[ok], p[ok])[0, 1]
        tag = ' <- block' if 15 <= r <= 20 else ''
        print(f'{r+1:2d}  same {rc(r):+.2f}   up {rc(r-1):+.2f}   down {rc(r+1):+.2f}   {ROWS[r][:20]}{tag}')
