"""THE MONAS AS A KEY: a reading rule defined BEFORE running, applied to every square leaf of Loagaeth.

Rule (fixed in advance; written before any result was seen):
  The Monas glyph of 1564 is laid on the 49x49 table, centred on column 25, scaled to 80% of the table height
  so that it can also be moved (for the control). Its parts are read in Dee's order of construction, top to bottom:
    1. the Moon: a bowl-shaped half circle (horns up) on top, read left to right
    2. the Sun: the full circle, read clockwise from its top
    3. the point at the centre of the Sun (one letter)
    4. the cross: the vertical bar top to bottom, then the horizontal bar left to right
    5. the sign of Aries: two half circles (arched) at the bottom, left one then right one, each left to right
  The letters under the glyph, in that order, are the reading. Eight orientations (4 rotations x mirror),
  each read forward and backward = 16 readings per leaf.
What would count as a message (three scores, all fixed in advance):
  S1 English: mean quadgram log-probability (Casaubon 1659, clean text)
  S2 Enochian of the Claves: hits of Claves words (>=4 letters, Casaubon's syllable-confirmed list) per 100 letters
  S3 the 'Adamic' words of leaf 1 (>=4 letters) per 100 letters
Controls:
  C1 position: the same glyph moved off-centre (every offset within +-4 cells, 80 positions) on the SAME leaf;
     the canonical placement must rank at the top, consistently over the leaves (mean percentile, sign test).
  C2 positive: an English sentence written along the canonical path into one leaf must be found (rank 1).
Run from project root."""
import re, sys, json, math, random, statistics
from collections import Counter
sys.path.insert(0, 'scripts/loagaeth')
import leaf7b_transposition as T
D = json.load(open('data/loagaeth/grids.json'))
def num(k): m = re.match(r'(\d+)([ab])$', k); return int(m.group(1)) * 2 + (m.group(2) == 'b') if m else 999
leaves = {k: [r[:49] for r in v if len(r) >= 49] for k, v in D['leaves'].items() if 4 <= num(k) <= num('25a')}
leaves = {k: v[:49] for k, v in leaves.items() if len(v) >= 49}
print(f'square leaves with a full 49x49 table: {len(leaves)}')
# ---------------- the glyph ----------------
S = 0.8
def arc(cy, cx, r, a0, a1, step=2.0):
    pts, a = [], a0
    while (a <= a1 if a1 > a0 else a >= a1):
        t = math.radians(a); pts.append((cy - r * math.sin(t), cx + r * math.cos(t))); a += step if a1 > a0 else -step
    return pts
def line(p, q, n=60):
    return [(p[0] + (q[0] - p[0]) * i / n, p[1] + (q[1] - p[1]) * i / n) for i in range(n + 1)]
def glyph():
    # unscaled design on a 49-high canvas, centre column 24, rows 0..48 (y down)
    parts = []
    parts.append(arc(6, 24, 6, 180, 360))            # Moon: lower half of a circle = bowl, left -> right
    parts.append(arc(19, 24, 7, 90, -270))           # Sun: full circle clockwise from the top
    parts.append([(19, 24)])                          # the point
    parts.append(line((26, 24), (40, 24)) + line((32, 17), (32, 31)))   # the cross
    parts.append(arc(45, 20, 3.5, 180, 0) + arc(45, 28, 3.5, 180, 0))  # Aries: two arches, left -> right
    pts = [p for part in parts for p in part]
    # scale about the table centre
    return [(24 + (y - 24) * S, 24 + (x - 24) * S) for y, x in pts]
BASE = glyph()
def cells(pts, dy=0, dx=0, rot=0, mirror=False):
    out = []
    for y, x in pts:
        yy, xx = y - 24, x - 24
        if mirror: xx = -xx
        for _ in range(rot): yy, xx = xx, -yy
        c = (int(round(yy + 24 + dy)), int(round(xx + 24 + dx)))
        if 0 <= c[0] < 49 and 0 <= c[1] < 49 and (not out or out[-1] != c) and c not in out: out.append(c)
    return out
ORIENT = [(r, m) for r in range(4) for m in (False, True)]
# ---------------- scores ----------------
voc = set()
for m in re.finditer(r'\b([A-Z]{3,})\b', T._raw):
    w = m.group(1).lower(); tail = T._raw[m.end():m.end() + 120]
    if w in re.sub(r'\s+', '', re.sub(r'[^A-Za-z ]', ' ', tail)).lower() and not re.fullmatch(r'[ivxlc]+', w):
        voc.add(w.replace('u', 'v'))
CLAVES = [w for w in voc if len(w) >= 4]
exec(open('scripts/loagaeth/lexicon.py').read().split('# (B)')[0])
ADAM = [w for w in set(leaf1) if len(w) >= 4]
def s_eng(t): return T.score(t.replace('v', 'u')) if len(t) > 4 else -9
def hits(t, words): return 100 * sum(t.count(w) for w in words) / max(len(t), 1)
SCORES = {'S1 English': s_eng, 'S2 Claves words': lambda t: hits(t, CLAVES), 'S3 leaf-1 words': lambda t: hits(t, ADAM)}
def reading(G, path): return ''.join(G[y][x] for y, x in path)
def best(G, dy, dx, f):
    v = -1e9
    for r, m in ORIENT:
        t = reading(G, cells(BASE, dy, dx, r, m)); v = max(v, f(t), f(t[::-1]))
    return v
OFFS = [(dy, dx) for dy in range(-4, 5) for dx in range(-4, 5) if (dy, dx) != (0, 0)]
def percentile(G, f):
    c = best(G, 0, 0, f); others = [best(G, dy, dx, f) for dy, dx in OFFS]
    return (sum(o < c for o in others) + 0.5 * sum(o == c for o in others)) / len(others), c   # mid-rank for ties
if __name__ == '__main__':
    path0 = cells(BASE)
    print(f'canonical reading length: {len(path0)} letters')
    # positive control C2
    k0 = sorted(leaves)[5]; G = [list(r) for r in leaves[k0]]
    msg = re.sub(r'[^a-z]', '', T._raw.lower()[60000:60000 + 400])[:len(path0)]
    for (y, x), ch in zip(path0, msg): G[y][x] = ch
    G = [''.join(r) for r in G]
    p, c = percentile(G, SCORES['S1 English'])
    print(f'POSITIVE CONTROL (English planted on the canonical path in leaf {k0}): S1 percentile {p:.2f}, score {c:.2f}\n   {reading(G, path0)[:80]}')
    for name, f in SCORES.items():
        ps = []; tops = []
        for k, G in leaves.items():
            p, c = percentile(G, f); ps.append(p); tops.append((c, k))
        above = sum(p > .5 for p in ps); n = len(ps)
        # two-sided sign test vs 0.5
        from math import comb
        tail = sum(comb(n, i) for i in range(max(above, n - above), n + 1)) / 2 ** n
        print(f'\n{name}: mean percentile of the canonical placement {statistics.mean(ps):.2f} (0.5 = no better than a moved glyph); '
              f'leaves above median {above}/{n}, sign test p={min(1, 2 * tail):.3f}; top-1 in {sum(p == 1 for p in ps)} leaves (chance {n/81:.1f})')
        c, k = max(tops); print(f'   best canonical reading: leaf {k}, score {c:.2f}')
    k = sorted(leaves)[10]; G = leaves[k]
    print(f'\nexample canonical reading, leaf {k}:\n   {reading(G, path0)}')
