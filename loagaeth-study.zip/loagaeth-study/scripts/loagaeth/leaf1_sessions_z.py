"""Word-order structure (window z, w=10) of leaf 1 by dictation session, blocks of 340 words.
Sessions from leaf1_dating.py (words located in Whitby vol. 2). Method (diary, Apr 2, p. 272 [71b]): rows 1-2
were taken letter by letter; from the third row on Kelley 'can read all, now, most perfectly' and reads words
(Dee writes); 1b (from word 2345) is written by Kelley himself on Apr 6 afternoon.
Controls: 20 samples of 340 words of Latin, English, Hebrew; and 20 texts from a letter 3-gram model (space =
symbol) trained on the whole of leaf 1 (no lexicon, no syntax)."""
import sys, random, statistics
sys.path.insert(0, 'scripts/loagaeth')
exec(open('scripts/loagaeth/generator_ladder2.py').read().split('rng = random.Random(21)')[0])
rng = random.Random(91); n = 340
blocks = [('Apr 2, A', 122), ('Apr 2, B', 462), ('Apr 2, C', 802), ('Apr 2, D', 1142), ('Apr 2, E', 1318), ('Apr 5', 1659),
          ('Apr 6 morning', 2005), ('1b Apr 6 pm, A', 2345), ('1b, B', 2685), ('1b, C', 3025)]
def z(s): return statistics.mean(zwin(s, 10, rng, 40) for _ in range(3))
print(f'blocks of {n} words, window z (mean of 3 runs of 40 shuffles)')
for name, st in blocks: print(f'  {name:16s} words {st}-{st+n}: z = {z(LOA[st:st+n]):5.1f}')
for name, corp in (('Latin', lat), ('English', eng), ('Hebrew', heb)):
    v = sorted(z(corp[x:x+n]) for x in (rng.randrange(0, len(corp)-n) for _ in range(20)))
    print(f'  {name:16s} 20 samples: median {statistics.median(v):.1f}, range {v[0]:.1f}..{v[-1]:.1f}')
v = sorted(z(gen(LOA, 3, n, rng)) for _ in range(20))
print(f'  {"letter 3-gram":16s} 20 texts:   median {statistics.median(v):.1f}, range {v[0]:.1f}..{v[-1]:.1f}')
