"""Does Loagaeth go BEYOND recorded glossolalia on defined dimensions? (rules fixed before running)
Over the production sequence (square leaves 2a-25a, written in about ten days, April 1583):
  D1 vocabulary accumulation: share of a leaf's 5-letter sequences already used in EARLIER leaves,
     minus the same share for the leaf's letters shuffled (excess reuse). Rising excess = a vocabulary that builds up.
  D2 rule stabilisation: Jensen-Shannon divergence between the letter-transition tables (bigram -> next letter)
     of consecutive leaves. Falling divergence = the 'rules' settle. Trend tested against random orderings of the leaves.
Against glossolalia (Atkins 2014) and written languages, on chunks of 400 letters:
  D3 unit diversity: distinct 4-letter sequences per 400 letters.
  D4 longer-range dependency: mutual information between letters 2-8 positions apart, minus a shuffled baseline.
Run from project root."""
import re, sys, json, math, random, statistics
from collections import Counter
sys.path.insert(0, 'scripts/loagaeth')
exec(open('scripts/loagaeth/glossolalia_compare.py').read().split('corp = {')[0])   # G, leaf1, tables, T, lat
D = json.load(open('data/loagaeth/grids.json'))
def num(k): m = re.fullmatch(r'(\d+)([ab])', k); return int(m.group(1)) * 2 + (m.group(2) == 'b') if m else 999
keys = sorted([k for k in D['leaves'] if num(k) <= num('25a') and num(k) >= num('2a')], key=num)
LV = {k: ''.join(r[:49] for r in D['leaves'][k] if len(r) >= 49) for k in keys}
LV = {k: v for k, v in LV.items() if len(v) >= 1500}
keys = [k for k in keys if k in LV]
rng = random.Random(4)
# D1
seen = set(); d1 = []
for k in keys:
    s = LV[k]; g = [s[i:i+5] for i in range(len(s) - 4)]
    real = sum(x in seen for x in g) / len(g)
    sh = ''.join(rng.sample(s, len(s))); gs = [sh[i:i+5] for i in range(len(sh) - 4)]
    base = sum(x in seen for x in gs) / len(gs)
    if seen: d1.append((k, real, base, real - base))
    seen |= set(g)
def corr(xs, ys):
    mx, my = statistics.mean(xs), statistics.mean(ys)
    return sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / math.sqrt(sum((x - mx) ** 2 for x in xs) * sum((y - my) ** 2 for y in ys))
print('D1 vocabulary accumulation (share of 5-letter sequences already used in earlier leaves; real - shuffled):')
for k, r, b, e in d1[::4]: print(f'   {k:>4}: real {r:.3f}  shuffled {b:.3f}  excess {e:+.3f}')
ex = [e for *_, e in d1]; t = list(range(len(ex)))
null = []
for _ in range(2000):
    p = ex[:]; rng.shuffle(p); null.append(corr(t, p))
r1 = corr(t, ex); print(f'   trend of the excess over the leaves: r={r1:+.2f}; random order 95% [{sorted(null)[50]:+.2f}, {sorted(null)[1950]:+.2f}]')
# D1b (correction): a growing 'already seen' set makes reuse rise for ANY text, so the trend above is confounded.
# Fair version: reuse against a FIXED memory (the previous 3 leaves only); null = the same on random leaf orders.
def d1b(order):
    out = []
    for i in range(3, len(order)):
        mem = set(); [mem.update(LV[k][j:j+5] for j in range(len(LV[k]) - 4)) for k in order[i-3:i]]
        s = LV[order[i]]; g = [s[j:j+5] for j in range(len(s) - 4)]
        out.append(sum(x in mem for x in g) / len(g))
    return out
real_b = d1b(keys); tb = list(range(len(real_b))); rb = corr(tb, real_b)
nb = sorted(corr(tb, d1b(rng.sample(keys, len(keys)))) for _ in range(300))
print(f'\nD1b fixed memory (previous 3 leaves): reuse first third {statistics.mean(real_b[:len(real_b)//3]):.3f}, last third {statistics.mean(real_b[-len(real_b)//3:]):.3f}')
print(f'   trend r={rb:+.2f}; random leaf orders 95% [{nb[7]:+.2f}, {nb[292]:+.2f}]')
# D2
def trans(s):
    c = {}
    for i in range(len(s) - 2):
        c.setdefault(s[i:i+2], Counter())[s[i+2]] += 1
    return c
def jsd(a, b):
    out, w = 0, 0
    for ctx in set(a) & set(b):
        p, q = a[ctx], b[ctx]; n1, n2 = sum(p.values()), sum(q.values())
        if n1 < 15 or n2 < 15: continue
        keys2 = set(p) | set(q); m = {x: (p[x] / n1 + q[x] / n2) / 2 for x in keys2}
        kl = lambda P, n: sum(P[x] / n * math.log2((P[x] / n) / m[x]) for x in keys2 if P[x])
        out += (kl(p, n1) + kl(q, n2)) / 2 * (n1 + n2); w += n1 + n2
    return out / w
Tr = [trans(LV[k]) for k in keys]
d2 = [jsd(Tr[i], Tr[i + 1]) for i in range(len(keys) - 1)]
t2 = list(range(len(d2))); r2 = corr(t2, d2)
null2 = []
for _ in range(500):
    order = keys[:]; rng.shuffle(order); Tp = [trans(LV[k]) for k in order]
    null2.append(corr(t2, [jsd(Tp[i], Tp[i + 1]) for i in range(len(order) - 1)]))
print(f'\nD2 rule stabilisation: divergence between consecutive leaves, first third {statistics.mean(d2[:len(d2)//3]):.3f}, last third {statistics.mean(d2[-len(d2)//3:]):.3f}')
print(f'   trend r={r2:+.2f} (negative = settling); random leaf orders 95% [{sorted(null2)[12]:+.2f}, {sorted(null2)[487]:+.2f}]')
# D3, D4
def div4(s): return len({s[i:i+4] for i in range(len(s) - 3)})
def mi_d(s, d):
    pairs = Counter(zip(s, s[d:])); n = len(s) - d; u = Counter(s)
    N = len(s); return sum(c / n * math.log2((c / n) / ((u[a] / N) * (u[b] / N))) for (a, b), c in pairs.items())
def lr(s):
    real = statistics.mean(mi_d(s, d) for d in range(2, 9))
    sh = [statistics.mean(mi_d(''.join(rng.sample(s, len(s))), d) for d in range(2, 9)) for _ in range(20)]
    return real - statistics.mean(sh)
corp = {'glossolalia Charlie': [G['Charlie'][:400]], 'glossolalia Jill': [G['Jill'][:400]], 'glossolalia Karen': [G['Karen'][:400]],
        'Loagaeth leaf 1': chunks(''.join(leaf1), k=20), 'Loagaeth tables': chunks(tables, k=20),
        'English': chunks(T.eng[5000:200000], k=20), 'Latin': chunks(lat[5000:200000], k=20)}
print(f'\n{"text (400 letters)":22s} {"D3 distinct 4-grams":>20s} {"D4 MI d=2..8 excess (bits)":>28s}')
for k, cs in corp.items():
    a = [div4(c) for c in cs]; b = [lr(c) for c in cs]
    f = lambda v, p: (f'{statistics.median(v):{p}}' if len(v) == 1 else f'{statistics.median(v):{p}} [{min(v):{p}}-{max(v):{p}}]')
    print(f'{k:22s} {f(a, ".0f"):>20s} {f(b, ".3f"):>28s}')

# D5: is the rise in reuse just more repetition? Diversity and local repetition per leaf over time.
def rep6(s, back=300):
    cov = [0] * len(s)
    for i in range(6, len(s) - 5):
        if s[i:i+6] in s[max(0, i - back):i + 5]:
            for j in range(i, i + 6): cov[j] = 1
    return sum(cov) / len(s)
dv = [statistics.mean(div4(LV[k][i:i+400]) for i in range(0, len(LV[k]) - 400, 400)) for k in keys]
rp = [statistics.mean(rep6(LV[k][i:i+400]) for i in range(0, len(LV[k]) - 400, 400)) for k in keys]
tt = list(range(len(keys)))
print(f'\nD5 over the leaves: distinct 4-grams per 400 letters first third {statistics.mean(dv[:len(dv)//3]):.0f}, last third {statistics.mean(dv[-len(dv)//3:]):.0f} (trend r={corr(tt, dv):+.2f});'
      f' local repetition first third {statistics.mean(rp[:len(rp)//3]):.3f}, last third {statistics.mean(rp[-len(rp)//3:]):.3f} (trend r={corr(tt, rp):+.2f})')

# D1c: same as D1b with the opportunity to match held constant: every leaf in memory and every target leaf
# is cut to the same length (the shortest leaf), so the number of 5-letter sequences compared never changes.
Lmin = min(len(v) for v in LV.values())
def d1c(order):
    out = []
    for i in range(3, len(order)):
        mem = set(); [mem.update(LV[k][:Lmin][j:j+5] for j in range(Lmin - 4)) for k in order[i-3:i]]
        s = LV[order[i]][:Lmin]; g = [s[j:j+5] for j in range(Lmin - 4)]
        out.append(sum(x in mem for x in g) / len(g))
    return out
lens = [len(LV[k]) for k in keys]
real_c = d1c(keys); tc = list(range(len(real_c)))
nc = sorted(corr(tc, d1c(rng.sample(keys, len(keys)))) for _ in range(300))
print(f'\nD1c equal length ({Lmin} letters per leaf): reuse first third {statistics.mean(real_c[:len(real_c)//3]):.3f}, last third {statistics.mean(real_c[-len(real_c)//3:]):.3f};'
      f' trend r={corr(tc, real_c):+.2f}; random orders 95% [{nc[7]:+.2f}, {nc[292]:+.2f}]; leaf length vs position r={corr(list(range(len(lens))), lens):+.2f}')
