"""Is the rise in text-likeness across leaves 2a-25a a STEP (a change of recording method) or GRADUAL
(growing fluency)? And is there a warm-up inside each leaf?
Dated anchors from Dee's diary (Sloane 3188, Whitby's transcription, w2.txt):
  6 Apr 1583: second page of leaf 1 finished; while writing, Kelley 'understood the language ... as if it had byn english',
              and it was taken away when he finished. From here Kelley writes the tables himself (Sl. 3189 begins in leaf 1b).
  15 Apr: Kelley writing the 18th leaf; he read a parcel 'playnely alowde to him self' and spirits appeared, saying he called them.
  18 Apr: 'As E K cam to write out the Tables according as he was wont: and to haue the letters appearing in the ayre';
          24 leaves written; the work stops (black cloud).
So leaves 2-24 were written by one method (Kelley, letters seen in the air) in about ten days.
Run from the project root."""
import numpy as np, random
src = open('scripts/loagaeth/episode_sieve.py').read().split('def lag1')[0]
exec(src)                                     # rows, F (per-row features), LEAVES
keys = [k for k in LEAVES if k in F]
pos = {k: i for i, k in enumerate(keys)}
x = np.array([pos[k] for k in keys for _ in F[k]]); y = np.concatenate([F[k][:, 0] for k in keys])
lm = np.array([F[k][:, 0].mean() for k in keys])
print('leaf  mean text-likeness (bits/letter gained by bigrams)')
for k, m in zip(keys, lm): print(f'{k:>4}  {m:.3f}  ' + '#' * int(m * 30))
def rss(pred): return ((lm - pred) ** 2).sum()
n = len(lm); t = np.arange(n)
# models on leaf means: constant, linear, single step (best break), step + linear
b = np.polyfit(t, lm, 1); r_lin = rss(np.polyval(b, t))
best = min((rss(np.where(t < c, lm[:c].mean(), lm[c:].mean())), c) for c in range(3, n - 3))
r_step, cbest = best
bic = lambda r, p: n * np.log(r / n) + p * np.log(n)
print(f'\nleaf-mean models (n={n}): constant BIC {bic(rss(lm.mean()),1):.1f} | linear {bic(r_lin,2):.1f} | single step at {keys[cbest]} {bic(r_step,3):.1f}')
# residual check: after the best step, is there still a trend inside each part?
for part, sl in (('before step', slice(0, cbest)), ('after step', slice(cbest, n))):
    tt, yy = t[sl], lm[sl]
    if len(tt) > 3:
        r = np.corrcoef(tt, yy)[0, 1]; print(f'  trend inside {part}: r={r:+.2f} over {len(tt)} pages')
# warm-up inside a leaf: does text-likeness rise from the first rows to the last rows of a page?
def within(Fs):
    rs = []
    for M in Fs:
        g = M[:, 0]; rs.append(np.corrcoef(np.arange(len(g)), g)[0, 1])
    return np.mean(rs)
real = within([F[k] for k in keys])
rng = random.Random(3); null = []
for _ in range(2000):
    null.append(within([F[k][rng.sample(range(len(F[k])), len(F[k]))] for k in keys]))
null = np.array(null)
print(f'\nwarm-up inside a page: mean corr(row number, text-likeness) = {real:+.3f}; shuffled rows {null.mean():+.3f} (sd {null.std():.3f}), p(one-sided) = {(null >= real).mean():.4f}')
first, last = np.mean([F[k][:10, 0].mean() for k in keys]), np.mean([F[k][-10:, 0].mean() for k in keys])
print(f'first 10 rows of a page {first:.3f} vs last 10 rows {last:.3f}')
