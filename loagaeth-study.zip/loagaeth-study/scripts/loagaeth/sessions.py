"""Sessions: do the leaves fall into blocks with their own letter profile, and where are the boundaries?
Data: every leaf 2a-25a, all letters of all its rows (u kept as transcribed: it is one of the possible session marks).
Method (binary segmentation, rule fixed in advance):
  cost of a block = multinomial negative log-likelihood of its letter counts under the block's pooled profile;
  gain of a split = cost(block) - cost(left) - cost(right);
  a split is accepted only if its gain exceeds the 95th percentile of the best-split gain over 200 random orderings
  of the leaves inside that block (so a boundary must be stronger than any that order-free data would produce).
For each block: the letters that set it apart from the rest (percentage points)."""
import json, re, math, random
from collections import Counter
D = json.load(open('data/loagaeth/grids.json'))
def num(k): m = re.fullmatch(r'(\d+)([ab])', k); return int(m.group(1)) * 2 + (m.group(2) == 'b') if m else 999
ks = sorted([k for k in D['leaves'] if num('2a') <= num(k) <= num('25a')], key=num)
C = {k: Counter(''.join(r.replace('?', '') for r in D['leaves'][k])) for k in ks}
ks = [k for k in ks if sum(C[k].values()) >= 600]
AB = sorted(set().union(*[set(c) for c in C.values()]))
def nll(block):
    tot = Counter(); [tot.update(C[k]) for k in block]; N = sum(tot.values())
    return -sum(n * math.log(n / N) for n in tot.values() if n)
def best_split(block):
    base = nll(block); best = (0, None)
    for i in range(1, len(block)):
        g = base - nll(block[:i]) - nll(block[i:])
        if g > best[0]: best = (g, i)
    return best
rng = random.Random(1)
def segment(block, depth=0, out=None):
    if out is None: out = []
    if len(block) < 4: out.append(block); return out
    g, i = best_split(block)
    null = sorted(best_split(rng.sample(block, len(block)))[0] for _ in range(200))
    thr = null[189]
    if g > thr:
        print(f'{"   "*depth}split {block[0]}-{block[-1]} at {block[i-1]} | {block[i]}: gain {g:.1f} (random-order 95th pct {thr:.1f})')
        segment(block[:i], depth + 1, out); segment(block[i:], depth + 1, out)
    else: out.append(block)
    return out
blocks = segment(ks)
tot = Counter(); [tot.update(C[k]) for k in ks]; NT = sum(tot.values())
print('\nBLOCKS and what sets each apart (percentage points vs the whole range, |d| >= 1.0):')
for b in blocks:
    c = Counter(); [c.update(C[k]) for k in b]; n = sum(c.values())
    d = sorted(((100 * (c[x] / n - tot[x] / NT), x) for x in AB), key=lambda z: -abs(z[0]))
    print(f'   {b[0]:>4}-{b[-1]:<4} ({len(b):2d} sides, {n:6d} letters): ' + ', '.join(f'{x} {v:+.1f}' for v, x in d if abs(v) >= 1.0))
print('\nDiary anchors (Whitby, Sl. 3188): 6 Apr leaf 1 finished; 15 Apr Kelley writing the 18th leaf; 18 Apr 24 leaves written, work stops.')
