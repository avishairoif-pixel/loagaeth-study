"""Specificity test on the TABLES (protocol proposed by the outside reviewer, 31 Oct 2026; exploratory, since the
text has already been examined). Character Markov model (orders 0-3, interpolated smoothing with alpha), history
reset at each row start and at '?'. Chronological split of the 45 sides: 27 train, 9 dev (choice of order and
alpha by dev bits/letter only), 9 test (21a-25a). The frozen model is refit on train+dev and generates 200
synthetic test sets with the real row templates ('?' positions kept, no real letters used as seed).
Measures, same code for real and synthetic:
  D4    distinct 4-grams per 400-letter window (mean over windows, per side, then mean over sides)
  R6    share of letters covered by a 6-gram already seen in the previous 300 letters (400-letter chunks)
  MIex  letter MI at distances 2..8 minus mean MI of 5 letter shuffles of the same side (mean over d and sides)
  REUSE share of a side's distinct 5-grams already present in the previous 3 sides (sides 4-9 of the test block)
  SLOPE slope of D4 over the 9 test sides
The test block contains the u-for-a leaves (21a, 23a-24b; B38), which the training material lacks; run twice:
raw, and with u restored to a in those leaves."""
import math, re, sys, statistics
SCRIPT = "markov_tables"
import numpy as np, pandas as pd
df = pd.read_csv('results/loagaeth_rows_raw_and_normalized.csv')
sel = df[df.used_in_sequence_tests == 'yes']
pages = list(dict.fromkeys(sel.leaf))
TR, DEV, TE = pages[:27], pages[27:36], pages[36:]
REG = {'21a', '23a', '23b', '24a', '24b'}
rows = {p: sel[sel.leaf == p].letters_used_first_49.tolist() for p in pages}
AL = 'abcdefghijklmnopqrstuvwxyz'; IX = {c: i for i, c in enumerate(AL)}
class CM:
    def __init__(s, k, a): s.k, s.a = k, a
    def fit(s, R):
        from collections import Counter, defaultdict
        s.C = [defaultdict(Counter) for _ in range(s.k+1)]; s.cache = {}
        for r in R:
            for seg in re.findall(r'[a-z]+', r):
                h = ''
                for c in seg:
                    for j in range(0, min(s.k, len(h))+1): s.C[j][h[len(h)-j:] if j else ''][c] += 1
                    h = (h + c)[-s.k:] if s.k else ''
        return s
    def P(s, h):
        h = h[-s.k:] if s.k else ''
        if h in s.cache: return s.cache[h]
        b = s.C[0]['']; p = np.array([b[c] + .5 for c in AL]); p /= p.sum()
        for j in range(1, len(h)+1):
            ct = s.C[j].get(h[-j:], {}); v = np.array([ct.get(c, 0) for c in AL], float)
            p = (v + s.a*p) / (v.sum() + s.a)
        s.cache[h] = (p, np.cumsum(p)); return s.cache[h]
    def bits(s, R):
        L = n = 0
        for r in R:
            for seg in re.findall(r'[a-z]+', r):
                h = ''
                for c in seg:
                    L -= math.log2(s.P(h)[0][IX[c]]); n += 1; h = (h + c)[-s.k:] if s.k else ''
        return L / n
    def gen(s, tmpl, rng):
        out = []; h = ''; u = rng.random(len(tmpl))
        for i, t in enumerate(tmpl):
            if not t.isalpha(): out.append(t); h = ''; continue
            cs = s.P(h)[1]; c = AL[min(int(np.searchsorted(cs, u[i] * cs[-1])), 25)]
            out.append(c); h = (h + c)[-s.k:] if s.k else ''
        return ''.join(out)
def side_text(R): return ''.join(re.sub(r'[^a-z]', '', r) for r in R)
def D4(t, L=400): return statistics.mean(len({t[i+j:i+j+4] for j in range(L-3)}) for i in range(0, len(t)-L+1, L))
def rep(s, n=6, back=300):
    cov = [0]*len(s)
    for i in range(n, len(s)-n+1):
        if s[i:i+n] in s[max(0, i-back):i+n-1]:
            for j in range(i, i+n): cov[j] = 1
    return sum(cov)/len(s)
def R6(t, L=400): return statistics.mean(rep(t[i:i+L]) for i in range(0, len(t)-L+1, L))
def mi_d(a, d):
    x, y = a[:-d], a[d:]; j = np.bincount(x*26 + y, minlength=676).reshape(26, 26) / len(x)
    px, py = j.sum(1), j.sum(0); nz = j > 0
    return float((j[nz] * np.log2(j[nz] / np.outer(px, py)[nz])).sum())
def MIex(t, rng):
    a = np.array([IX[c] for c in t]); out = []
    for d in range(2, 9):
        sh = [mi_d(rng.permutation(a), d) for _ in range(5)]; out.append(mi_d(a, d) - statistics.mean(sh))
    return statistics.mean(out)
def grams(t, n=5): return {t[i:i+n] for i in range(len(t)-n+1)}
def R6row(R, L=400, n=6, back=300):
    """R6 with no 6-gram crossing a row boundary (reviewer's correction, 31 Oct): both the current and the earlier
    occurrence must lie inside one row; overlap still allowed; windows, i>=6 start, coverage, averaging unchanged."""
    t = ''.join(re.sub(r'[^a-z]', '', r) for r in R); rid = []
    for k, r in enumerate(R): rid += [k] * len(re.sub(r'[^a-z]', '', r))
    vals = []
    for w in range(0, len(t)-L+1, L):
        s = t[w:w+L]; cov = [0]*L; last = {}
        for i in range(L-n+1):
            if rid[w+i] != rid[w+i+n-1]: continue
            g = s[i:i+n]
            if i >= n and g in last and last[g] >= i-back:
                for j in range(i, i+n): cov[j] = 1
            last[g] = i
        vals.append(sum(cov)/L)
    return statistics.mean(vals)
def battery(sides, rng):
    T = [side_text(R) for R in sides]
    d4 = [D4(t) for t in T]
    reuse = [len(grams(T[i]) & (grams(T[i-1]) | grams(T[i-2]) | grams(T[i-3]))) / len(grams(T[i])) for i in range(3, len(T))]
    return {'D4': statistics.mean(d4), 'R6': statistics.mean(R6(t) for t in T), 'R6row': statistics.mean(R6row(R) for R in sides), 'MIex': statistics.mean(MIex(t, rng) for t in T),
            'REUSE': statistics.mean(reuse), 'SLOPE': float(np.polyfit(range(len(d4)), d4, 1)[0])}
rng = np.random.default_rng(1583)
trR = [r for p in TR for r in rows[p]]; dvR = [r for p in DEV for r in rows[p]]
cands = sorted((CM(k, a).fit(trR).bits(dvR), k, a) for k in (0, 1, 2, 3) for a in (0.1, 1.0, 10.0))
print('dev bits/letter (best 5):', [(round(b, 3), k, a) for b, k, a in cands[:5]])
_, K, A = cands[0]; M = CM(K, A).fit(trR + dvR)
print(f'chosen: order {K}, alpha {A}; test sides: {TE}')
for variant in ('raw', 'u restored to a'):
    real_sides = [[(r.replace('u', 'a') if (variant != 'raw' and p in REG) else r) for r in rows[p]] for p in TE]
    real = battery(real_sides, rng)
    sims = [battery([[M.gen(r, rng) for r in R] for R in real_sides], rng) for _ in range(200)]
    _tag = 'raw' if variant == 'raw' else 'u_as_a'
    pd.DataFrame([dict(sim='REAL', **real)] + [dict(sim=i+1, **x) for i, x in enumerate(sims)]).to_csv(f'results/lexicon/sims_{SCRIPT}_{_tag}.csv', index=False)
    print(f'\n=== test block, {variant} (200 synthetic sets) ===')
    print(f'{"measure":7s} {"real":>9s} {"synthetic median":>17s} {"2.5-97.5%":>22s} {"two-sided p":>12s} {"sims >= real":>13s} {"sims <= real":>13s}')
    for m in real:
        v = np.array([s[m] for s in sims]); b = min((v >= real[m]).sum(), (v <= real[m]).sum()); p = min(1.0, 2*(b + 1)/201)
        print(f'{m:7s} {real[m]:9.4f} {np.median(v):17.4f} {np.percentile(v, 2.5):10.4f}..{np.percentile(v, 97.5):9.4f} {p:12.4f} {int((v >= real[m]).sum()):13d} {int((v <= real[m]).sum()):13d}')
