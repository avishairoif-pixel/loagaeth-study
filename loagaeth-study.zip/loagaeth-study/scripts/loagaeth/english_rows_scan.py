"""Scan every row of every Loagaeth leaf (square and diamond) for rows whose letter profile is closer
to English than to Loagaeth (the leaf 7b anomaly). Run from project root."""
import json, re
from collections import Counter
D = json.load(open('data/loagaeth/grids.json')); DI = json.load(open('data/loagaeth/diamonds.json'))
eng = re.sub(r'[^a-z]', '', open('/home/claude/z/loagaeth_research/01_primary_sources/casaubon_1659.txt', errors='replace').read().lower())
lo = ''.join(r for v in D['leaves'].values() for r in v)
AB = 'abcdefghiklmnopqrstuvwxyz'
def prof(t): c = Counter(t); n = max(1, len(t)); return {x: c[x] / n for x in AB}
PE, PL = prof(eng), prof(lo)
def d(p, q): return sum(abs(p[x] - q[x]) for x in AB) / 2
hits = []
for src, leaves in (('square', D['leaves']), ('diamond', DI)):
    for k, rows in leaves.items():
        for i, r in enumerate(rows):
            if len(r) < 25: continue
            p = prof(r); de, dl = d(p, PE), d(p, PL)
            if de < dl: hits.append((src, k, i + 1, round(de, 2), round(dl, 2), r))
print(f'rows closer to English than to Loagaeth: {len(hits)}')
for h in hits: print('  ', h[0], h[1], 'row', h[2], 'dEng', h[3], 'dLoag', h[4], h[5])
