"""A sieve for episodic structure in Loagaeth.

Idea (Avishai): if the text is transcribed glossolalia, its production comes in episodes, so the
text should switch between regimes that differ in their statistics, and those regimes should come
in runs rather than alternate at random.

Unit: one row of a square leaf (49 letters), leaves 2a-25a, in reading order.
Features per row:
  F1 text-likeness   mean bits per letter gained by a letter-bigram model over a unigram model
  F2 lexicon cover   share of letters covered by the 150 recurring words (step 1)
  F3 alternation     share of consonant/vowel alternations
  F4 vowel share
  F5 letter entropy
Tests:
  T1 runs: lag-1 autocorrelation of each feature between consecutive rows, against 2,000 random
     orderings of the rows inside each leaf (a real episode structure gives positive autocorrelation)
  T2 regimes: does a 2-group mixture describe the rows better than a single group (BIC), compared
     with rows rebuilt from shuffled letters of the same leaf
Run from the project root."""
import json, math, random, re, csv
from collections import Counter
import numpy as np
from sklearn.mixture import GaussianMixture
exec(open('scripts/loagaeth/lexicon.py').read().split('# (C)')[0])      # lex, D
V = set('aeiouy')
LEAVES = [f'{n}{s}' for n in range(2, 26) for s in 'ab' if f'{n}{s}' != '25b']
rows = {k: [r[:49] for r in D['leaves'][k] if len(r) >= 49] for k in LEAVES}
rows = {k: v for k, v in rows.items() if len(v) >= 40}
allt = ''.join(r for v in rows.values() for r in v)
uni = Counter(allt); bi = Counter(zip(allt, allt[1:])); A = len(uni); NT = len(allt)
def gain(s):
    return sum(math.log2((bi[(a, b)] + .5) / (uni[a] + .5 * A)) - math.log2((uni[b] + 1) / (NT + A)) for a, b in zip(s, s[1:])) / (len(s) - 1)
recurring = [w for w, c in lex.items() if len(w) >= 5 and c >= 1]
top150 = [r['word'] for r in csv.DictReader(open('results/lexicon/loagaeth_lexicon.csv'))
          if r['count_in_leaves_6a_25a'] and r['shuffled_expectation'] and int(r['count_in_leaves_6a_25a']) >= 3
          and int(r['count_in_leaves_6a_25a']) > 3 * max(float(r['shuffled_expectation']), .3)]
def cover(s):
    m = [0] * len(s)
    for w in top150:
        for x in re.finditer(w, s):
            for i in range(x.start(), x.end()): m[i] = 1
    return sum(m) / len(s)
def feats(s):
    c = Counter(s); n = len(s)
    return [gain(s), cover(s), sum((a in V) != (b in V) for a, b in zip(s, s[1:])) / (n - 1),
            sum(c[x] for x in V) / n, -sum(v / n * math.log2(v / n) for v in c.values())]
NAMES = ['text-likeness', 'lexicon cover', 'C/V alternation', 'vowel share', 'letter entropy']
F = {k: np.array([feats(r) for r in v]) for k, v in rows.items()}
rng = random.Random(1)

def lag1(Fk):
    num = den = 0
    for M in Fk:
        Z = (M - allmu) / allsd
        num += (Z[1:] * Z[:-1]).sum(0); den += len(Z) - 1
    return num / den
allF = np.vstack(list(F.values())); allmu = allF.mean(0); allsd = allF.std(0)
real = lag1(list(F.values()))
null = []
for _ in range(2000):
    null.append(lag1([M[rng.sample(range(len(M)), len(M))] for M in F.values()]))
null = np.array(null)
print(f'{len(F)} leaves, {len(allF)} rows\n')
print('T1  runs: correlation between consecutive rows (real vs random row order)')
for i, n in enumerate(NAMES):
    p = (null[:, i] >= real[i]).mean()
    print(f'    {n:16} real {real[i]:+.3f}   random orders {null[:, i].mean():+.3f} (sd {null[:, i].std():.3f})   p = {p:.4f}')

def bic_gain(X):
    X = (X - X.mean(0)) / X.std(0)
    b1 = GaussianMixture(1, random_state=0).fit(X).bic(X); b2 = GaussianMixture(2, random_state=0, n_init=3).fit(X).bic(X)
    return b1 - b2
real_gain = bic_gain(allF[:, :2])
shuf = []
for t in range(10):
    R = []
    for k, v in rows.items():
        cells = list(''.join(v)); rng.shuffle(cells); s = ''.join(cells)
        R += [feats(s[i*49:(i+1)*49]) for i in range(len(v))]
    shuf.append(bic_gain(np.array(R)[:, :2]))
print('\nT2  regimes: BIC improvement of 2 groups over 1 (text-likeness x lexicon cover)')
print(f'    real {real_gain:.1f}   letter-shuffled leaves {np.mean(shuf):.1f} (range {min(shuf):.1f} to {max(shuf):.1f})')
gm = GaussianMixture(2, random_state=0, n_init=3).fit((allF[:, :2] - allF[:, :2].mean(0)) / allF[:, :2].std(0))
lab = gm.predict((allF[:, :2] - allF[:, :2].mean(0)) / allF[:, :2].std(0))
for g in (0, 1):
    m = allF[lab == g].mean(0)
    print(f'    group {g}: {int((lab == g).sum())} rows; ' + ', '.join(f'{n} {m[i]:.2f}' for i, n in enumerate(NAMES)))
np.save('results/lexicon/row_features.npy', allF)
