"""Step 2 of the ladder (after generator_ladder.py showed that word-level recycling is too rare in leaf 1 to
explain the z: bigram reuse 1.1% in the first half, and 98% of the MI comes from bigram types seen once).
Diagnosis: the repeated pairs are short syllable-like units (mi na, gem na, pa ge, na ca, ge do).
G2 = a continuous letter n-gram model WITH the space as a symbol (order k = 3, 4, 5), trained on the FIRST
half only, generating text whose words are whatever falls between spaces: no lexicon, no word syntax, but
letter context can cross a word boundary. Tested on second-half length. Positive control: the same
generator trained on the first half of Latin and English samples, to see whether the windowed z test
separates real language from its own letter model at all."""
import sys, random, statistics
from collections import Counter, defaultdict
sys.path.insert(0, 'scripts/loagaeth')
exec(open('scripts/loagaeth/generator_ladder.py').read().split('H1, H2 =')[0])     # mi, zwin, zglob, repn, LOA, eng, lat, heb
def train(words, k):
    t = ' ' + ' '.join(words) + ' '; M = defaultdict(Counter)
    for i in range(len(t)-k): M[t[i:i+k]][t[i+k]] += 1
    return t, M
def gen(words, k, n, rng):
    t, M = train(words, k); st = rng.randrange(len(t)-k); ctx = t[st:st+k]; out = ''
    while out.count(' ') < n + 2:
        c = M.get(ctx)
        if not c:   # dead end: restart from a random context
            st = rng.randrange(len(t)-k); ctx = t[st:st+k]; continue
        ch = rng.choices(list(c), list(c.values()))[0]; out += ch; ctx = ctx[1:] + ch
    return out.split()[1:n+1]
def summ(xs): return f'{statistics.median(xs):6.1f} [{min(xs):.1f}..{max(xs):.1f}]'
rng = random.Random(21)
src = {'Loagaeth leaf 1': LOA}
for name, corp in (('Latin (Erasmus)', lat), ('English (Casaubon)', eng)):
    s0 = rng.randrange(0, len(corp) - len(LOA)); src[name] = corp[s0:s0+len(LOA)]
print(f'{"source / text":44s} {"windowed z w=10":>20s} {"global z":>20s} {"types/tokens":>13s} {"word-bigram reuse":>18s}')
for name, ws in src.items():
    A, B = ws[:len(ws)//2], ws[len(ws)//2:]; n = len(B)
    print(f'{name+": real second half":44s} {summ([zwin(B,10,rng)]):>20s} {summ([zglob(B,rng)]):>20s} {len(set(B))/n:13.2f} {repn(B,2):18.3f}')
    for k in (3, 4, 5):
        G = [gen(A, k, n, rng) for _ in range(10)]
        print(f'{"   letter "+str(k)+"-gram (+space) trained on first half":44s} {summ([zwin(g,10,rng) for g in G]):>20s} {summ([zglob(g,rng) for g in G]):>20s} '
              f'{statistics.median(len(set(g))/n for g in G):13.2f} {statistics.median(repn(g,2) for g in G):18.3f}')
