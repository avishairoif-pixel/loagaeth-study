"""Is Loagaeth meant to be read right-to-left? (claim from the GLM session: 'R->L coverage beats L->R by 25%',
made on Zubair's demo strings and a VLM transcription, with no control.)
Proper test on Peterson's transcription:
  vocabulary = Enochian words of the 48 Claves as Casaubon (1659) prints them: CAPITALS word, English gloss,
  then the same word split into syllables; we keep only entries where the syllables re-spell the word (clean set);
  count occurrences of each word (>=4 letters) in every Loagaeth row read forward and reversed.
Positive control: the same procedure on English text with English words (direction must show).
Null: the same counts on Loagaeth rows with letters shuffled inside each row."""
import re, sys, json, random
sys.path.insert(0, 'scripts/loagaeth')
import leaf7b_transposition as T
raw = T._raw
voc = set()
for m in re.finditer(r'\b([A-Z]{3,})\b', raw):
    w = m.group(1).lower(); tail = raw[m.end():m.end() + 120]
    syl = re.sub(r'[^a-z]', '', tail.lower())
    # the syllabified repeat must appear after the gloss: look for the word spelled out in lowercase within the tail
    if w in re.sub(r'\s+', '', re.sub(r'[^A-Za-z ]', ' ', tail)).lower() and not re.fullmatch(r'[ivxlc]+', w):
        voc.add(w.replace('u', 'v').replace('j', 'i'))
voc4 = sorted(w for w in voc if len(w) >= 4)
print(f'Claves vocabulary (clean, syllable-confirmed): {len(voc)} words, {len(voc4)} with >=4 letters')
print('  sample:', ', '.join(voc4[:25]))
D = json.load(open('data/loagaeth/grids.json'))
rows = [r.replace('u', 'v') for leaf in D['leaves'].values() for r in leaf if len(r) >= 40]
def count(rows, words):
    return sum(r.count(w) for r in rows for w in words)
fwd, rev = count(rows, voc4), count([r[::-1] for r in rows], voc4)
print(f'\nLoagaeth ({len(rows)} rows): forward {fwd}, reversed {rev}, ratio {rev/max(fwd,1):.2f}')
nul = []
for s in range(200):
    rng = random.Random(s); sh = [''.join(rng.sample(r, len(r))) for r in rows]
    nul.append(count(sh, voc4))
nul.sort(); print(f'  shuffled-within-row null: median {nul[100]}, 2.5-97.5% [{nul[5]}, {nul[194]}]')
# per-word breakdown of the biggest asymmetries
diff = sorted(((sum(r.count(w) for r in rows), sum(r[::-1].count(w) for r in rows), w) for w in voc4), key=lambda x: -(x[0] + x[1]))[:15]
print('  most frequent Claves words (fwd, rev):', '; '.join(f'{w} {a}/{b}' for a, b, w in diff))
# positive control: English
eng = T.eng; chunks = [eng[i:i+49] for i in range(0, 49*3000, 49)]
ew = sorted({w for w in re.findall(r'[a-z]{4,}', raw.lower())[:20000]})[:600]
ef, er = count(chunks, ew), count([c[::-1] for c in chunks], ew)
print(f'\nPOSITIVE CONTROL English ({len(chunks)} rows of 49, {len(ew)} English words): forward {ef}, reversed {er}, ratio {er/max(ef,1):.2f}')
# robustness: drop the single most frequent word and English look-alikes
drop = {'emna', 'hath', 'part', 'anno', 'para', 'alar'}
v2 = [w for w in voc4 if w not in drop]
f2, r2 = count(rows, v2), count([r[::-1] for r in rows], v2)
n2 = sorted(count([''.join(random.Random(s).sample(r, len(r))) for r in rows], v2) for s in range(200))
print(f'\nwithout {sorted(drop)}: forward {f2}, reversed {r2}; shuffled null median {n2[100]}, 95% [{n2[5]}, {n2[194]}]')
