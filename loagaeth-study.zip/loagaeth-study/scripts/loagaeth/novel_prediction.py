"""Generalisation test (proposed in review): does the text get better at producing NEW combinations according to
regularities learned earlier, beyond re-using old material?
For each leaf i >= 3 (square leaves 2a-25a, production order), all leaves cut to equal length:
  train a letter-trigram model (add-0.1 smoothing) on the previous 3 leaves only;
  on leaf i, split positions into SEEN (the 5-letter sequence ending here occurred in training) and NOVEL (it did not);
  record mean log2-probability per letter in each group.
Trend = Pearson r between leaf position and the score; null = the same computed on 1,000 random leaf orders;
p = share of random orders with r at least as large (one-sided), and the central 95% of the null is reported.
Also reports the same statistics for the reuse measure (D1c) and the convergence measure (D2) of rule_stabilization.py."""
import re, json, math, random, statistics
from collections import Counter, defaultdict
D = json.load(open('data/loagaeth/grids.json'))
def num(k): m = re.fullmatch(r'(\d+)([ab])', k); return int(m.group(1)) * 2 + (m.group(2) == 'b') if m else 999
keys = sorted([k for k in D['leaves'] if num('2a') <= num(k) <= num('25a')], key=num)
LV = {k: ''.join(r[:49] for r in D['leaves'][k] if len(r) >= 49) for k in keys}
LV = {k: v for k, v in LV.items() if len(v) >= 1500}; keys = [k for k in keys if k in LV]
L = min(len(v) for v in LV.values()); LV = {k: v[:L] for k, v in LV.items()}
A = sorted(set(''.join(LV.values()))); V = len(A)
def scores(order):
    seen_s, novel_s, nov_share = [], [], []
    for i in range(3, len(order)):
        tri = defaultdict(Counter); five = set()
        for k in order[i-3:i]:
            s = LV[k]
            for j in range(len(s) - 2): tri[s[j:j+2]][s[j+2]] += 1
            five.update(s[j:j+5] for j in range(len(s) - 4))
        s = LV[order[i]]; a, b = [], []
        for j in range(4, len(s)):
            c = tri[s[j-2:j]]; p = (c[s[j]] + .1) / (sum(c.values()) + .1 * V)
            (a if s[j-4:j+1] in five else b).append(math.log2(p))
        seen_s.append(statistics.mean(a)); novel_s.append(statistics.mean(b)); nov_share.append(len(b) / (len(a) + len(b)))
    return seen_s, novel_s, nov_share
def pr(x, y):
    mx, my = statistics.mean(x), statistics.mean(y)
    return sum((a - mx) * (b - my) for a, b in zip(x, y)) / math.sqrt(sum((a - mx) ** 2 for a in x) * sum((b - my) ** 2 for b in y))
rng = random.Random(8)
real = scores(keys); t = list(range(len(real[0])))
nulls = [scores(rng.sample(keys, len(keys))) for _ in range(1000)]
names = ['SEEN material: log2 p per letter', 'NOVEL material: log2 p per letter', 'share of novel material']
print(f'{len(keys)} leaves, each cut to {L} letters; model = trigram trained on the previous 3 leaves; 1,000 random leaf orders\n')
for idx, nm in enumerate(names):
    r = pr(t, real[idx]); nr = sorted(pr(t, n[idx]) for n in nulls)
    p_hi = sum(x >= r for x in nr) / len(nr); p_lo = sum(x <= r for x in nr) / len(nr)
    third = len(real[idx]) // 3
    print(f'{nm:36s} first third {statistics.mean(real[idx][:third]):+.3f}  last third {statistics.mean(real[idx][-third:]):+.3f}  '
          f'Pearson r={r:+.2f}  null 95% [{nr[25]:+.2f}, {nr[974]:+.2f}]  p(up)={p_hi:.3f} p(down)={p_lo:.3f}')
