import re, unicodedata, json
lines = open('data/loagaeth/peterson_sl3189.txt', encoding='utf-8', errors='replace').read().split('\n')
def norm(s):
    s = unicodedata.normalize('NFD', s)
    return ''.join(ch for ch in s if not unicodedata.combining(ch))
leaf_re = re.compile(r'^\[LEAF (\d+[ab])\]', re.I)
row_re = re.compile(r'^(?:[A-Za-zÀ-ÿĀ-ɏ?_](?:[ .,;:]|$)){20,}')
leaves = {}; cur = None
soy_start = next(i for i,l in enumerate(lines) if l.startswith('[TABLES OF SOYGA]'))
for i, l in enumerate(lines[:soy_start]):
    m = leaf_re.match(l)
    if m: cur = m.group(1).lower(); leaves[cur] = []; continue
    if cur and cur not in ('1a', '1b'):
        t = norm(l.strip())
        if row_re.match(t):
            toks = re.split(r'[ ]', t)
            rowtxt = ''.join(ch for ch in t if ch.isalpha() or ch in '?')   # letters only
            seps = [m.start() for m in re.finditer(r'[.,;:]', t)]
            leaves[cur].append({'row': rowtxt.lower(), 'raw': t})
# Soyga
soy = {}; name = None
for l in lines[soy_start:]:
    if 'table' in l.lower() and len(l) < 40: name = l.strip('" ').strip(); soy[name] = []; continue
    m = re.match(r'^\s*(\d+)\.\s+((?:\S\s?){20,})$', l)
    if name and m:
        soy[name].append(''.join(m.group(2).split()).replace('_',''))
json.dump({'leaves': {k: [r['row'] for r in v] for k, v in leaves.items()},
           'raw': {k: [r['raw'] for r in v] for k, v in leaves.items()},
           'soyga': soy}, open('data/loagaeth/grids.json', 'w'))
from collections import Counter
lens = Counter(); nrows = {}
for k, v in leaves.items():
    nrows[k] = len(v); lens.update(len(r['row']) for r in v)
print('leaves parsed:', len(leaves)); print('rows per leaf:', nrows)
print('row length distribution (top):', lens.most_common(12))
print('soyga tables:', {k: (len(v), Counter(len(r) for r in v).most_common(2)) for k, v in soy.items()})
