import json, math, random
from collections import Counter
D = json.load(open('data/loagaeth/grids.json')); T = json.load(open('data/loagaeth/tilde_grids.json'))
# bigram model from ordinary text leaves 2a-25a (rows)
train = ''.join(r for k in D['leaves'] for r in D['leaves'][k] if k[:-1].isdigit() and 2 <= int(k[:-1]) <= 25 and k != '25b' and 47 <= len(r) <= 51)
uni = Counter(train); bi = Counter(zip(train, train[1:])); A = sorted(uni); V = len(A)
def lp(a, b): return math.log2((bi[(a, b)] + 0.5) / (uni[a] + 0.5 * V))
def lpu(b): return math.log2((uni[b] + 1) / (len(train) + V))
def score(s):   # bits per char gain of bigram model over unigram model (>0 means text-like)
    return sum(lp(a, b) - lpu(b) for a, b in zip(s, s[1:])) / max(1, len(s) - 1)
rng = random.Random(7)
for leaf, g in T.items():
    n = len(g)
    print(f'\n{leaf} ({n}x49): text-score per diagonal (bits/char; ordinary text ~ +1, shuffle ~ 0)')
    for sj, lab in ((1, 'DR'), (-1, 'DL')):
        sc = [score(''.join(g[i][(d + sj*i) % 49] for i in range(n))) for d in range(49)]
        print(f'  {lab}: ' + ' '.join(f'{x:+.1f}' for x in sc))
    rows = [score(r) for r in g]; print('  rows: ' + ' '.join(f'{x:+.1f}' for x in rows[:20]), '...')
    c = [x for r in g for x in r]; rng.shuffle(c); sh = ''.join(c)
    print(f'  shuffled baseline: {score(sh):+.2f}')
# reference
print('\nreference rows of leaf 5a:', ' '.join(f'{score(r):+.1f}' for r in D["leaves"]["5a"][:10]))

print('\n=== non-wrapped diagonals of 26b, scored (only length>=15) ===')
g = T['26b']
anti = {u: ''.join(g[i][u-i] for i in range(49) if 0 <= u-i < 49) for u in range(97)}
main = {v: ''.join(g[i][i+v] for i in range(49) if 0 <= i+v < 49) for v in range(-48, 49)}
ev = [score(s) for u, s in anti.items() if len(s) >= 15 and u % 2 == 0]
od = [score(s) for u, s in anti.items() if len(s) >= 15 and u % 2 == 1]
print(f'anti-diagonals (i+j=u): even u mean {sum(ev)/len(ev):+.2f} (n={len(ev)}), odd u mean {sum(od)/len(od):+.2f} (n={len(od)})')
ev = [score(s) for v, s in main.items() if len(s) >= 15 and v % 2 == 0]
od = [score(s) for v, s in main.items() if len(s) >= 15 and v % 2 != 0]
print(f'main diagonals (j-i=v): even v mean {sum(ev)/len(ev):+.2f}, odd v mean {sum(od)/len(od):+.2f}')
print('sample even anti-diagonals:'); [print('  ', anti[u]) for u in (40, 42, 44, 46, 48)]
print('sample odd anti-diagonals:');  [print('  ', anti[u]) for u in (41, 43, 45)]
