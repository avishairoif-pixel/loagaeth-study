"""Step 2: word collocations in Liber Loagaeth.
(1) Word pairs (bigrams) inside the segmented sources (leaf 1, leaves 2a-5a).
(2) For the strongest recurring words, what immediately precedes and follows them in the
    unsegmented leaves 6a-25a (the validated words of step 1 are matched in the gap)."""
import re, json, unicodedata, math, csv
from collections import Counter, defaultdict
exec(open('scripts/loagaeth/lexicon.py').read().split('# (C)')[0])        # builds leaf1, seg, lex, src
# sequences in order: leaf 1 is one running text; for grids keep each row's inner words in order
seqs = [leaf1]
for k in ('2a', '2b', '3a', '3b', '4a', '4b', '5a'):
    for r in D['raw'][k]:
        parts = [''.join(c for c in p if c.isalpha()) for p in re.split(r'[.,;:]', re.sub(r'[ ?]', '', norm(r)))]
        if len(parts) > 2: seqs.append([p for p in parts[1:-1] if p])
uni = Counter(w for s in seqs for w in s); N = sum(uni.values())
bi = Counter((a, b) for s in seqs for a, b in zip(s, s[1:])); NB = sum(bi.values())
print(f'(1) word pairs in segmented sources: {NB} pairs, {len(bi)} distinct')
rows = []
for (a, b), c in bi.items():
    if c >= 3:
        pmi = math.log2((c / NB) / ((uni[a] / N) * (uni[b] / N)))
        rows.append((c, pmi, a, b))
rows.sort(key=lambda x: (-x[0], -x[1]))
print('   pairs occurring 3+ times (count, PMI):')
for c, p, a, b in rows[:30]: print(f'     {a} {b:12} x{c}  PMI {p:+.1f}')
# (2) contexts in unsegmented leaves
later = {k: [r[:49] for r in D['leaves'][k] if len(r) >= 49] for k in D['leaves']
         if k[:-1].isdigit() and 6 <= int(k[:-1]) <= 25 and k != '25b'}
top = ['anzach', 'cheph', 'nodax', 'nochas', 'ontant', 'arged', 'napha', 'vorge', 'vanta', 'argen', 'anget', 'doxan']
valid = sorted({w for w, c in lex.items() if len(w) >= 3 and c >= 2}, key=len, reverse=True)
def word_at(s, i, forward=True):
    for w in valid:
        if forward and s.startswith(w, i): return w
        if not forward and i - len(w) >= 0 and s[i-len(w):i] == w: return w
    return None
print('\n(2) neighbours of the strongest recurring words in leaves 6a-25a (row text, joined across rows):')
ctx = {}
for t in top:
    after, before, leaves_seen = Counter(), Counter(), set()
    for k, g in later.items():
        s = ''.join(g)
        for m in re.finditer(t, s):
            leaves_seen.add(k)
            a = word_at(s, m.end(), True); b = word_at(s, m.start(), False)
            if a: after[a] += 1
            if b: before[b] += 1
    ctx[t] = (before, after, leaves_seen)
    print(f'   {t:8} in {len(leaves_seen):2} leaves | before: {before.most_common(4)} | after: {after.most_common(4)}')
with open('results/lexicon/word_pairs.csv', 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['word1', 'word2', 'count', 'pmi'])
    for c, p, a, b in rows: w.writerow([a, b, c, round(p, 2)])
