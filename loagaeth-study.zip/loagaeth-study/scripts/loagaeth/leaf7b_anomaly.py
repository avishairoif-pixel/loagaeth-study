"""Leaf 7b, rows 16-23: the block flagged by the row-level HMM sieve.
(1) letter profile vs ordinary Loagaeth and vs English; (2) English-likeness of the block under
many reading orders (rows, reversed, columns, diagonals, every k-th letter), scored with an
English letter-bigram model from Casaubon 1659, against the same orders on ordinary Loagaeth rows."""
import json, math, re
from collections import Counter
D = json.load(open('data/loagaeth/grids.json'))
rows = [r[:49] for r in D['leaves']['7b'] if len(r) >= 49]
block_idx = [15, 16, 17, 18, 19, 21]                        # rows 16-20 and 22 (1-based)
block = [rows[i] for i in block_idx]
normal = [rows[i] for i in range(len(rows)) if i not in block_idx]
eng = re.sub(r'[^a-z]', '', open('/home/claude/z/loagaeth_research/01_primary_sources/casaubon_1659.txt', errors='replace').read().lower())
eng = eng.replace('j', 'i').replace('w', 'w')
lo = ''.join(r for k, v in D['leaves'].items() if k[:-1].isdigit() and 2 <= int(k[:-1]) <= 25 for r in v if len(r) >= 49)
def prof(t):
    c = Counter(t); n = len(t); return {x: c[x] / n for x in 'abcdefghiklmnopqrstuvwxyz'}
def dist(p, q): return sum(abs(p[x] - q[x]) for x in p) / 2
B = ''.join(block); pb, pe, pl = prof(B), prof(eng), prof(lo)
print(f'block: {len(B)} letters. Distance of its letter profile from ENGLISH {dist(pb, pe):.2f}, from LOAGAETH {dist(pb, pl):.2f} (0 = identical, 1 = disjoint)')
for x in 'etsyw':
    print(f'   letter {x}: block {pb[x]:.1%}   English {pe[x]:.1%}   Loagaeth {pl[x]:.1%}')
ub = Counter(eng); bb = Counter(zip(eng, eng[1:])); NA = 26; NE = len(eng)
def eng_gain(s):
    return sum(math.log2((bb[(a, b)] + .5) / (ub[a] + .5 * NA)) - math.log2((ub[b] + 1) / (NE + NA)) for a, b in zip(s, s[1:])) / (len(s) - 1)
def orders(g):
    n, m = len(g), len(g[0]); o = {}
    o['rows'] = ''.join(g); o['rows reversed'] = ''.join(g)[::-1]
    o['columns down'] = ''.join(g[i][j] for j in range(m) for i in range(n))
    o['columns up'] = ''.join(g[i][j] for j in range(m) for i in range(n - 1, -1, -1))
    o['boustrophedon'] = ''.join(r if i % 2 == 0 else r[::-1] for i, r in enumerate(g))
    o['diagonals'] = ''.join(g[i][(i + d) % m] for d in range(m) for i in range(n))
    o['anti-diagonals'] = ''.join(g[i][(d - i) % m] for d in range(m) for i in range(n))
    for k in (2, 3, 7): o[f'every {k}th letter'] = ''.join(''.join(g)[s::k] for s in range(k))
    return o
ob = orders(block); on = orders(normal[:7])
print('\nEnglish-likeness (bits/letter gained by an English bigram model; real English text scores about +1.0):')
for name in ob: print(f'   {name:18} block {eng_gain(ob[name]):+.2f}    ordinary 7b rows {eng_gain(on[name]):+.2f}')
print('\nreference: Casaubon English', f'{eng_gain(eng[5000:5343]):+.2f}', '| Loagaeth rows', f'{eng_gain(lo[:343]):+.2f}')
print('\nthe block, row by row:'); [print('  ', r) for r in block]

# transposition signature: a transposed English text keeps English letter frequencies but loses English
# letter order. Compare the block with English letters shuffled at random (same length).
import random
rng = random.Random(1); sh = []
for _ in range(200):
    s = list(eng[rng.randrange(len(eng) - 400):][:len(B)]); rng.shuffle(s); sh.append(eng_gain(''.join(s)))
real_eng = [eng_gain(eng[i:i+len(B)]) for i in range(0, 200000, 20000)]
print(f'\nEnglish-likeness: block (rows) {eng_gain(B):+.2f} | real English passages {sum(real_eng)/len(real_eng):+.2f} | English letters shuffled {sum(sh)/len(sh):+.2f} (range {min(sh):+.2f} to {max(sh):+.2f})')
