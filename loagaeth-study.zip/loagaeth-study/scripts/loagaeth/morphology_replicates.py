"""Robustness check for morphology.py: the key statistics on 20 independent control lexicons."""
import random, sys, io, contextlib
src = open('scripts/loagaeth/morphology.py').read()
head = src.split("print(f'Real lexicon:")[0]
results = []
for seed in range(20):
    g = {}
    with contextlib.redirect_stdout(io.StringIO()):
        exec(head.replace('random.Random(42)', f'random.Random({seed})'), g)
    aff, sig, mor = g['affixes'], g['signatures'], g['morfessor_run']
    words, control, CTRL, types, Counter = g['words'], g['control'], g['CTRL'], g['types'], g['Counter']
    if seed == 0:
        rs = [a for a, n, f in aff(words, 'suffix')[:20]]; rp = [a for a, n, f in aff(words, 'prefix')[:20]]
        top_suf = [a for a, n, f in aff(words, 'suffix')[:15]]
        real = (sum(f for _, _, f in aff(words, 'suffix')[:20]), sum(f for _, _, f in aff(words, 'prefix')[:20]),
                sum(len(st) for s, st in sig(words, top_suf)), len(mor(Counter({w: types[w] for w in words}))[1]))
    cs = {a: f for a, n, f in aff(control, 'suffix')}; cp = {a: f for a, n, f in aff(control, 'prefix')}
    results.append((sum(cs.get(a, 0) for a in rs), sum(cp.get(a, 0) for a in rp),
                    sum(len(st) for s, st in sig(control, top_suf)), len(mor(CTRL)[1])))
names = ['free stems, top-20 suffixes', 'free stems, top-20 prefixes', 'stems in paradigms', 'Morfessor morph inventory']
for i, n in enumerate(names):
    vals = [r[i] for r in results]; mu = sum(vals) / len(vals); sd = (sum((v - mu) ** 2 for v in vals) / len(vals)) ** .5
    print(f'{n:30} REAL {real[i]:5}   CONTROL mean {mu:7.1f} (range {min(vals)}-{max(vals)})   z = {(real[i]-mu)/sd:+.1f}')
