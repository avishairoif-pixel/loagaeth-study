"""Linear vs saturation vs change-point for the reuse series (proposed in the external review).
Series: D1c (reuse of 5-letter sequences from the previous 3 leaves, every leaf cut to equal length), production order.
Models (least squares, Gaussian errors, BIC = n ln(RSS/n) + k ln n):
  linear            y = a + b t                                   k=2
  saturation        y = c - (c - y0) exp(-t / tau)                k=3
  rise-then-flat    y = a + b min(t, cp), cp searched              k=3 (cp counted as a parameter)
  step              y = m1 (t < cp), m2 (t >= cp)                  k=3
Also: the same comparison with the 7b and 21a points removed (the two outliers)."""
import re, json, math, statistics
import numpy as np
from scipy.optimize import curve_fit
exec(open('scripts/loagaeth/rule_stabilization.py').read().split('# D1b (correction)')[0].split('# D1\n')[0])
LVc = None
L = min(len(v) for v in LV.values())
def d1c(order):
    out = []
    for i in range(3, len(order)):
        mem = set(); [mem.update(LV[k][:L][j:j+5] for j in range(L - 4)) for k in order[i-3:i]]
        s = LV[order[i]][:L]; g = [s[j:j+5] for j in range(L - 4)]
        out.append(sum(x in mem for x in g) / len(g))
    return out
y_all = np.array(d1c(keys)); lab = keys[3:]
def fit_all(t, y):
    n = len(y); res = {}
    b = np.polyfit(t, y, 1); r = ((y - np.polyval(b, t)) ** 2).sum(); res['linear'] = (r, 2, f'slope {b[0]*100:+.2f} pts/leaf')
    f = lambda t, c, y0, tau: c - (c - y0) * np.exp(-t / tau)
    try:
        p, _ = curve_fit(f, t, y, p0=[y.max(), y[0], 5], maxfev=20000); r = ((y - f(t, *p)) ** 2).sum()
        res['saturation'] = (r, 3, f'plateau {p[0]:.3f}, time constant {p[2]:.1f} leaves')
    except Exception as e: res['saturation'] = (np.inf, 3, 'no fit')
    best = None
    for cp in range(3, n - 3):
        X = np.column_stack([np.ones(n), np.minimum(t, t[cp])]); co, *_ = np.linalg.lstsq(X, y, rcond=None)
        r = ((y - X @ co) ** 2).sum()
        if best is None or r < best[0]: best = (r, cp, co)
    res['rise-then-flat'] = (best[0], 3, f'rise until {lab_[best[1]]}, slope before {best[2][1]*100:+.2f} pts/leaf')
    best = None
    for cp in range(3, n - 3):
        r = ((y[:cp] - y[:cp].mean()) ** 2).sum() + ((y[cp:] - y[cp:].mean()) ** 2).sum()
        if best is None or r < best[0]: best = (r, cp)
    res['step'] = (best[0], 3, f'step at {lab_[best[1]]}: {y[:best[1]].mean():.3f} -> {y[best[1]:].mean():.3f}')
    out = {k: n * math.log(r / n) + kk * math.log(n) for k, (r, kk, _) in res.items()}
    m = min(out.values())
    for k, (r, kk, d) in res.items(): print(f'   {k:15s} BIC {out[k]:7.1f}  (delta {out[k]-m:5.1f})  {d}')
for name, mask in (('all leaves', [True] * len(lab)), ('without 7b and 21a', [l not in ('7b', '21a') for l in lab])):
    y = y_all[np.array(mask)]; lab_ = [l for l, m in zip(lab, mask) if m]; t = np.arange(len(y), dtype=float)
    print(f'\n{name} (n={len(y)}):'); fit_all(t, y)
