"""Leaves 21a and 23a-24b: what does u stand in for? (follow-up to an external analysis)
(1) letter shares of a, e, o, u, v in these leaves vs the rest;
(2) for every 4-letter sequence containing u in these leaves, replace u by each other vowel and ask how often the
    result is a sequence attested in the u-free leaves (2a-20b, 21b, 22a, 25a); the vowel that 'restores' the most
    sequences is the one u most likely stands for (a graphic or orthographic variant)."""
import json, re
from collections import Counter
D = json.load(open('data/loagaeth/grids.json'))
def num(k): m = re.fullmatch(r'(\d+)([ab])', k); return int(m.group(1)) * 2 + (m.group(2) == 'b') if m else 999
ks = [k for k in D['leaves'] if num('2a') <= num(k) <= num('25a')]
T = {k: [r[:49] for r in D['leaves'][k] if len(r) >= 49] for k in ks}
U = ['21a', '23a', '23b', '24a', '24b']
ref = [k for k in ks if k not in U and k != '22b']
for k in ['20b', '21a', '21b', '22a', '22b', '23a', '23b', '24a', '24b', '25a']:
    t = ''.join(T[k]); c = Counter(t); n = len(t)
    print(f'{k:>4}: ' + '  '.join(f'{x} {100*c[x]/n:4.1f}%' for x in 'aeouv'))
rest = ''.join(''.join(T[k]) for k in ref); cr = Counter(rest); print(f'rest: ' + '  '.join(f'{x} {100*cr[x]/len(rest):4.1f}%' for x in 'aeouv'))
refset = Counter(r[i:i+4] for k in ref for r in T[k] for i in range(len(r) - 3))
ug = Counter(r[i:i+4] for k in U for r in T[k] for i in range(len(r) - 3) if 'u' in r[i:i+4])
print(f'\n{sum(ug.values())} occurrences of 4-letter sequences with u in {U}')
for v in 'aeoiy':
    hit = sum(c for g, c in ug.items() if refset[g.replace("u", v)] > 0)
    print(f'   u -> {v}: {100*hit/sum(ug.values()):5.1f}% become sequences attested in the u-free leaves')
print('   examples (u-sequence -> a-version: count in u-free leaves):',
      ', '.join(f'{g}->{g.replace("u","a")}:{refset[g.replace("u","a")]}' for g, _ in ug.most_common(10)))
