"""Leaf 7b block: is it English (or Latin) written with English secretary-hand and/or Italian (italic)
abbreviations, as a transcription that keeps only the letters would show them?
Forward model: take real text, apply each abbreviation system, and ask which version the block's letter
profile resembles; bootstrap 244-letter chunks of each version to see whether the block is a plausible sample.
Then re-run the transposition searches with a quadgram model of the best-fitting version.
Letters: j->i, u/v merged into v (Peterson writes v), as in the transcription. Run from project root."""
import re, sys, glob, html, random, statistics, math
from collections import Counter
sys.path.insert(0, 'scripts/loagaeth')
import leaf7b_transposition as T
import leaf7b_chessboard as C
AB = 'abcdefghiklmnopqrstvwxyz'
def norm(s): return s.lower().replace('j', 'i').replace('u', 'v')
core = norm(''.join(re.sub(r'[^a-z]', '', T.L[i - 1].lower()) for i in (1345, 1346, 1347, 1348, 1349)))
eng_words = re.findall(r'[a-z]+', T._raw.lower())
lat_raw = ' '.join(open(f, errors='replace').read() for f in ['/home/claude/dl_latin/ll/ficino.txt'] + glob.glob('/home/claude/dl_latin/ll/erasmus/*.txt'))
lat_words = re.findall(r'[a-z]+', lat_raw.lower())
# --- English secretary hand: thorn-y in function words, plus wt / wch / yr ---
SEC = {'the': 'ye', 'that': 'yt', 'them': 'ym', 'this': 'ys', 'thou': 'yu', 'thee': 'ye', 'then': 'yn', 'they': 'yei',
       'with': 'wt', 'which': 'wch', 'your': 'yr', 'there': 'yr'}
def secretary(w): return SEC.get(w, w)
def thorn_all(w): return w.replace('th', 'y')
# --- Italian / italic conventions (Cappelli-type) that survive as letters ---
def italian(w):
    w = re.sub(r'^(per|par|pro|pre)(?=.)', 'p', w)           # p with a stroke
    w = re.sub(r'(?<=[aeiouy])[nm](?=[^aeiouy]|$)', '', w)   # nasal under a macron (tilde) dropped
    w = re.sub(r'(?<=.)(us|um)$', '', w)                      # -us/-um sign (9 / 4-shape) dropped
    w = re.sub(r'que$', 'q', w)                               # -que -> q;
    w = re.sub(r'^con(?=.)', '', w)                           # con- sign (reversed c) dropped
    return w
def build(words, fs):
    out = []
    for w in words:
        for f in fs: w = f(w)
        out.append(w)
    return norm(''.join(out))
VERS = {
  'English plain': build(eng_words, []),
  'English + secretary (ye, yt, wt, wch)': build(eng_words, [secretary]),
  'English + thorn-y everywhere': build(eng_words, [thorn_all]),
  'English + Italian marks': build(eng_words, [italian]),
  'English + secretary + Italian': build(eng_words, [secretary, italian]),
  'English + thorn-y everywhere + Italian': build(eng_words, [thorn_all, italian]),
  'Latin plain': build(lat_words, []),
  'Latin + Italian marks': build(lat_words, [italian]),
}
def prof(t): c = Counter(t); n = len(t); return {x: c[x] / n for x in AB}
def dist(p, q): return sum(abs(p[x] - q[x]) for x in AB) / 2
if __name__ == '__main__':
    pb = prof(core); rng = random.Random(1)
    print(f'core rows 17-21: {len(core)} letters\n')
    print(f'{"version":42s} dist  | 244-letter samples of the version: median, 95th pct | block percentile')
    res = []
    for k, t in VERS.items():
        pv = prof(t); d = dist(pb, pv)
        boot = sorted(dist(prof(t[s:s + len(core)]), pv) for s in (rng.randrange(len(t) - 300) for _ in range(2000)))
        pct = 100 * sum(x <= d for x in boot) / len(boot)
        res.append((d, k)); print(f'{k:42s} {d:.3f} | {statistics.median(boot):.3f}, {boot[1899]:.3f} | {pct:5.1f}')
    print('\nbiggest letter gaps, block minus version (percent points):')
    for k in ('English plain', 'English + secretary (ye, yt, wt, wch)', 'English + secretary + Italian'):
        pv = prof(VERS[k]); g = sorted(((pb[x] - pv[x]) * 100, x) for x in AB)
        print(f'  {k:40s} ' + ' '.join(f'{x}{v:+.1f}' for v, x in g[:4] + g[-4:]))
    # ---- transposition searches with the best-fitting abbreviated-English model ----
    best = min((d, k) for d, k in res if k.startswith('English') and k != 'English plain')[1]
    t = VERS[best]; Q = Counter(t[i:i+4] for i in range(len(t) - 3)); NQ = sum(Q.values())
    T.QL = {k: math.log10(v / NQ) for k, v in Q.items()}; T.FLOOR = math.log10(0.01 / NQ)
    C.QL, C.FLOOR, C.score = T.QL, T.FLOOR, T.score
    print(f'\n=== searches re-run with a quadgram model of "{best}" ===')
    print(f'reference: real text of this version {T.score(t[50000:50000+len(core)]):.3f} | block as written {T.score(core):.3f}')
    rb = T.solve(core, 2); print(f'columnar/rail: block {rb[0]:.3f} via {rb[1]}\n   {rb[2][:120]}')
    neg = []
    for s in range(15):
        l = list(core); random.Random(900 + s).shuffle(l); neg.append(T.solve(''.join(l), s)[0])
    print(f'   shuffles (15): mean {statistics.mean(neg):.3f}, max {max(neg):.3f}')
    pt = t[60000:60000 + len(core)]; key = list(range(9)); random.Random(3).shuffle(key)
    pc = T.solve(T.col_encrypt(pt, key), 4); print(f'   positive control: {pc[0]:.3f} via {pc[1]}\n   {pc[2][:90]}')
    rows7 = [norm(r) for r in C.ROWS]
    s7, k7 = C.best_fixed(rows7); print(f'7x7 fixed routes: block {s7:.3f} via {k7}')
    neg = []
    for s in range(100):
        l = list(''.join(rows7)); random.Random(s).shuffle(l); neg.append(C.best_fixed([''.join(l[49*i:49*(i+1)]) for i in range(7)])[0])
    neg.sort(); print(f'   shuffles (100): mean {statistics.mean(neg):.3f}, max {neg[-1]:.3f}, block beaten by {sum(x >= s7 for x in neg)}')
