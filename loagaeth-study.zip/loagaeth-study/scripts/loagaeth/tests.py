import json, re, random, math
from collections import Counter
D = json.load(open('data/loagaeth/grids.json'))
SQUARE = [f'{n}{s}' for n in range(2, 26) for s in 'ab' if f'{n}{s}' != '25b']
def grid(k):
    rows = [r for r in D['leaves'][k] if 47 <= len(r) <= 51]
    return [r[:49] for r in rows if len(r) >= 49]
G = {k: grid(k) for k in SQUARE}
G = {k: g for k, g in G.items() if len(g) >= 40}
print('usable square leaves:', len(G), 'rows total', sum(len(g) for g in G.values()))
# ---------- lexicon: Loagaeth's own words (dot-separated in the raw rows) ----------
words = Counter()
for k in G:
    for raw in D['raw'][k]:
        t = re.sub(r'[ ?]', '', raw)
        parts = re.split(r'[.,;:]', t)
        for w in parts[1:-1]:                       # skip possibly truncated ends
            w = ''.join(c for c in w.lower() if c.isalpha())
            if len(w) >= 5: words[w] += 1
LEX = set(words)
print('lexicon (internal words, len>=5):', len(LEX), 'e.g.', list(LEX)[:12])
# ---------- readers ----------
def lines_of(g, mode):
    n, m = len(g), len(g[0])
    if mode == 'rows': L = [r for r in g]
    elif mode == 'cols': L = [''.join(g[i][j] for i in range(n)) for j in range(m)]
    elif mode == 'diag':
        L = []
        for d in range(-(n-1), m):
            L.append(''.join(g[i][i+d] for i in range(n) if 0 <= i+d < m))
            L.append(''.join(g[i][m-1-(i+d)] for i in range(n) if 0 <= i+d < m))
    return [x for x in L if len(x) >= 5] + [x[::-1] for x in L if len(x) >= 5]
def hits(g, mode, lex):
    return sum(1 for line in lines_of(g, mode) for w in lex if w in line)
def shuffled(g, rng):   # random cyclic shift of each row: rows intact, vertical alignment destroyed
    out = []
    for r in g:
        s = rng.randrange(len(r)); out.append(r[s:] + r[:s])
    return out
def mi(g, dx, dy):
    pairs = Counter(); a = Counter(); b = Counter()
    for i in range(len(g)):
        for j in range(len(g[i])):
            i2, j2 = i + dy, j + dx
            if 0 <= i2 < len(g) and 0 <= j2 < len(g[i2]):
                x, y = g[i][j], g[i2][j2]; pairs[(x, y)] += 1; a[x] += 1; b[y] += 1
    N = sum(pairs.values())
    return sum(c / N * math.log2(c * N / (a[x] * b[y])) for (x, y), c in pairs.items())
def fullshuffle(g, rng):
    cells = [c for r in g for c in r]; rng.shuffle(cells); m = len(g[0])
    return [''.join(cells[i*m:(i+1)*m]) for i in range(len(g))]
rng = random.Random(1)
# ---------- Test A: neighbour mutual information (structure), with Soyga as positive control ----------
def mi_report(name, gs):
    h = sum(mi(g, 1, 0) for g in gs) / len(gs); v = sum(mi(g, 0, 1) for g in gs) / len(gs)
    sh = sum(mi(fullshuffle(g, rng), 1, 0) for g in gs) / len(gs)
    print(f'{name:22} MI horizontal {h:.3f}  vertical {v:.3f}  shuffled {sh:.3f} bits')
mi_report('Soyga (3 tables)', [t for t in D['soyga'].values() if len(t) > 30 and len(set(map(len,t)))<=2 and [r[:36] for r in t]])
mi_report('Loagaeth leaves', list(G.values()))
# ---------- Test B: do Loagaeth's own words appear vertically/diagonally beyond chance? ----------
for mode in ('rows', 'cols', 'diag'):
    obs = sum(hits(g, mode, LEX) for g in G.values())
    nulls = [sum(hits(shuffled(g, rng), mode, LEX) for g in G.values()) for _ in range(20)]
    mu = sum(nulls) / len(nulls); sd = (sum((x - mu) ** 2 for x in nulls) / len(nulls)) ** .5
    print(f'Test B {mode:5}: observed {obs:6d}   null mean {mu:8.1f} sd {sd:6.1f}   z = {(obs-mu)/sd if sd else float("nan"):.1f}')
