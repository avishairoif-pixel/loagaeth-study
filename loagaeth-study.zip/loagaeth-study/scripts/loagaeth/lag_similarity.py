"""Replication and extension of the reviewer's adjacent-side similarity test (31 Oct). 4-gram repertoire of each
side, counted inside rows only (no gram crosses a row boundary or '?'). Jaccard similarity of side pairs at a
FIXED lag (1, 2, 4, 8 sides), pairs spanning the 8b/9a gap excluded. Trend = Spearman rho between pair position
and similarity; p = one-sided, share of 2,000 random side orders (gap kept in place) with rho >= observed.
Question: does similarity rise only between neighbours (slow drift) or also at lag 4 and 8 (convergence to a
common repertoire)? Controls: Latin and English pseudo-sides (same row counts), and Loagaeth with u->a."""
import sys, re, random, glob
import numpy as np
from scipy.stats import spearmanr
sys.path.insert(0, 'scripts/loagaeth')
exec(open('scripts/loagaeth/markov_orders.py').read().split("print(f'{\"text\":44s}")[0])
GAP = pages.index('9b')          # first side after the gap
def reps(R, n=4): return [set(g for r in R[p] for seg in re.findall(r'[a-z]+', r) for g in (seg[i:i+n] for i in range(len(seg)-n+1))) for p in pages]
def series(S, lag, order):
    out = []
    for k in range(len(order)-lag):
        i, j = order[k], order[k+lag]
        if k < GAP <= k+lag: continue
        a, b = S[i], S[j]; out.append(len(a & b) / len(a | b))
    return out
def rho(v): return spearmanr(range(len(v)), v).correlation
corp2 = {'Latin (Erasmus)': corp['Latin (Erasmus)'], 'English (Casaubon)': corp['English (Casaubon)']}
rng = random.Random(11); N = 1000
print(f'{"text":20s} {"lag":>3s} {"pairs":>5s} {"first third":>11s} {"last third":>10s} {"rho":>6s} {"p (order)":>9s}')
for name, R in corp2.items():
    S = reps(R); idx = list(range(len(pages)))
    for lag in (1, 2, 4, 8):
        v = series(S, lag, idx); r0 = rho(v); t = len(v)//3; ge = 0
        for _ in range(N):
            o = idx[:]; rng.shuffle(o); ge += rho(series(S, lag, o)) >= r0
        print(f'{name:20s} {lag:3d} {len(v):5d} {100*np.mean(v[:t]):10.2f}% {100*np.mean(v[-t:]):9.2f}% {r0:6.3f} {(ge+1)/(N+1):9.4f}')
