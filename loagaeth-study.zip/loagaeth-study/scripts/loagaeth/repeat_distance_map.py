"""Diagnostic (reviewer, 31 Oct): WHERE is the excess repetition of the test block (21a-25a) relative to the two
generators of markov_tables.py (G-M: Markov order 3, alpha 10) and markov_cache_tables.py (G-C: + cache,
lam 0.2, memory 8000; parameters as chosen on dev)? Descriptive, no new model is fitted.
For every 6-gram occurrence with an earlier occurrence in the test block, the distance to the nearest earlier
occurrence, classified: same row / same side, other row / earlier side. Overlapping repeated 6-grams are merged
into maximal repeated segments (length distribution). Per side: R6 and letter shares.
Real text in both variants (raw; u restored to a in 21a, 23a-24b); 50 synthetic blocks per generator."""
import sys
sys.path.insert(0, 'scripts/loagaeth')
src = open('scripts/loagaeth/markov_cache_tables.py').read()
exec(src.split('K0, A0 = 3, 10.0')[0])
K0, A0, LAM, BB = 3, 10.0, 0.2, 8000
trR = [r for p in TR for r in rows[p]]; dvR = [r for p in DEV for r in rows[p]]
M = CM(K0, A0).fit(trR + dvR); seed = ''.join(side_text(rows[p]) for p in DEV)
exec('def gen_block' + src.split('def gen_block')[1].split('rng = np.random.default_rng(1584)')[0])
def gen_markov(real_sides, rng): return [[M.gen(r, rng) for r in R] for R in real_sides]
def stream(sides):
    """letters with (side, row) labels; '?' removed"""
    L, S, R = [], [], []
    for si, side in enumerate(sides):
        for ri, r in enumerate(side):
            for c in r:
                if c.isalpha(): L.append(c); S.append(si); R.append((si, ri))
    return ''.join(L), S, R
BINS = [('same row', None), ('same side, 1-6 rows back', None), ('same side, >6 rows back', None), ('previous side', None), ('2+ sides back', None)]
def profile(sides, n=6):
    t, S, R = stream(sides); last = {}; cnt = [0]*5; covered = [0]*len(t)
    for i in range(len(t)-n+1):
        g = t[i:i+n]
        if g in last:
            j = last[g]
            if R[j] == R[i]: b = 0
            elif S[j] == S[i]: b = 1 if R[i][1] - R[j][1] <= 6 else 2
            else: b = 3 if S[i] - S[j] == 1 else 4
            cnt[b] += 1
            for k in range(i, i+n): covered[k] = 1
        last[g] = i
    segs, run = [], 0
    for c in covered + [0]:
        if c: run += 1
        elif run: segs.append(run); run = 0
    per = 1000 / len(t)
    return [c*per for c in cnt], segs, len(t)
def seglen(segs):
    return [sum(1 for s in segs if lo <= s <= hi) for lo, hi in ((6, 7), (8, 10), (11, 15), (16, 999))]
def side_stats(sides):
    out = []
    for side in sides:
        t = side_text(side); out.append((rep(t[:2400]) if len(t) >= 400 else float('nan'), *(t.count(c)/len(t) for c in 'aueo')))
    return out
rng = np.random.default_rng(7)
for variant in ('raw', 'u restored to a'):
    real_sides = [[(r.replace('u', 'a') if (variant != 'raw' and p in REG) else r) for r in rows[p]] for p in TE]
    Gm = [gen_markov(real_sides, rng) for _ in range(50)]; Gc = [gen_block(real_sides, rng) for _ in range(50)]
    print(f'\n================ {variant} ================')
    pr = profile(real_sides); pm = [profile(g) for g in Gm]; pc = [profile(g) for g in Gc]
    print('repeated 6-gram occurrences per 1000 letters, by distance to the nearest earlier occurrence')
    print(f'{"distance class":28s} {"real":>7s} {"G-M median [range]":>22s} {"G-C median [range]":>22s}')
    for b, (nm, _) in enumerate(BINS):
        vm = [x[0][b] for x in pm]; vc = [x[0][b] for x in pc]
        print(f'{nm:28s} {pr[0][b]:7.1f} {np.median(vm):8.1f} [{min(vm):4.1f}-{max(vm):4.1f}] {np.median(vc):8.1f} [{min(vc):4.1f}-{max(vc):4.1f}]')
    print('maximal repeated segments (merged overlapping 6-grams), count by length in letters')
    print(f'{"length":10s} {"real":>6s} {"G-M median":>11s} {"G-C median":>11s}')
    for k, lab in enumerate(('6-7', '8-10', '11-15', '16+')):
        print(f'{lab:10s} {seglen(pr[1])[k]:6d} {np.median([seglen(x[1])[k] for x in pm]):11.1f} {np.median([seglen(x[1])[k] for x in pc]):11.1f}')
    print(f'longest repeated segment: real {max(pr[1])}, G-M max over 50 {max(max(x[1]) for x in pm)}, G-C max over 50 {max(max(x[1]) for x in pc)}')
    print('per side: R6 (first 2400 letters) and shares of a, u, e, o; synthetic = G-C median')
    sr = side_stats(real_sides); sc = [side_stats(g) for g in Gc]
    for i, p in enumerate(TE):
        med = [np.median([s[i][j] for s in sc]) for j in range(5)]
        print(f'  {p:4s} R6 real {sr[i][0]:.3f} / G-C {med[0]:.3f}   a {sr[i][1]:.3f}/{med[1]:.3f}  u {sr[i][2]:.3f}/{med[2]:.3f}  e {sr[i][3]:.3f}/{med[3]:.3f}  o {sr[i][4]:.3f}/{med[4]:.3f}')
