"""Re-run Zubair (2026) paper 1, 'Directional Reading Traversal', on the REAL leaf 2a
(Peterson's transcription, which matches Zubair's own grid in CSV3b 109/109),
instead of the demo file. Vocabulary: the 94 items that appear in Zubair's file
(his full 264-entry list is not published in the package). Null: 300 random
shuffles of the same 2,401 letters."""
import csv, json, random
from collections import Counter
P = json.load(open('data/loagaeth/grids.json'))['leaves']['2a']
G = [r[:49].upper() for r in P if len(r) >= 49]
demo = list(csv.DictReader(open('data/zubair/loagaeth_matches_T1_demo.csv')))
TIER = {}
for r in demo: TIER.setdefault(r['matched_word'], r['word_source'])
VOCAB = sorted(TIER)
D8 = {'left_right': (0, 1), 'right_left': (0, -1), 'top_bottom': (1, 0), 'bottom_top': (-1, 0),
      'diagonal_down_right': (1, 1), 'diagonal_down_left': (1, -1), 'diagonal_up_right': (-1, 1), 'diagonal_up_left': (-1, -1)}
def lines(g, d):
    dr, dc = D8[d]; n = len(g); out = []
    starts = {(i, j) for i in range(n) for j in range(49) if not (0 <= i - dr < n and 0 <= j - dc < 49)}
    for i, j in starts:
        s = ''
        while 0 <= i < n and 0 <= j < 49: s += g[i][j]; i += dr; j += dc
        out.append(s)
    return out
def count(g, vocab=VOCAB):
    per = Counter(); words = Counter()
    for d in D8:
        for s in lines(g, d):
            for w in vocab:
                k = s.count(w)
                if k: per[d] += k; words[w] += k
    return per, words
per, words = count(G)
tot = sum(per.values())
print(f'REAL leaf 2a: {tot} matches, {len(words)} distinct words')
for d, c in per.most_common(): print(f'   {d:22} {c:4}  ({c/tot:.1%})')
long = sorted((w for w in words if len(w) >= 5), key=len, reverse=True)
print('   words of 5+ letters found:', [(w, words[w]) for w in long])
rng = random.Random(11); cells = [c for r in G for c in r]; nulls = []; nullper = Counter(); nlong = []
for _ in range(300):
    rng.shuffle(cells); S = [''.join(cells[i*49:(i+1)*49]) for i in range(len(G))]
    p, w = count(S); nulls.append(sum(p.values())); nullper.update(p); nlong.append(sum(1 for x in w if len(x) >= 5))
mu = sum(nulls) / len(nulls); sd = (sum((x - mu) ** 2 for x in nulls) / len(nulls)) ** .5
print(f'SHUFFLED grids: mean {mu:.1f} matches (sd {sd:.1f});  real is z = {(tot-mu)/sd:.1f};  shuffles with >= real: {sum(x>=tot for x in nulls)}/300')
print('   shuffled share left_right: {:.1%}'.format(nullper['left_right'] / sum(nullper.values())))
print(f'   distinct 5+ letter words: real {len(long)} vs shuffled mean {sum(nlong)/len(nlong):.2f} (max {max(nlong)})')
