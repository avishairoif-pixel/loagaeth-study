"""Next rung after generator_joint.py (stationary letter models cannot produce burstiness, z ~0, while
Loagaeth leaf 1 has 9.0). G3 = letter model (order 4 w.p. lam else 3, space = symbol) + a production memory:
with prob c the next words are a copied run (geometric length, mean m) from the last 300 output words.
No lexicon given in advance, no syntax, no semantics. Parameters (lam, c, m) calibrated on the FIRST half only,
on three quantities that are not among the tested ones: type/token, local word repetition (share of tokens
already used in the previous 100 tokens), mean word length. Tested on the SECOND half with the same joint rule
as generator_joint.py (real value inside the 5-95% range of 30 texts, on all six measures).
Controls: the same calibration and test on Latin and English samples."""
import sys, random, statistics
sys.path.insert(0, 'scripts/loagaeth')
exec(open('scripts/loagaeth/generator_joint.py').read().split('rng = random.Random(31)')[0])
def g3(tm, lam, c, m, n, rng, B=300):
    """letter state is continuous across words; after a copied run the context = the end of the copied text"""
    t, M = tm; out = []; st = rng.randrange(len(t)-4); ctx = t[st:st+4]; cur = ''
    while len(out) < n:
        if out and not cur and rng.random() < c:
            L = 1
            while rng.random() > 1/m: L += 1
            j = rng.randrange(max(0, len(out)-B), len(out)); run = out[j:j+L]; out += run
            ctx = (' ' + ' '.join(out[-3:]) + ' ')[-4:]; continue
        d = M[4].get(ctx) if rng.random() < lam else None
        if not d: d = M[3].get(ctx[1:])
        if not d: st = rng.randrange(len(t)-4); ctx = t[st:st+4]; cur = ''; continue
        ch = rng.choices(list(d), list(d.values()))[0]; ctx = ctx[1:] + ch
        if ch == ' ':
            if cur: out.append(cur); cur = ''
        else: cur += ch
    return out[:n]
def localrep(seq, back=100): return sum(seq[i] in seq[max(0, i-back):i] for i in range(len(seq))) / len(seq)
def cal(seq): return (len(set(seq))/len(seq), localrep(seq), statistics.mean(map(len, seq)))
rng = random.Random(41)
src = {'Loagaeth leaf 1': LOA}
for name, corp in (('Latin (Erasmus)', lat), ('English (Casaubon)', eng)):
    s0 = rng.randrange(0, len(corp) - len(LOA)); src[name] = corp[s0:s0+len(LOA)]
for name, ws in src.items():
    A, B = ws[:len(ws)//2], ws[len(ws)//2:]; tm = models(A); tA = cal(A); sc = (0.05, 0.05, 0.3)
    best = None
    for lam in (0, .3, .6, .9):
        for c in (0, .03, .06, .1, .15, .2, .3):
            for m in (1, 1.5, 2.5):
                v = [cal(g3(tm, lam, c, m, len(A), rng)) for _ in range(2)]
                v = [statistics.mean(x[i] for x in v) for i in range(3)]
                d = sum(((v[i]-tA[i])/sc[i])**2 for i in range(3))
                if best is None or d < best[0]: best = (d, lam, c, m, v)
    _, lam, c, m, v = best
    print(f'\n=== {name}: fitted lam={lam}, c={c}, m={m}; first half target tt/localrep/len = {tA[0]:.2f}/{tA[1]:.2f}/{tA[2]:.2f}, fitted {v[0]:.2f}/{v[1]:.2f}/{v[2]:.2f}')
    G = [meas(g3(tm, lam, c, m, len(B), rng), rng) for _ in range(30)]; real = meas(B, rng)
    print(f'{"measure":12s} {"real":>8s} {"gen median":>11s} {"gen 5-95%":>18s}  inside'); ok = True
    for i, nm in enumerate(NAMES):
        s = sorted(g[i] for g in G); lo, hi = s[1], s[-2]; ins = lo <= real[i] <= hi; ok &= ins
        print(f'{nm:12s} {real[i]:8.3f} {statistics.median(s):11.3f} {lo:8.3f}..{hi:8.3f}  {"yes" if ins else "NO"}')
    print('-> G3 reproduces ALL measures' if ok else '-> G3 fails on at least one measure')
