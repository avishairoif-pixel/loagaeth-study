"""Lexical similarity of Loagaeth to Hebrew, Persian, Arabic and English (as a reference).

Semitic and Persian script do not write most vowels, and Kelley's Latin spelling is uncertain, so
words are compared by CONSONANT SKELETON, using coarse sound classes:
  P = b p f ph      K = c k q g ch kh gh      T = t d th      S = s z sh ts j (and affricates)
  L, M, N, R kept;  dropped = vowels, h, glides, aleph/ayin and other gutturals;  x = K S
For each language: the share of Loagaeth word skeletons (3 and 4 consonants) that also exist as
skeletons among that language's 5,000 most frequent words. The same share is computed for 20
control lexicons (letter-trigram pseudo-words with Loagaeth's own sound habits). Only an EXCESS
over the controls points to shared vocabulary rather than shared sound patterns.

Limitations: word lists are modern (wordfreq), not Biblical Hebrew or early-modern Persian;
Proto-Sinaitic is excluded because only a handful of its words are securely read.
Run from the project root."""
import io, contextlib, re
from wordfreq import top_n_list
src = open('scripts/loagaeth/morphology.py').read(); head = src.split("print(f'Real lexicon:")[0]

def latin_skel(w):
    w = w.lower()
    for a, b in (('ph', 'P'), ('th', 'T'), ('ch', 'K'), ('sh', 'S'), ('kh', 'K'), ('gh', 'K'), ('ts', 'S'), ('x', 'KS')):
        w = w.replace(a, b)
    m = {'b': 'P', 'p': 'P', 'f': 'P', 'c': 'K', 'k': 'K', 'q': 'K', 'g': 'K', 't': 'T', 'd': 'T',
         's': 'S', 'z': 'S', 'j': 'S', 'l': 'L', 'm': 'M', 'n': 'N', 'r': 'R'}
    return ''.join(m.get(c, c if c in 'PKTS' else '') for c in w)
GRK = {'β':'P','γ':'K','δ':'T','ζ':'S','θ':'T','κ':'K','λ':'L','μ':'M','ν':'N','ξ':'KS','π':'P','ρ':'R','σ':'S','ς':'S','τ':'T','φ':'P','χ':'K','ψ':'PS'}
HEB = {'ב': 'P', 'ג': 'K', 'ד': 'T', 'ז': 'S', 'ט': 'T', 'כ': 'K', 'ך': 'K', 'ל': 'L', 'מ': 'M', 'ם': 'M', 'נ': 'N', 'ן': 'N',
       'ס': 'S', 'פ': 'P', 'ף': 'P', 'צ': 'S', 'ץ': 'S', 'ק': 'K', 'ר': 'R', 'ש': 'S', 'ת': 'T'}
PER = {'ب': 'P', 'پ': 'P', 'ف': 'P', 'ت': 'T', 'ط': 'T', 'د': 'T', 'ث': 'S', 'س': 'S', 'ص': 'S', 'ش': 'S', 'ز': 'S', 'ذ': 'S',
       'ض': 'S', 'ظ': 'S', 'ژ': 'S', 'ج': 'S', 'چ': 'S', 'ک': 'K', 'ك': 'K', 'گ': 'K', 'ق': 'K', 'غ': 'K', 'خ': 'K',
       'ل': 'L', 'م': 'M', 'ن': 'N', 'ر': 'R'}
def script_skel(w, table): return ''.join(table.get(c, '') for c in w)
LANGS = {
    'Hebrew':  {script_skel(w, HEB) for w in top_n_list('he', 5000)},
    'Aramaic': {script_skel(w, HEB) for w in open('data/aramaic/biblical_aramaic_words.txt').read().split()},
    'Persian': {script_skel(w, PER) for w in top_n_list('fa', 5000)},
    'Arabic':  {script_skel(w, PER) for w in top_n_list('ar', 5000)},
    'English': {latin_skel(w) for w in top_n_list('en', 5000) if w.isalpha()},
    'German':  {latin_skel(w.replace('sch','sh')) for w in top_n_list('de', 5000) if w.isalpha()},
    'Greek':   {script_skel(w.lower(), GRK) for w in top_n_list('el', 5000)},
    'Latin':   {latin_skel(w) for w in open('data/latin/latin_top5000.txt').read().split()},
    'Dutch':   {latin_skel(w.replace('sch','sk')) for w in top_n_list('nl', 5000) if w.isalpha()},
}
def coverage(lexicon, langset, k):
    sk = [latin_skel(w) for w in lexicon]; sk = [s for s in sk if len(s) == k]
    return sum(1 for s in sk if s in langset) / len(sk), sk
results = {}
for seed in range(20):
    g = {}
    with contextlib.redirect_stdout(io.StringIO()): exec(head.replace('random.Random(42)', f'random.Random({seed})'), g)
    for L, S in LANGS.items():
        for k in (3, 4):
            if seed == 0: results[(L, k, 'real')] = coverage(g['words'], S, k)[0]
            results.setdefault((L, k, 'ctrl'), []).append(coverage(g['control'], S, k)[0])
print('Share of Loagaeth consonant skeletons found in each language (top 5,000 words)\n')
print(f'{"language":9} {"skeleton":9} {"Loagaeth":>9} {"controls (mean, range)":>26} {"z":>6}')
for L in LANGS:
    for k in (3, 4):
        r = results[(L, k, 'real')]; c = results[(L, k, 'ctrl')]; mu = sum(c) / len(c); sd = max((sum((x - mu) ** 2 for x in c) / len(c)) ** .5, 1e-9)
        print(f'{L:9} {k} cons.   {r:9.1%} {mu:12.1%} ({min(c):.1%}-{max(c):.1%}) {(r-mu)/sd:+6.1f}')
