"""Search all real square Loagaeth leaves (2a-25a) for runs of consecutive alphabet letters
in all 8 directions, against a shuffled control. Run from the project root."""
import json, random
from collections import Counter
D = json.load(open('data/loagaeth/grids.json'))['leaves']
A = 'abcdefghiklmnopqrstuxyz'; pos = {c: i for i, c in enumerate(A)}
def runs(s):
    out, cur = [], 1
    for a, b in zip(s, s[1:]):
        if a in pos and b in pos and (pos[b] - pos[a]) % 23 == 1: cur += 1
        else: out.append(cur); cur = 1
    return out + [cur]
def lines(g):
    n = len(g); L = list(g) + [''.join(g[i][j] for i in range(n)) for j in range(49)]
    for d in range(-(n-1), 49):
        L.append(''.join(g[i][i+d] for i in range(n) if 0 <= i+d < 49))
        L.append(''.join(g[i][48-i-d] for i in range(n) if 0 <= 48-i-d < 49))
    return L + [x[::-1] for x in L]
real, null, rng = Counter(), Counter(), random.Random(1)
for k in [f'{n}{s}' for n in range(2, 26) for s in 'ab']:
    g = [r[:49] for r in D.get(k, []) if len(r) >= 49]
    if len(g) < 40: continue
    for x in lines(g): real.update(r for r in runs(x) if r >= 3)
    c = [ch for r in g for ch in r]; rng.shuffle(c)
    for x in lines([''.join(c[i*49:(i+1)*49]) for i in range(len(g))]): null.update(r for r in runs(x) if r >= 3)
print('alphabet runs (length: count), all 8 directions, 45 leaves')
print('  real    :', dict(sorted(real.items()))); print('  shuffled:', dict(sorted(null.items())))
