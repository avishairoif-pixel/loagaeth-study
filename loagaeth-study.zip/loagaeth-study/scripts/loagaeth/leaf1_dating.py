"""Date the words of leaf 1a by locating them in Dee's diary (Whitby 1982 vol. 2, OCR /home/claude/whit/w2.txt,
the Sl. 3188 dictation sessions). Distinctive words (>=6 letters, once in leaf 1) are searched as tokens in the
diary between lines 12300 and 14960; each hit takes the last date header above it."""
import sys, re, bisect, statistics
sys.path.insert(0, 'scripts/loagaeth')
exec(open('scripts/loagaeth/lexicon.py').read().split('# (B)')[0])
L = leaf1; from collections import Counter; C = Counter(L)
W = open('/home/claude/whit/w2.txt', errors='replace').read().split('\n')
heads = []
for i in range(12000, 14960):
    m = re.search(r'(Martij|Marcij|Aprilis)\s*\.?\s*(\d+)', W[i])
    if m: heads.append((i, f'{m.group(1)[:3]} {m.group(2)}'))
tok = {}
for i in range(12300, 14960):
    for t in re.findall(r'[a-z]+', W[i].lower()): tok.setdefault(t, []).append(i)
hl = [h[0] for h in heads]
rows = []
for k, w in enumerate(L):
    if len(w) >= 6 and C[w] == 1 and w in tok and len(tok[w]) == 1:
        ln = tok[w][0]; j = bisect.bisect_right(hl, ln) - 1
        rows.append((k, w, ln + 1, heads[j][1] if j >= 0 else 'before first header'))
print('date headers found:', heads)
print(f'\n{len(rows)} leaf-1 words located (word index, word, diary line, last date header above):')
for r in rows[::max(1, len(rows)//40)]: print('  ', r)
b = L.index('oxar')
mono = sum(rows[i][2] < rows[i+1][2] for i in range(len(rows)-1)) / max(1, len(rows)-1)
print(f'\nshare of consecutive located words in increasing diary order: {mono:.2f}; 1b starts at word {b}')

# robust session boundaries: a date label is trusted only if the diary line lies between the neighbouring
# trusted lines (drops OCR hits on ordinary English words); the false header 'Mar 24' (a margin cross-reference) is ignored
rows = [r for r in rows if r[3] != 'Mar 24' and r[3] != 'before first header' or r[0] < 80]
good = [r for i, r in enumerate(rows) if 0 < i < len(rows)-1 and rows[i-1][2] <= r[2] <= rows[i+1][2]]
sess = {}
for k, w, ln, d in good: sess.setdefault(d, []).append(k)
print('\nsessions (word-index range of located words):')
for d, ks in sess.items(): print(f'  {d:20s} words {min(ks)}..{max(ks)}  (n located = {len(ks)})')
