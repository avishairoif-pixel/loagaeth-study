"""Attempt to undo a transposition in the leaf 7b block (Peterson lines 1344-1349, 1351).

Rules fixed IN ADVANCE:
  * Ciphers tried: rail fence (2-12 rails); columnar transposition with a keyword order
    (2-12 columns, column order found by hill-climbing); both read off as rows or as columns.
  * Score: English letter-quadgram log-likelihood per letter, from Casaubon 1659 (early-modern English),
    with Loagaeth's letters mapped to modern use (v as u where it stands between consonants is NOT
    guessed; the text is scored as it stands).
  * Positive control: an English passage of the same length is encrypted with a random columnar key;
    the solver must recover it.
  * Negative control: the same search on the same letters shuffled at random (30 shuffles).
    A result only counts if it beats the BEST negative control clearly.
Run from project root."""
import re, math, random, itertools
from collections import Counter
L = open('data/loagaeth/peterson_sl3189.txt', encoding='utf-8', errors='replace').read().split('\n')
ROWS = [L[i - 1] for i in (1344, 1345, 1346, 1347, 1348, 1349, 1351)]
BLOCK = ''.join(re.sub(r'[^a-z]', '', r.lower()) for r in ROWS)
import html
_raw = open('/home/claude/z/loagaeth_research/01_primary_sources/casaubon_1659.txt', errors='replace').read()
_raw = re.sub(r'(?is)<(script|style)[^>]*>.*?</\1>', ' ', _raw); _raw = re.sub(r'(?s)<[^>]+>', ' ', html.unescape(_raw))
_raw = _raw[_raw.find('former  Ages'):]                     # start of Casaubon's own prose (skip archive.org page chrome)
eng = re.sub(r'[^a-z]', '', _raw.lower())
Q = Counter(eng[i:i+4] for i in range(len(eng) - 3)); NQ = sum(Q.values()); FLOOR = math.log10(0.01 / NQ)
QL = {k: math.log10(v / NQ) for k, v in Q.items()}
def score(t): return sum(QL.get(t[i:i+4], FLOOR) for i in range(len(t) - 3)) / (len(t) - 3)
# ---- ciphers ----
def rail_decrypt(c, r):
    n = len(c); pat = [min(i % (2 * r - 2), 2 * r - 2 - i % (2 * r - 2)) for i in range(n)] if r > 1 else [0] * n
    idx = sorted(range(n), key=lambda i: (pat[i], i)); out = [''] * n
    for ch, i in zip(c, idx): out[i] = ch
    return ''.join(out)
def col_decrypt(c, order):            # plaintext written in rows of k, ciphertext = columns read in `order`
    k = len(order); n = len(c); rows = math.ceil(n / k); full = n % k or k
    lens = [rows if j < full else rows - 1 for j in range(k)]; cols, p = {}, 0
    for j in order: cols[j] = c[p:p + lens[j]]; p += lens[j]
    return ''.join(cols[j][i] for i in range(rows) for j in range(k) if i < len(cols[j]))
def col_encrypt(pt, order):
    k = len(order); return ''.join(pt[j::k] for j in order)
def climb(c, k, rng, iters=1500, restarts=6):
    best_s, best_o = -1e9, None
    for _ in range(restarts):
        o = list(range(k)); rng.shuffle(o); s = score(col_decrypt(c, o))
        for _ in range(iters):
            a, b = rng.sample(range(k), 2); o2 = o[:]; o2[a], o2[b] = o2[b], o2[a]
            if rng.random() < .3: i, j = sorted(rng.sample(range(k), 2)); o2 = o[:i] + o[i:j+1][::-1] + o[j+1:]
            s2 = score(col_decrypt(c, o2))
            if s2 >= s: o, s = o2, s2
        if s > best_s: best_s, best_o = s, o
    return best_s, best_o
def solve(c, seed=0):
    rng = random.Random(seed); best = (-1e9, '', '')
    for r in range(2, 13):
        t = rail_decrypt(c, r); s = score(t)
        if s > best[0]: best = (s, f'rail fence {r}', t)
    for k in range(2, 13):
        s, o = climb(c, k, rng)
        if s > best[0]: best = (s, f'columnar k={k} order {o}', col_decrypt(c, o))
    return best
VARIANTS = {
  'rows 16-21 + 23, as written': BLOCK,
  'rows 16-21 + 23, v->u between consonants': re.sub(r'(?<=[^aeiouy])v(?=[^aeiouy])', 'u', BLOCK),
  'core rows 17-21 only': ''.join(re.sub(r'[^a-z]', '', L[i-1].lower()) for i in (1345,1346,1347,1348,1349)),
}
if __name__ == '__main__':
    rng = random.Random(7)
    print(f'block: {len(BLOCK)} letters')
    print(f'reference scores: real English {score(eng[9000:9000+len(BLOCK)]):.3f} | block as written {score(BLOCK):.3f}')
    # positive control
    pt = eng[20000:20000 + len(BLOCK)]; key = list(range(8)); rng.shuffle(key); ct = col_encrypt(pt, key)
    pc = solve(ct, 1); print(f'POSITIVE CONTROL (English, columnar key {key}): recovered score {pc[0]:.3f} via {pc[1]}\n   {pc[2][:90]}')
    # the block
    for name, c in VARIANTS.items():
        for lab, cc in (('forward', c), ('reversed', c[::-1])):
            rb = solve(cc, 2); print(f'BLOCK [{name}, {lab}, {len(cc)} letters]: best {rb[0]:.3f} via {rb[1]}\n   {rb[2][:120]}')
    # negative control
    neg = []
    for t in range(30):
        l = list(BLOCK); random.Random(100 + t).shuffle(l); neg.append(solve(''.join(l), 3 + t)[0])
    print(f'NEGATIVE CONTROL (block letters shuffled, 30x): best scores mean {sum(neg)/len(neg):.3f}, max {max(neg):.3f}')
