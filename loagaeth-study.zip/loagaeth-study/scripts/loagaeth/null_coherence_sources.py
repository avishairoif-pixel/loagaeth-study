"""Where does Loagaeth's word-order information come from? (follow-up to null_coherence.py)
(a) the word pairs that recur most above chance; (b) sound-chaining: do adjacent words share sounds
(same first letter / same last two letters / rhyme) more than chance, compared with coherent texts?
Sound-chaining (assonance, alliteration) is a known trait of glossolalia and would create order information
without syntax."""
import re, sys, random, statistics
from collections import Counter
exec(open('scripts/loagaeth/null_coherence.py').read().split('def mi(seq)')[0])
rng = random.Random(9)
def pairs_report(seq, top=20):
    c = Counter(seq); n = len(seq); bi = Counter(zip(seq, seq[1:]))
    rows = sorted(((v - c[a]*c[b]/n, v, c[a]*c[b]/n, a, b) for (a, b), v in bi.items() if v >= 3), reverse=True)[:top]
    for ex, v, e, a, b in rows: print(f'   {a} {b}: {v} times (chance {e:.1f})')
    rep = sum(v for v in bi.values() if v >= 2) / (n - 1)
    print(f'   share of adjacent pairs that recur: {rep:.3f}')
print('(a) Loagaeth leaf 1, recurring pairs most above chance:'); pairs_report(LOA)
def chain(seq):
    f = sum(a[0] == b[0] for a, b in zip(seq, seq[1:])) / (len(seq) - 1)
    e = sum(len(a) > 1 and len(b) > 1 and a[-2:] == b[-2:] for a, b in zip(seq, seq[1:])) / (len(seq) - 1)
    return f, e
def chain_z(seq, k=60):
    f0, e0 = chain(seq); fs, es = [], []
    for _ in range(k):
        s = seq[:]; rng.shuffle(s); f, e = chain(s); fs.append(f); es.append(e)
    return (f0 - statistics.mean(fs)) / statistics.pstdev(fs), (e0 - statistics.mean(es)) / statistics.pstdev(es), f0, e0
print('\n(b) sound-chaining between adjacent words, z vs shuffled order (alliteration = same first letter; rhyme = same last 2 letters)')
for name, corp in (('Loagaeth leaf 1', None), ('English (Casaubon)', eng), ('Latin (Erasmus)', lat), ('Hebrew (Genesis)', heb)):
    seqs = [LOA] if corp is None else [corp[s:s+N] for s in (rng.randrange(0, len(corp) - N) for _ in range(5))]
    zs = [chain_z(s) for s in seqs]
    fz = [z[0] for z in zs]; ez = [z[1] for z in zs]
    print(f'   {name:22s} alliteration z {min(fz):5.1f}..{max(fz):5.1f}   rhyme z {min(ez):5.1f}..{max(ez):5.1f}   (rates {zs[0][2]:.3f}, {zs[0][3]:.3f})')
