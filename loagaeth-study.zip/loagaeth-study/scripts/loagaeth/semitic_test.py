"""Is there Semitic-style root-and-pattern morphology in Loagaeth?
Semitic hallmark: a consonantal root (k-t-b) appears in many words that differ only in their vowels
and affixes (kataba, kitab, kutub). Test: group words by their consonant skeleton (vowels removed);
count skeletons carried by 2+ words that differ ONLY in vowels. Compare with 20 control lexicons
(letter-trigram pseudo-words, see morphology.py). Also tests the Arabic definite article al-."""
import io, contextlib
from collections import defaultdict
src = open('scripts/loagaeth/morphology.py').read(); head = src.split("print(f'Real lexicon:")[0]
VOW = set('aeiouy')
def skel(w): return ''.join(c for c in w if c not in VOW)
def vocalic_families(lex, k=3):
    fam = defaultdict(set)
    for w in lex:
        s = skel(w)
        if len(s) == k: fam[s].add(w)
    fams = {s: ws for s, ws in fam.items() if len(ws) >= 2}
    return len(fams), sum(len(ws) for ws in fams.values()), fams
def al_prefix(lex):
    S = set(lex); return sum(1 for w in S if w.startswith('al') and len(w) > 4 and w[2:] in S)
real = None; ctrl = []
for seed in range(20):
    g = {}
    with contextlib.redirect_stdout(io.StringIO()): exec(head.replace('random.Random(42)', f'random.Random({seed})'), g)
    if seed == 0:
        W = g['words']; r3 = vocalic_families(W, 3); r2 = vocalic_families(W, 2); real = (r3[0], r3[1], r2[0], al_prefix(W)); ex = r3[2]
    C = g['control']; c3 = vocalic_families(C, 3); c2 = vocalic_families(C, 2); ctrl.append((c3[0], c3[1], c2[0], al_prefix(C)))
names = ['3-consonant roots with 2+ vowel variants', 'words inside those root families', '2-consonant roots with 2+ variants', 'al- + independent word']
for i, n in enumerate(names):
    v = [c[i] for c in ctrl]; mu = sum(v) / 20; sd = max((sum((x - mu) ** 2 for x in v) / 20) ** .5, 0.5)
    print(f'{n:42} REAL {real[i]:4}   CONTROL mean {mu:6.1f} (range {min(v)}-{max(v)})   z = {(real[i]-mu)/sd:+.1f}')
big = sorted(ex.items(), key=lambda x: -len(x[1]))[:12]
print('largest 3-consonant families in Loagaeth:'); [print(f'   {"-".join(s)}: {", ".join(sorted(ws))}') for s, ws in big]
