"""Step 1 of word identification in Liber Loagaeth (Peterson transcription).
Sources of segmented words: (A) leaf 1a/1b, written as running words; (B) leaves 2a-5a, where
the transcription keeps word separators. Outputs a frequency lexicon and tests whether these
words recur in the UNSEGMENTED leaves (6a-25a) more than in shuffled versions of those leaves."""
import re, json, unicodedata, random, csv
from collections import Counter, defaultdict
L = open('data/loagaeth/peterson_sl3189.txt', encoding='utf-8', errors='replace').read().split('\n')
def norm(s): return ''.join(c for c in unicodedata.normalize('NFD', s) if not unicodedata.combining(c)).lower()
# (A) leaf 1: numbered running-text lines between [LEAF 1a] and [LEAF 2a], skipping notes and phonetic readings
s = next(i for i, l in enumerate(L) if l.startswith('[LEAF 1a]')); e = next(i for i, l in enumerate(L) if l.startswith('[LEAF 2a]'))
leaf1 = []
for l in L[s:e]:
    m = re.match(r'^\s*(\d+)\.\s+(.*)$', l)
    if not m or '"' in l or len(m.group(2)) < 60 or re.search(r'pronoun|signif|read|written|Sl\.|fol\.', l, re.I): continue
    leaf1 += [w for w in re.split(r'[\s.,;:!?()\-]+', re.sub(r'\d+', '', norm(m.group(2)))) if re.fullmatch(r'[a-z]+', w)]
# (B) leaves 2a-5a: dot-separated words inside the grids
D = json.load(open('data/loagaeth/grids.json'))
seg = []
for k in ('2a', '2b', '3a', '3b', '4a', '4b', '5a'):
    for r in D['raw'][k]:
        parts = re.split(r'[.,;:]', re.sub(r'[ ?]', '', norm(r)))
        seg += [''.join(c for c in p if c.isalpha()) for p in parts[1:-1]]      # drop row-edge fragments
seg = [w for w in seg if w]
lex = Counter(leaf1) + Counter(seg)
src = defaultdict(set)
for w in leaf1: src[w].add('leaf1')
for w in seg: src[w].add('grids2a-5a')
print(f'tokens: leaf 1 = {len(leaf1)}, grids 2a-5a = {len(seg)};  distinct words = {len(lex)}')
print('most frequent:', lex.most_common(25))
# (C) do these words recur in the unsegmented leaves 6a-25a beyond chance?
later = {k: [r[:49] for r in D['leaves'][k] if len(r) >= 49] for k in D['leaves']
         if k[:-1].isdigit() and 6 <= int(k[:-1]) <= 25 and k != '25b'}
cand = [w for w in lex if len(w) >= 5]
def hits(grids):
    c = Counter()
    for g in grids.values():
        for row in g:
            for w in cand:
                if w in row: c[w] += row.count(w)
    return c
real = hits(later)
rng = random.Random(2); null_tot = Counter()
for _ in range(20):
    sh = {}
    for k, g in later.items():
        cells = [ch for r in g for ch in r]; rng.shuffle(cells); sh[k] = [''.join(cells[i*49:(i+1)*49]) for i in range(len(g))]
    null_tot.update(hits(sh))
null = {w: null_tot[w] / 20 for w in cand}
recurring = sorted([(w, real[w], null[w]) for w in cand if real[w] >= 3 and real[w] > 3 * max(null[w], 0.3)], key=lambda x: -x[1])
print(f'\nwords of 5+ letters from the segmented sources: {len(cand)}')
print(f'occurrences in unsegmented leaves 6a-25a: real {sum(real.values())}  vs shuffled {sum(null.values()):.1f}')
print(f'words recurring >=3 times and >=3x their shuffled rate: {len(recurring)}')
for w, r, n in recurring[:30]: print(f'   {w:14} {r:4}  (shuffled {n:.1f})  sources {sorted(src[w])}')
with open('results/lexicon/loagaeth_lexicon.csv', 'w', newline='') as f:
    wr = csv.writer(f); wr.writerow(['word', 'count_segmented_sources', 'sources', 'count_in_leaves_6a_25a', 'shuffled_expectation'])
    for w, c in lex.most_common(): wr.writerow([w, c, '+'.join(sorted(src[w])), real.get(w, ''), round(null.get(w, 0), 2) if w in null else ''])
