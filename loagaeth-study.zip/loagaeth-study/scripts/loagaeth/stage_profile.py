"""Transmission stages (Peterson; diary 2 Apr 1583, Whitby vol. 2 p. 272): stage 1 = letters named one by one, Dee
writes (leaf 1a, rows 1-2, about the first 100 words); stage 2 = Kelley reads, Dee writes in Roman letters (rest of
1a); stage 3 = Kelley writes himself (1b and the tables). Spelling and letter profile by stage."""
import re, sys, math
from collections import Counter
import pandas as pd
sys.path.insert(0, 'scripts/loagaeth')
exec(open('scripts/loagaeth/lexicon.py').read().split('# (B)')[0])
L = leaf1; b = L.index('oxar')
d = pd.read_csv('results/loagaeth_rows_raw_and_normalized.csv', dtype=str); s = d[d.used_in_sequence_tests == 'yes']
tab = [re.sub(r'[^a-z]', '', r) for r in s.letters_used_first_49]
stages = {'stage 1: 1a words 0-99 (letter by letter, Dee writes)': L[:100], 'stage 2: 1a words 100-2344 (Kelley reads, Dee writes)': L[100:b],
          'stage 3a: 1b (Kelley writes, words)': L[b:], 'stage 3b: tables 2a-25a (Kelley writes)': tab}
DG = ['th', 'ch', 'ph', 'sh', 'gh']
print(f'{"stage":55s} {"letters":>8s} ' + ' '.join(f'{g:>5s}' for g in DG) + f' {"h after c/p/t/s":>15s} {"a%":>5s} {"H1":>5s} {"mean word len":>13s}')
for k, u in stages.items():
    pairs = sum(max(0, len(x)-1) for x in u); t = ''.join(u); c = Counter(t); n = len(t)
    h = t.count('h'); hc = sum(len(re.findall(r'(?<=[cpts])h', x)) for x in u)
    H1 = -sum(v/n*math.log2(v/n) for v in c.values())
    wl = f'{sum(map(len,u))/len(u):.2f}' if 'tables' not in k else '-'
    print(f'{k:55s} {n:8d} ' + ' '.join(f'{1000*sum(x.count(g) for x in u)/pairs:5.1f}' for g in DG) + f' {hc/h:15.2f} {100*c["a"]/n:5.1f} {H1:5.2f} {wl:>13s}')
