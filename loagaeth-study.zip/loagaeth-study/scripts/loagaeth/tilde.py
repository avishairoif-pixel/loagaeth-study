import re, math, random, json
from collections import Counter
L = open('data/loagaeth/peterson_sl3189.txt', encoding='utf-8', errors='replace').read().split('\n')
def mi(seq):
    pairs=list(zip(seq,seq[1:])); P=Counter(pairs); a=Counter(x for x,_ in pairs); b=Counter(y for _,y in pairs); N=len(pairs)
    return sum(c/N*math.log2(c*N/(a[x]*b[y])) for (x,y),c in P.items())
def leafgrid(name, nxt):
    s=next(i for i,l in enumerate(L) if l.upper().startswith(f'[LEAF {name.upper()}]')); e=next(i for i,l in enumerate(L) if l.upper().startswith(f'[LEAF {nxt.upper()}]'))
    rows=[re.sub(r'^\s*\d+\.\s*','',l) for l in L[s:e] if re.match(r'^\s*\d+\.\s*[~/]?[A-Za-z?][~/]',l)]
    st=''.join(c for r in rows for c in r if c.isalpha() or c=='?').lower()
    n=len(st)//49; return [st[i*49:(i+1)*49] for i in range(n)]
def diags(g, sj, parity):
    n=len(g); out=[]
    for d in range(49):
        if d%2!=parity: continue
        out.append(''.join(g[i][(d+sj*i)%49] for i in range(n)))
    return out
rng=random.Random(4)
def shuffled_mi(g):
    c=[x for r in g for x in r]; rng.shuffle(c); return mi(''.join(c))
order=['25b','26a','26b','27a','27b','28a','28b','29a']
res={}
for a,b in zip(order,order[1:]):
    try: g=leafgrid(a,b)
    except StopIteration: continue
    if len(g)<20: print(a,'rows',len(g)); continue
    out={}
    for sj,lab in ((1,'down-right'),(-1,'down-left')):
        for p in (0,1): out[f'{lab} parity{p}']=mi(''.join(diags(g,sj,p)))
    print(f'{a}: {len(g)}x49  shuffled {shuffled_mi(g):.3f} | ' + '  '.join(f'{k} {v:.3f}' for k,v in out.items()))
    res[a]=g
json.dump(res,open('data/loagaeth/tilde_grids.json','w'))
