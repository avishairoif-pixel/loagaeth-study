"""Leaf 1a contains runs like 'ard ardo arga arges argah ax axa' and 'iamles arcasa arcasan arcusma'.
Two measures per 200-word segment: P2 = share of adjacent word pairs sharing their first two letters;
ALPH = share of adjacent pairs in non-decreasing alphabetical order (0.5 expected by chance).
Shuffled baseline: same words, random order. Controls: Latin, English (same length)."""
import sys, random, statistics
sys.path.insert(0, 'scripts/loagaeth')
exec(open('scripts/loagaeth/generator_joint.py').read().split('rng = random.Random(31)')[0])
rng = random.Random(81)
def P2(s): return sum(a[:2] == b[:2] for a, b in zip(s, s[1:])) / (len(s)-1)
def ALPH(s): return sum(a <= b for a, b in zip(s, s[1:])) / (len(s)-1)
def shuf(s): s = s[:]; rng.shuffle(s); return s
b = LOA.index('oxar'); S = 200
print(f'{"start":>5s} {"P2":>6s} {"P2 shuf":>8s} {"ALPH":>6s}  first words')
for s in range(0, len(LOA)-S+1, S):
    seg = LOA[s:s+S]; ps = statistics.mean(P2(shuf(seg)) for _ in range(50))
    print(f'{s:5d} {P2(seg):6.2f} {ps:8.2f} {ALPH(seg):6.2f}  {"[1b] " if s >= b else ""}{" ".join(seg[:7])}')
for name, corp in (('Latin', lat), ('English', eng)):
    v = [corp[x:x+S] for x in (rng.randrange(0, len(corp)-S) for _ in range(30))]
    print(f'{name}: P2 {min(map(P2,v)):.2f}..{max(map(P2,v)):.2f}; ALPH {min(map(ALPH,v)):.2f}..{max(map(ALPH,v)):.2f} (30 segments)')
# longest alphabetical runs in leaf 1
runs, cur = [], [LOA[0]]
for a, w in zip(LOA, LOA[1:]):
    if a <= w: cur.append(w)
    else: runs.append(cur); cur = [w]
runs.append(cur)
print('\nlongest non-decreasing alphabetical runs in leaf 1:')
for r in sorted(runs, key=len, reverse=True)[:6]: print(f'  {len(r)} words @ {LOA.index(r[0])}: {" ".join(r[:14])}{" ..." if len(r) > 14 else ""}')
