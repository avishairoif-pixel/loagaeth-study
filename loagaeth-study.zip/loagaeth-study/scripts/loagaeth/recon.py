import json, math, random
from collections import Counter
D = json.load(open('data/loagaeth/diamonds.json'))
def mi_pairs(pairs):
    P = Counter(pairs); a = Counter(x for x, _ in pairs); b = Counter(y for _, y in pairs); N = len(pairs)
    return sum(c / N * math.log2(c * N / (a[x] * b[y])) for (x, y), c in P.items())
def square(ka, kb):
    A, B = D[ka], D[kb]
    if [len(r) for r in A] != [min(u, 96 - u) + 1 for u in range(1, 96, 2)]: return None
    if [len(r) for r in B] != [min(u, 96 - u) + 1 for u in range(0, 97, 2)]: return None
    S = [[None] * 49 for _ in range(49)]
    for rows, us in ((A, range(1, 96, 2)), (B, range(0, 97, 2))):
        for r, u in zip(rows, us):
            cells = [(i, u - i) for i in range(49) if 0 <= u - i < 49]   # i ascending: j descending
            for (i, j), ch in zip(cells, r): S[i][j] = ch
    return S
rng = random.Random(5)
rows_mi = {'square rows': [], 'square cols': [], 'printed rows (anti-diag)': [], 'main diagonals': [], 'shuffled': []}
n = 0
for k in range(29, 49):
    S = square(f'{k}a', f'{k}b')
    if not S: continue
    n += 1
    g = lambda i, j: S[i][j]
    rows_mi['square rows'].append(mi_pairs([(S[i][j], S[i][j+1]) for i in range(49) for j in range(48)]))
    rows_mi['square cols'].append(mi_pairs([(S[i][j], S[i+1][j]) for i in range(48) for j in range(49)]))
    rows_mi['printed rows (anti-diag)'].append(mi_pairs([(S[i][j], S[i-1][j+1]) for i in range(1, 49) for j in range(48)]))
    rows_mi['main diagonals'].append(mi_pairs([(S[i][j], S[i+1][j+1]) for i in range(48) for j in range(48)]))
    cells = [c for r in S for c in r]; rng.shuffle(cells)
    rows_mi['shuffled'].append(mi_pairs([(cells[t], cells[t+1]) for t in range(len(cells) - 1)]))
print('complete a+b pairs reconstructed into 49x49 squares:', n)
for k, v in rows_mi.items(): print(f'  {k:26} mean MI {sum(v)/len(v):.3f} bits')
json.dump({k: square(f'{k}a', f'{k}b') for k in range(29, 49) if square(f'{k}a', f'{k}b')}, open('data/loagaeth/squares.json', 'w'))
