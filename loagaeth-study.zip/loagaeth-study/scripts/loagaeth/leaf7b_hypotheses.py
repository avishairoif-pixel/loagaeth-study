"""Leaf 7b block: which kind of English does its letter profile match?
 - running English text (a transposition cipher would keep this)
 - English with vowels dropped (abbreviation / shorthand-like writing)
 - FIRST letters of English words (notarikon / acrostic)
 - LAST letters of English words
 and: does the block repeat itself (a repeated prayer)? Run from project root."""
import json, re, random
from collections import Counter
D = json.load(open('data/loagaeth/grids.json'))
rows = [r[:49] for r in D['leaves']['7b'] if len(r) >= 49]
B = ''.join(rows[i] for i in (16, 17, 18, 19, 20)).replace('?', '')      # rows 17-21, the core of the anomaly
txt = open('/home/claude/z/loagaeth_research/01_primary_sources/casaubon_1659.txt', errors='replace').read().lower()
words = re.findall(r'[a-z]+', txt)
AB = 'abcdefghiklmnopqrstuvwxyz'
def prof(t): c = Counter(t); n = len(t); return {x: c[x] / n for x in AB}
def dist(p, q): return sum(abs(p[x] - q[x]) for x in AB) / 2
models = {
    'running English': ''.join(words),
    'English, vowels dropped': re.sub(r'[aeiou]', '', ''.join(words)),
    'first letters of words': ''.join(w[0] for w in words),
    'last letters of words': ''.join(w[-1] for w in words),
    'Loagaeth (rest of book)': ''.join(r for k, v in D['leaves'].items() for r in v if k != '7b'),
}
pb = prof(B)
print(f'core block, rows 17-21: {len(B)} letters; vowels {sum(B.count(v) for v in "aeiou")/len(B):.0%}')
for name, t in models.items():
    print(f'   distance to {name:26} {dist(pb, prof(t)):.2f}')
# repetition inside the block
def repeats(s, k):
    c = Counter(s[i:i+k] for i in range(len(s) - k + 1)); return sum(v - 1 for v in c.values() if v > 1)
rng = random.Random(0)
for k in (4, 5, 6):
    sh = []
    for _ in range(500):
        l = list(B); rng.shuffle(l); sh.append(repeats(''.join(l), k))
    print(f'repeated {k}-letter strings inside the block: {repeats(B, k)}   (same letters shuffled: mean {sum(sh)/len(sh):.1f}, max {max(sh)})')
c = Counter(B[i:i+4] for i in range(len(B) - 3)); print('   repeated 4-grams:', [g for g, v in c.items() if v > 1])
