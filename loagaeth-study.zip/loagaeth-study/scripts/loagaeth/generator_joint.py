"""Steps 1-2 of the ladder: (1) the burstiness measure of null_coherence.py (z of mean variance/mean of word
counts over 10 blocks, words with >=5 occurrences, vs global shuffles) on letter-model generators;
(2) an intermediate generator: interpolated letter model, order 4 with prob lam else order 3 (space = symbol).
lam is calibrated on the FIRST half only, on a quantity that is not tested: the type/token ratio of texts of
first-half length generated from the first half, matched to the first half's own ratio.
Joint test on the SECOND half: windowed order z (w=10), global order z, burstiness z, type/token, word-bigram
reuse, mean word length. Rule fixed in advance: the generator 'reproduces' a measure if the real second half
lies inside the 5-95% range of 30 generated texts; reproduces the text only if it does so on ALL measures.
The same procedure on Latin and English samples (their own first halves) as controls."""
import sys, random, statistics
from collections import Counter, defaultdict
sys.path.insert(0, 'scripts/loagaeth')
exec(open('scripts/loagaeth/generator_ladder.py').read().split('H1, H2 =')[0])
def models(words):
    t = ' ' + ' '.join(words) + ' '; M = {3: defaultdict(Counter), 4: defaultdict(Counter)}
    for k in (3, 4):
        for i in range(len(t)-k): M[k][t[i:i+k]][t[i+k]] += 1
    return t, M
def gen(tm, lam, n, rng):
    t, M = tm; st = rng.randrange(len(t)-4); ctx = t[st:st+4]; out = ''
    while out.count(' ') < n + 2:
        c = M[4].get(ctx) if rng.random() < lam else None
        if not c: c = M[3].get(ctx[1:])
        if not c: st = rng.randrange(len(t)-4); ctx = t[st:st+4]; continue
        ch = rng.choices(list(c), list(c.values()))[0]; out += ch; ctx = ctx[1:] + ch
    return out.split()[1:n+1]
def zburst(seq, rng, k=40):
    b0 = burst(seq); bs = []
    for _ in range(k): s = seq[:]; rng.shuffle(s); bs.append(burst(s))
    sd = statistics.pstdev(bs); return (b0 - statistics.mean(bs)) / sd if sd else float('nan')
def meas(seq, rng):
    return [zwin(seq, 10, rng), zglob(seq, rng), zburst(seq, rng), len(set(seq))/len(seq), repn(seq, 2), statistics.mean(map(len, seq))]
NAMES = ['window z', 'global z', 'burst z', 'type/tok', 'bigr reuse', 'word len']
rng = random.Random(31)
src = {'Loagaeth leaf 1': LOA}
for name, corp in (('Latin (Erasmus)', lat), ('English (Casaubon)', eng)):
    s0 = rng.randrange(0, len(corp) - len(LOA)); src[name] = corp[s0:s0+len(LOA)]
for name, ws in src.items():
    A, B = ws[:len(ws)//2], ws[len(ws)//2:]; tm = models(A); ttA = len(set(A))/len(A)
    best = min(((abs(statistics.mean(len(set(g))/len(g) for g in [gen(tm, lam, len(A), rng) for _ in range(4)]) - ttA), lam)
                for lam in (0, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1.0)))
    lam = best[1]
    G = [meas(gen(tm, lam, len(B), rng), rng) for _ in range(30)]
    real = meas(B, rng)
    print(f'\n=== {name}: lam = {lam} (calibrated on first-half type/token {ttA:.2f}); second half {len(B)} words')
    print(f'{"measure":12s} {"real":>8s} {"gen median":>11s} {"gen 5-95%":>18s}  inside')
    ok = True
    for i, nm in enumerate(NAMES):
        v = sorted(g[i] for g in G); lo, hi = v[1], v[-2]   # 30 texts: 2nd and 29th = approx 5% and 95%
        ins = lo <= real[i] <= hi; ok &= ins
        print(f'{nm:12s} {real[i]:8.3f} {statistics.median(v):11.3f} {lo:8.3f}..{hi:8.3f}  {"yes" if ins else "NO"}')
    print('-> generator reproduces ALL measures' if ok else '-> generator fails on at least one measure')
