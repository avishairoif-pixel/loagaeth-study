"""Loagaeth against recorded glossolalia (Atkins 2014: three native English speakers, IPA, 1-minute samples).
Atkins marks only breath groups, not words, so the comparison is at the level of sounds/letters.
IPA is mapped to plain letters. Features on chunks of 400 letters:
  R6 / R10  local repetition: share of letters covered by a 6- (10-) letter sequence already used in the
            previous 300 letters (glossolalia is described as 'repetition interwoven with diversification', Samarin)
  H1        letter entropy (bits)            H2  entropy of a letter given the previous one
Reference texts: Loagaeth leaf 1 (prose calls), Loagaeth tables 2a-25a, English (Casaubon), Latin (Erasmus)."""
import re, sys, math, json, glob, statistics
from collections import Counter
sys.path.insert(0, 'scripts/loagaeth')
import leaf7b_transposition as T
exec(open('scripts/loagaeth/lexicon.py').read().split('# (B)')[0])
MULTI = [('oʊ', 'o'), ('eɪ', 'e'), ('aɪ', 'ai'), ('dʒ', 'j'), ('tʃ', 'ch'), ('t̚', 't')]
SINGLE = {'ɑ': 'a', 'ʌ': 'u', 'ə': 'e', 'ɪ': 'i', 'ɛ': 'e', 'ɔ': 'o', 'ʊ': 'u', 'æ': 'a', 'ʃ': 'sh', 'ʒ': 'zh', 'ɾ': 'r',
          'ɹ': 'r', 'ŋ': 'ng', 'ð': 'th', 'θ': 'th', 'j': 'y', 'ɡ': 'g', 'ẽ': 'e'}
def ipa2lat(s):
    for a, b in MULTI: s = s.replace(a, b)
    s = ''.join(SINGLE.get(c, c) for c in s)
    return re.sub(r'[^a-z]', '', s)
G = {}
for line in open('data/glossolalia/atkins2014_ipa.txt', encoding='utf-8'):
    k, v = line.rstrip('\n').split('\t'); G.setdefault(k, []).append(ipa2lat(v))
G = {k: ''.join(v) for k, v in G.items()}
def rep(s, n, back=300):
    cov = [0] * len(s)
    for i in range(n, len(s) - n + 1):
        g = s[i:i+n]
        if g in s[max(0, i - back):i + n - 1]:
            for j in range(i, i + n): cov[j] = 1
    return sum(cov) / len(s)
def H1(s): c = Counter(s); n = len(s); return -sum(v/n*math.log2(v/n) for v in c.values())
def H2(s):
    b = Counter(zip(s, s[1:])); u = Counter(s[:-1]); n = len(s) - 1
    return -sum(v/n*math.log2(v/u[a]) for (a, _), v in b.items())
def feats(s): return [rep(s, 6), rep(s, 10), H1(s), H2(s)]
def chunks(s, L=400, k=40):
    step = max(L, (len(s) - L) // k)
    return [s[i:i+L] for i in range(0, len(s) - L + 1, step)][:k]
D = json.load(open('data/loagaeth/grids.json'))
tables = ''.join(r[:49] for k, v in D['leaves'].items() if re.fullmatch(r'(\d+)[ab]', k) and 2 <= int(k[:-1]) <= 25 for r in v if len(r) >= 49)
lat = re.sub(r'[^a-z]', '', ' '.join(open(f, errors='replace').read() for f in sorted(glob.glob('/home/claude/dl_latin/ll/erasmus/*.txt'))).lower())
corp = {'glossolalia Charlie': [G['Charlie'][:400]], 'glossolalia Jill': [G['Jill'][:400]], 'glossolalia Karen': [G['Karen'][:400]],
        'Loagaeth leaf 1 (calls)': chunks(''.join(leaf1)), 'Loagaeth tables 2a-25a': chunks(tables),
        'English (Casaubon)': chunks(T.eng[5000:200000]), 'Latin (Erasmus)': chunks(lat[5000:200000])}
print('glossolalia lengths (letters after mapping):', {k: len(v) for k, v in G.items()})
print(f'\n{"text (400-letter chunks)":28s} {"R6 repetition":>14s} {"R10 repetition":>15s} {"H1":>11s} {"H2":>11s}')
for k, cs in corp.items():
    F = [feats(c) for c in cs]
    def cell(i):
        v = [f[i] for f in F]
        return f'{statistics.median(v):.2f}' if len(v) == 1 else f'{statistics.median(v):.2f} [{min(v):.2f}-{max(v):.2f}]'
    print(f'{k:28s} {cell(0):>14s} {cell(1):>15s} {cell(2):>11s} {cell(3):>11s}')
print('\nexample, Charlie:', G['Charlie'][:160])
