import re, json, math
from collections import Counter, defaultdict
exec(open('scripts/loagaeth/score.py').read().split("rng = random.Random(7)")[0])
L = open('data/loagaeth/peterson_sl3189.txt', encoding='utf-8', errors='replace').read().split('\n')
heads = [(i, l[1:].split(']')[0].split()[1].lower()) for i, l in enumerate(L) if re.match(r'^\[LEAF \d+[ab]\]', l, re.I)]
def parse(leaf):
    k = [n for n, (_, nm) in enumerate(heads) if nm == leaf][0]
    s, e = heads[k][0], heads[k + 1][0]
    rows = [re.sub(r'^\s*\d+\.\s*', '', l.rstrip()) for l in L[s:e] if re.match(r'^\s*\d+\.\s*[~/]?[A-Za-z?]', l) and re.search(r'[~/]', l)]
    # tokenise the continuous stream: marker (~ or / or none) + letter
    grid = []
    carry = ''
    for r in rows:
        r = carry + r; carry = ''
        if r and r[-1] in '~/': carry = r[-1]; r = r[:-1]
        toks = re.findall(r'([~/]?)\s?([A-Za-z?])', r)
        grid.append([(m, c.lower()) for m, c in toks])
    return grid
DIRS = {'rows →': (0, 1), 'cols ↓': (1, 0), 'diag ↘': (1, 1), 'diag ↙': (1, -1)}
def analyse(leaf):
    g = parse(leaf); n = len(g)
    widths = Counter(len(r) for r in g)
    cls = defaultdict(set)
    for i, r in enumerate(g):
        for j, (m, c) in enumerate(r): cls[m or 'plain'].add((i, j))
    print(f'\n{leaf}: {n} rows, widths {widths.most_common(2)}, classes ' + ', '.join(f"'{k}'={len(v)}" for k, v in cls.items()))
    for k, cells in cls.items():
        out = []
        for name, (di, dj) in DIRS.items():
            seqs = []; seen = set()
            for (i, j) in sorted(cells):
                if (i, j) in seen or (i - di, j - dj) in cells: continue
                s = ''; a, b = i, j
                while (a, b) in cells: seen.add((a, b)); s += g[a][b][1]; a += di; b += dj
                if len(s) >= 8: seqs.append(s)
            # also allow stepping by 2 along rows/cols when class is a checkerboard
            sc = [score(x) for x in seqs]
            out.append(f'{name} {sum(sc)/len(sc):+.2f} (n={len(sc)})' if sc else f'{name}   —   ')
        print(f"   class '{k}': " + ' | '.join(out))
for leaf in ('25b', '26a', '26b', '27a', '27b', '28a', '28b'):
    try: analyse(leaf)
    except Exception as ex: print(leaf, 'error', ex)
