"""Leaf 7b block: each 49-letter row read as a 7x7 board, letters moved by chess-like routes.
Run from project root. Uses the quadgram model of leaf7b_transposition.py.

Part 1 FIXED ROUTES (no free parameters, so no overfitting): rows, columns, boustrophedon, diagonals from
each corner (straight and boustrophedon, both orientations, as in the Sigillum names), spirals; each in both
directions (route = reading order, or route = writing order) and reversed. The SAME route is applied to every
row, and the concatenation is scored.
Part 2 FREE PATHS (beam search, one path per row): self-avoiding path through all 49 squares, using
  king  = one step to any of the 8 neighbours,
  pawn  = always one row forward, straight or diagonal, the board wrapping round (a cylinder/torus),
          i.e. exactly the 'forward and diagonal' move.
Controls: positive = English hidden by a random route of the same kind must be recovered;
negative = identical search on the block's own letters shuffled."""
import sys, re, random, statistics
sys.path.insert(0, 'scripts/loagaeth')
from leaf7b_transposition import L, QL, FLOOR, score, eng
N = 7
rows_raw = [re.sub(r'[^a-z]', '', L[i - 1].lower()) for i in (1344, 1345, 1346, 1347, 1348, 1349, 1351)]
ROWS = [r if len(r) == 49 else r + 'x' * (49 - len(r)) for r in rows_raw]   # row 20 has 48 letters: pad one null
print('row lengths:', [len(r) for r in rows_raw])
# ---------- Part 1 ----------
def cell(r, c): return r * N + c
def routes():
    R = {}
    R['rows'] = [cell(r, c) for r in range(N) for c in range(N)]
    R['cols'] = [cell(r, c) for c in range(N) for r in range(N)]
    R['boustro rows'] = [cell(r, c if r % 2 == 0 else N - 1 - c) for r in range(N) for c in range(N)]
    R['boustro cols'] = [cell(r if c % 2 == 0 else N - 1 - r, c) for c in range(N) for r in range(N)]
    for name, f in {'TL': lambda r, c: (r, c), 'TR': lambda r, c: (r, N-1-c), 'BL': lambda r, c: (N-1-r, c), 'BR': lambda r, c: (N-1-r, N-1-c)}.items():
        for orient in (0, 1):
            for bou in (0, 1):
                seq = []
                for d in range(2 * N - 1):
                    diag = [(r, d - r) for r in range(N) if 0 <= d - r < N]
                    if orient: diag = diag[::-1]
                    if bou and d % 2: diag = diag[::-1]
                    seq += [cell(*f(r, c)) for r, c in diag]
                R[f'diag {name} o{orient}{" boustro" if bou else ""}'] = seq
    def spiral(cw):
        top, bot, lef, rig, s = 0, N-1, 0, N-1, []
        while top <= bot and lef <= rig:
            for c in range(lef, rig+1): s.append((top, c))
            for r in range(top+1, bot+1): s.append((r, rig))
            if top < bot:
                for c in range(rig-1, lef-1, -1): s.append((bot, c))
            if lef < rig:
                for r in range(bot-1, top, -1): s.append((r, lef))
            top, bot, lef, rig = top+1, bot-1, lef+1, rig-1
        return s if cw else [(c, r) for r, c in s]
    for cw in (1, 0):
        for name, f in {'TL': lambda r, c: (r, c), 'TR': lambda r, c: (r, N-1-c), 'BL': lambda r, c: (N-1-r, c), 'BR': lambda r, c: (N-1-r, N-1-c)}.items():
            R[f'spiral {name} {"cw" if cw else "ccw"}'] = [cell(*f(r, c)) for r, c in spiral(cw)]
    out = {}
    for k, p in R.items():
        inv = [0] * 49
        for i, x in enumerate(p): inv[x] = i
        for k2, q in ((k + ' read', p), (k + ' write', inv)):
            out[k2] = q; out[k2 + ' rev'] = q[::-1]
    return out
RT = routes()
def apply(rows, p): return ''.join(''.join(r[i] for i in p) for r in rows)
def best_fixed(rows):
    return max((score(apply(rows, p)), k) for k, p in RT.items())
# ---------- Part 2 ----------
def nbrs(moves):
    out = {}
    for x in range(49):
        r, c = divmod(x, N)
        if moves == 'king':
            out[x] = [cell(r+dr, c+dc) for dr in (-1, 0, 1) for dc in (-1, 0, 1) if (dr or dc) and 0 <= r+dr < N and 0 <= c+dc < N]
        else:   # pawn on a torus: one row forward, column -1/0/+1
            out[x] = [cell((r+1) % N, (c+dc) % N) for dc in (-1, 0, 1)]
    return out
NB = {m: nbrs(m) for m in ('king', 'pawn')}
def reach_all(nb, last, used):
    # every unvisited square must still be reachable from the current square through unvisited squares
    todo = 49 - len(used)
    if todo == 0: return True
    seen, st = set(), [y for y in nb[last] if y not in used]
    for y in st: seen.add(y)
    while st:
        x = st.pop()
        for y in nb[x]:
            if y not in used and y not in seen: seen.add(y); st.append(y)
    return len(seen) == todo
def beam(row, moves, B=400):
    nb = NB[moves]; beam_ = [(0.0, (x,), row[x]) for x in range(49)]
    for _ in range(48):
        cand = []
        for s, path, txt in beam_:
            used = set(path)
            for y in nb[path[-1]]:
                if y in used: continue
                t = txt + row[y]
                cand.append((s + (QL.get(t[-4:], FLOOR) if len(t) >= 4 else 0), path + (y,), t))
        if not cand: return None
        cand.sort(key=lambda z: -z[0]); beam_ = []
        for z in cand:
            if reach_all(nb, z[1][-1], set(z[1])): beam_.append(z)
            if len(beam_) == B: break
        if not beam_: return None
    s, p, t = beam_[0]; return s / 46, t
def random_path(moves, rng):
    nb = NB[moves]
    while True:
        p = [rng.randrange(49)]; used = {p[0]}
        while len(p) < 49:
            opts = [y for y in nb[p[-1]] if y not in used]
            if not opts: break
            opts.sort(key=lambda y: (len([z for z in nb[y] if z not in used]), rng.random()))   # Warnsdorff
            p.append(opts[0]); used.add(opts[0])
        if len(p) == 49: return p
def run_free(rows, moves):
    res = [beam(r, moves) for r in rows]
    ok = [x for x in res if x]
    print(f'   ({len(ok)}/{len(rows)} rows completed a full path)')
    return (statistics.mean(x[0] for x in ok) if ok else None), [x[1] for x in ok]
if __name__ == '__main__':
    rng = random.Random(11)
    print(f'\n=== PART 1: fixed routes ({len(RT)} routes, same route on every row) ===')
    s, k = best_fixed(ROWS); print(f'BLOCK: best {s:.3f} via {k}\n   {apply(ROWS, RT[k])[:147]}')
    pt = [eng[30000 + 49*i: 30000 + 49*(i+1)] for i in range(7)]; key = rng.choice(list(RT))
    inv = [0]*49
    for i, x in enumerate(RT[key]): inv[x] = i
    ct = [''.join(r[inv[j]] for j in range(49)) for r in pt]
    s2, k2 = best_fixed(ct); print(f'POSITIVE (English hidden by "{key}"): best {s2:.3f} via {k2}\n   {apply(ct, RT[k2])[:98]}')
    neg = []
    for t in range(300):
        l = list(''.join(ROWS)); random.Random(t).shuffle(l); neg.append(best_fixed([''.join(l[49*i:49*(i+1)]) for i in range(7)])[0])
    neg.sort(); print(f'NEGATIVE (300 shuffles): mean {statistics.mean(neg):.3f}, 99th pct {neg[296]:.3f}, max {neg[-1]:.3f}')
    print(f'   block rank among shuffles: {sum(x >= s for x in neg)} of 300 shuffles score as high or higher')
    for moves in ('pawn', 'king'):
        print(f'\n=== PART 2: free {moves} paths, beam search per row ===')
        ms, txt = run_free(ROWS, moves); print(f'BLOCK: mean per-letter {ms:.3f}')
        for t in txt: print('   ', t)
        pos = []
        for r in pt[:3]:
            p = random_path(moves, rng); c = [''] * 49
            for i, x in enumerate(p): c[x] = r[i]
            pos.append(''.join(c))
        mp, tp = run_free(pos, moves); print(f'POSITIVE (3 English rows hidden by random {moves} paths): mean {mp:.3f}')
        for t in tp: print('   ', t)
        negs = []
        for t in range(5 if moves == 'pawn' else 3):
            l = list(''.join(ROWS)); random.Random(500 + t).shuffle(l)
            negs.append(run_free([''.join(l[49*i:49*(i+1)]) for i in range(7)], moves)[0])
        print(f'NEGATIVE (5 shuffles of the block, all 7 rows each): means {[round(x, 3) for x in negs]}')
