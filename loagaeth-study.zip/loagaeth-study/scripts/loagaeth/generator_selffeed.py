"""G4 = self-feeding letter model: a production that learns from its own recent output (a plausible model of
glossolalic drift: 'repetition interwoven with diversification'). Order-3 letter model (space = symbol): with
prob w the next letter is drawn from the counts of the generator's own last K letters, else from the base
model of the first half. Parameters (w, K) calibrated on the first half only (type/token, local repetition,
word length), tested on the second half with the joint rule. Controls: Latin, English."""
import sys, random, statistics
from collections import Counter, defaultdict, deque
sys.path.insert(0, 'scripts/loagaeth')
exec(open('scripts/loagaeth/generator_cache.py').read().split('rng = random.Random(41)')[0])
def g4(tm, w, K, n, rng):
    t, M = tm; base = M[3]; R = defaultdict(Counter); hist = deque()
    st = rng.randrange(len(t)-3); ctx = t[st:st+3]; out = []; cur = ''
    while len(out) < n:
        d = R.get(ctx) if rng.random() < w else None
        if not d: d = base.get(ctx)
        if not d: st = rng.randrange(len(t)-3); ctx = t[st:st+3]; continue
        ch = rng.choices(list(d), list(d.values()))[0]
        R[ctx][ch] += 1; hist.append((ctx, ch))
        if len(hist) > K:
            a, b = hist.popleft(); R[a][b] -= 1
            if R[a][b] == 0: del R[a][b]
            if not R[a]: del R[a]
        ctx = ctx[1:] + ch
        if ch == ' ':
            if cur: out.append(cur); cur = ''
        else: cur += ch
    return out[:n]
rng = random.Random(51)
src = {'Loagaeth leaf 1': LOA}
for name, corp in (('Latin (Erasmus)', lat), ('English (Casaubon)', eng)):
    s0 = rng.randrange(0, len(corp) - len(LOA)); src[name] = corp[s0:s0+len(LOA)]
for name, ws in src.items():
    A, B = ws[:len(ws)//2], ws[len(ws)//2:]; tm = models(A); tA = cal(A); sc = (0.05, 0.05, 0.3); best = None
    for w in (0, .2, .4, .6, .8, .9):
        for K in (500, 1500, 4000):
            v = [cal(g4(tm, w, K, len(A), rng)) for _ in range(2)]; v = [statistics.mean(x[i] for x in v) for i in range(3)]
            d = sum(((v[i]-tA[i])/sc[i])**2 for i in range(3))
            if best is None or d < best[0]: best = (d, w, K, v)
    _, w, K, v = best
    print(f'\n=== {name}: fitted w={w}, K={K}; first-half target tt/localrep/len {tA[0]:.2f}/{tA[1]:.2f}/{tA[2]:.2f}, fitted {v[0]:.2f}/{v[1]:.2f}/{v[2]:.2f}')
    G = [meas(g4(tm, w, K, len(B), rng), rng) for _ in range(30)]; real = meas(B, rng); ok = True
    print(f'{"measure":12s} {"real":>8s} {"gen median":>11s} {"gen 5-95%":>18s}  inside')
    for i, nm in enumerate(NAMES):
        s = sorted(g[i] for g in G); lo, hi = s[1], s[-2]; ins = lo <= real[i] <= hi; ok &= ins
        print(f'{nm:12s} {real[i]:8.3f} {statistics.median(s):11.3f} {lo:8.3f}..{hi:8.3f}  {"yes" if ins else "NO"}')
    print('-> G4 reproduces ALL measures' if ok else '-> G4 fails on at least one measure')
# within-leaf drift of Loagaeth itself (first vs second half), for the record
A, B = LOA[:len(LOA)//2], LOA[len(LOA)//2:]
print('\nLoagaeth leaf 1, first half vs second half:', [f'{nm} {a:.2f}/{b:.2f}' for nm, a, b in zip(NAMES, meas(A, rng), meas(B, rng))])
