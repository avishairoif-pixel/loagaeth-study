"""Glossolalia signatures: repeated letters and repeated syllables (reduplication) in Loagaeth,
compared with letter-trigram control lexicons and with English (Casaubon 1659)."""
import re, io, contextlib
src = open('scripts/loagaeth/morphology.py').read(); head = src.split("print(f'Real lexicon:")[0]
def stats(text):
    t = re.sub(r'[^a-z]', '', text)
    triple = len(re.findall(r'(.)\1\1', t))                              # same letter 3+ times in a row
    redup = len(re.findall(r'([a-z]{2,3})\1', t))                        # a 2-3 letter chunk repeated immediately
    return 1000 * triple / len(t), 1000 * redup / len(t)
g = {}
with contextlib.redirect_stdout(io.StringIO()): exec(head, g)
real_running = ' '.join(g['leaf1'])                                     # leaf 1 as running text
grid_text = ''.join(r for k, v in g['D']['leaves'].items() if k[:-1].isdigit() and 2 <= int(k[:-1]) <= 25 for r in v)
ctrl = ' '.join(g['control'])
eng = open('/home/claude/z/loagaeth_research/01_primary_sources/casaubon_1659.txt', errors='replace').read().lower()[200000:300000]
for name, t in [('Loagaeth leaf 1', real_running), ('Loagaeth leaves 2a-25b', grid_text), ('control pseudo-words', ctrl), ('English (Casaubon)', eng)]:
    a, b = stats(t); print(f'{name:24} triple letters per 1000: {a:5.2f}   immediate syllable repeats per 1000: {b:5.2f}')
print('examples of reduplication in Loagaeth:', sorted(set(w for w in g['lex'] if re.search(r'([a-z]{2,3})\1', w)))[:25])
