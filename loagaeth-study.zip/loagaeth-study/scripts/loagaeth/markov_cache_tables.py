"""Next rung (reviewer's protocol: 'add a limited recycling component'): the frozen Markov model of
markov_tables.py mixed with a CACHE of the producer's own recent output (a standard cache language model):
P(c|h) = (1-lam) P_markov(c|h) + lam P_cache(c|h), where P_cache uses the continuations of the longest of the
last 4..1 letters that occurs in the last B letters produced. No lexicon, no syntax, no semantics.
lam and B are chosen ONLY by bits/letter on the dev sides (memory = the real text before each dev letter).
Then 200 synthetic test blocks: the memory starts with the last B real letters of the dev block and continues
with the synthetic output. Same battery and same two variants as markov_tables.py."""
import sys
sys.path.insert(0, 'scripts/loagaeth')
exec(open('scripts/loagaeth/markov_tables.py').read().split('rng = np.random.default_rng(1583)')[0])
from collections import Counter, deque
SCRIPT = 'markov_cache_tables'
class Cache:
    def __init__(s, B, seed=''):
        s.B = B; s.mem = deque(); s.C = [dict() for _ in range(5)]
        for c in seed[-B:]: s.push(c)
    def _ctx(s, j):
        return ''.join(list(s.mem)[-j:]) if len(s.mem) >= j else None
    def push(s, c):
        m = s.mem
        for j in range(1, 5):
            if len(m) >= j:
                k = ''.join(m[i] for i in range(len(m)-j, len(m))); s.C[j].setdefault(k, Counter())[c] += 1
        m.append(c); s.hist = getattr(s, 'hist', deque()); s.hist.append([(j, ''.join(m[i] for i in range(len(m)-1-j, len(m)-1)) if len(m)-1 >= j else None) for j in range(1, 5)] + [c])
        if len(m) > s.B:
            m.popleft(); old = s.hist.popleft(); ch = old[-1]
            for j, k in old[:-1]:
                if k is not None:
                    ct = s.C[j][k]; ct[ch] -= 1
                    if ct[ch] <= 0: del ct[ch]
                    if not ct: del s.C[j][k]
    def P(s, tail):
        for j in range(min(4, len(tail)), 0, -1):
            ct = s.C[j].get(tail[-j:])
            if ct:
                v = np.array([ct.get(c, 0) for c in AL], float); return v / v.sum()
        return None
def mix(Mk, cache, h, tail, lam):
    p = Mk.P(h)[0]; q = cache.P(tail) if lam > 0 else None
    return p if q is None else (1-lam)*p + lam*q
def dev_bits(lam, B):
    cache = Cache(B, ''.join(side_text(rows[p]) for p in TR)); Mk = CM(K0, A0).fit(trR); L = n = 0; tail = ''
    for p in DEV:
        for r in rows[p]:
            h = ''
            for c in r:
                if not c.isalpha(): h = ''; continue
                L -= math.log2(mix(Mk, cache, h, tail, lam)[IX[c]]); n += 1
                h = (h + c)[-K0:]; tail = (tail + c)[-4:]; cache.push(c)
    return L / n
K0, A0 = 3, 10.0
trR = [r for p in TR for r in rows[p]]; dvR = [r for p in DEV for r in rows[p]]
grid = sorted((dev_bits(l, B), l, B) for l in (0.0, 0.1, 0.2, 0.3, 0.5) for B in (1000, 3000, 8000))
print('dev bits/letter (best 6):', [(round(b, 3), l, B) for b, l, B in grid[:6]], '| lam=0:', [round(b, 3) for b, l, B in grid if l == 0][:1])
_, LAM, BB = grid[0]
M = CM(K0, A0).fit(trR + dvR); seed = ''.join(side_text(rows[p]) for p in DEV)
def gen_block(real_sides, rng):
    cache = Cache(BB, seed); tail = seed[-4:]; out = []
    for R in real_sides:
        side = []
        for r in R:
            s = []; h = ''; u = rng.random(len(r))
            for i, t in enumerate(r):
                if not t.isalpha(): s.append(t); h = ''; continue
                p = mix(M, cache, h, tail, LAM); cs = np.cumsum(p); c = AL[min(int(np.searchsorted(cs, u[i]*cs[-1])), 25)]
                s.append(c); h = (h + c)[-K0:]; tail = (tail + c)[-4:]; cache.push(c)
            side.append(''.join(s))
        out.append(side)
    return out
rng = np.random.default_rng(1584)
print(f'chosen: Markov order {K0}, alpha {A0}; cache lam {LAM}, memory {BB} letters')
for variant in ('raw', 'u restored to a'):
    real_sides = [[(r.replace('u', 'a') if (variant != 'raw' and p in REG) else r) for r in rows[p]] for p in TE]
    real = battery(real_sides, rng); sims = [battery(gen_block(real_sides, rng), rng) for _ in range(200)]
    _tag = 'raw' if variant == 'raw' else 'u_as_a'
    pd.DataFrame([dict(sim='REAL', **real)] + [dict(sim=i+1, **x) for i, x in enumerate(sims)]).to_csv(f'results/lexicon/sims_{SCRIPT}_{_tag}.csv', index=False)
    print(f'\n=== test block, {variant} (200 synthetic sets) ===')
    print(f'{"measure":7s} {"real":>9s} {"synthetic median":>17s} {"2.5-97.5%":>22s} {"two-sided p":>12s} {"sims >= real":>13s} {"sims <= real":>13s}')
    for m in real:
        v = np.array([s[m] for s in sims]); b = min((v >= real[m]).sum(), (v <= real[m]).sum()); p = min(1.0, 2*(b + 1)/201)
        print(f'{m:7s} {real[m]:9.4f} {np.median(v):17.4f} {np.percentile(v, 2.5):10.4f}..{np.percentile(v, 97.5):9.4f} {p:12.4f} {int((v >= real[m]).sum()):13d} {int((v <= real[m]).sum()):13d}')
