import re, unicodedata, json
lines = open('data/loagaeth/peterson_sl3189.txt', encoding='utf-8', errors='replace').read().split('\n')
def norm(s): return ''.join(c for c in unicodedata.normalize('NFD', s) if not unicodedata.combining(c))
single = re.compile(r'^(?:[A-Za-z?](?:[ .,;:]+|$))+$')
leaf_re = re.compile(r'^\[LEAF (\d+[ab])\]', re.I)
soy = next(i for i,l in enumerate(lines) if l.startswith('[TABLES OF SOYGA]'))
L = {}; cur = None
for l in lines[:soy]:
    m = leaf_re.match(l)
    if m: cur = m.group(1).lower(); L[cur] = []; continue
    t = norm(l.strip())
    if cur and t and single.match(t):
        L[cur].append(''.join(c for c in t if c.isalpha() or c == '?').lower())
D = {k: v for k, v in L.items() if int(k[:-1]) >= 29}
for k, v in D.items():
    print(k, len(v), sum(map(len, v)), [len(r) for r in v][:6], '...')
json.dump(D, open('data/loagaeth/diamonds.json', 'w'))
