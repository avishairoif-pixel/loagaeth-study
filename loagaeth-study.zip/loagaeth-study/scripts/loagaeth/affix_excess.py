"""Which individual affixes behave like morphemes? Free-stem counts per affix, real vs 20 controls."""
import io, contextlib
src = open('scripts/loagaeth/morphology.py').read(); head = src.split("print(f'Real lexicon:")[0]
ctrl = {'suffix': [], 'prefix': []}; real = {}
for seed in range(20):
    g = {}
    with contextlib.redirect_stdout(io.StringIO()): exec(head.replace('random.Random(42)', f'random.Random({seed})'), g)
    for side in ('suffix', 'prefix'):
        if seed == 0: real[side] = {a: (n, f) for a, n, f in g['affixes'](g['words'], side)}
        ctrl[side].append({a: f for a, n, f in g['affixes'](g['control'], side)})
for side in ('suffix', 'prefix'):
    rows = []
    for a, (n, f) in real[side].items():
        if f < 10: continue
        vals = [c.get(a, 0) for c in ctrl[side]]; mu = sum(vals) / 20; sd = max((sum((v - mu) ** 2 for v in vals) / 20) ** .5, 1)
        rows.append(((f - mu) / sd, a, f, mu))
    rows.sort(reverse=True)
    print(f'{side.upper()}ES with the strongest excess of free stems (z, real, control mean):')
    print('   ' + '   '.join(f"{'-' if side=='suffix' else ''}{a}{'-' if side=='prefix' else ''} z={z:+.1f} ({f} vs {mu:.0f})" for z, a, f, mu in rows[:12]))
    print('   behave like ordinary sound patterns (|z|<1): ' + ', '.join(a for z, a, f, mu in rows if abs(z) < 1))
