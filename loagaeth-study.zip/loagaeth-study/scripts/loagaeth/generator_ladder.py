"""SPECIFICITY OF THE H0 TEST (B28). Can generators without explicit semantics reach Loagaeth leaf 1's
order-information z (adjacent-word MI vs windowed word shuffles, w=10: z=11.1; w=20: 12.7; null_coherence.py)?
Ladder: G0 words i.i.d. from the unigram distribution; G1 recycling = with prob p copy a run of words
(mean length m, geometric) from the last B=300 output words, otherwise draw a word i.i.d. from the unigram.
Out-of-sample: lexicon and parameters are fitted on the FIRST half of leaf 1 only, on two targets that are
not the z itself (share of tokens inside a word bigram / word trigram already used in the previous 300 words);
the test statistic is computed on texts of the length of the SECOND half and compared with the second half.
Rule fixed before running: the H0 test is called non-specific if the median z of 20 G1 texts lies inside the
coherent-language range at the same length and the Loagaeth half lies inside the G1 range."""
import re, sys, math, random, statistics, glob
from collections import Counter
sys.path.insert(0, 'scripts/loagaeth')
exec(open('scripts/loagaeth/null_coherence.py').read().split('rng = random.Random(5)')[0])   # mi, burst, LOA, eng, lat, heb
def win_shuffle(seq, w, rng):
    out = []
    for i in range(0, len(seq), w): b = seq[i:i+w]; rng.shuffle(b); out += b
    return out
def zwin(seq, w, rng, k=40):
    m0 = mi(seq); ms = [mi(win_shuffle(seq[:], w, rng)) for _ in range(k)]
    return (m0 - statistics.mean(ms)) / statistics.pstdev(ms)
def zglob(seq, rng, k=40):
    m0 = mi(seq); ms = []
    for _ in range(k): s = seq[:]; rng.shuffle(s); ms.append(mi(s))
    return (m0 - statistics.mean(ms)) / statistics.pstdev(ms)
def repn(seq, n, back=300):
    cov = [0]*len(seq)
    for i in range(n, len(seq)-n+1):
        g = tuple(seq[i:i+n]); win = seq[max(0, i-back):i+n-1]
        if any(tuple(win[j:j+n]) == g for j in range(len(win)-n+1)):
            for t in range(i, i+n): cov[t] = 1
    return sum(cov)/len(seq)
H1, H2 = LOA[:len(LOA)//2], LOA[len(LOA)//2:]
uni = Counter(H1); W, P = list(uni), list(uni.values())
def G(n, p, m, rng, B=300):
    out = []
    while len(out) < n:
        if out and rng.random() < p:
            L = 1
            while rng.random() > 1/m: L += 1
            j = rng.randrange(max(0, len(out)-B), len(out)); out += out[j:j+L]
        else: out.append(rng.choices(W, P)[0])
    return out[:n]
rng = random.Random(11)
tgt = (repn(H1, 2), repn(H1, 3))
print(f'leaf 1: {len(LOA)} words, {len(set(LOA))} types; first half: {len(H1)} words, {len(uni)} types')
print(f'calibration targets on first half: bigram-reuse {tgt[0]:.3f}, trigram-reuse {tgt[1]:.3f}')
best = None
for p in (0.0, 0.02, 0.04, 0.06, 0.08, 0.10, 0.13, 0.16, 0.20, 0.25):
    for m in (1.5, 2, 3, 4, 6):
        s = [G(len(H1), p, m, rng) for _ in range(3)]
        v = (statistics.mean(repn(x, 2) for x in s), statistics.mean(repn(x, 3) for x in s))
        d = (v[0]-tgt[0])**2 + (v[1]-tgt[1])**2
        if best is None or d < best[0]: best = (d, p, m, v)
_, p, m, v = best
print(f'fitted G1: p={p}, m={m} -> bigram-reuse {v[0]:.3f}, trigram-reuse {v[1]:.3f}')
n = len(H2)
def summ(xs): return f'{statistics.median(xs):6.1f} [{min(xs):.1f}..{max(xs):.1f}]'
rows = {}
rows['Loagaeth leaf 1, second half'] = [H2]
rows['G0 i.i.d. words (20)'] = [G(n, 0.0, 2, rng) for _ in range(20)]
rows[f'G1 recycling p={p} m={m} (20)'] = [G(n, p, m, rng) for _ in range(20)]
for name, corp in (('English (Casaubon)', eng), ('Latin (Erasmus)', lat), ('Hebrew (Genesis)', heb)):
    rows[name + ' (10)'] = [corp[s:s+n] for s in (rng.randrange(0, len(corp)-n) for _ in range(10))]
print(f'\nsamples of {n} words. z = (MI - mean MI of shuffles) / SD, 40 shuffles each')
print(f'{"text":36s} {"windowed z w=10":>20s} {"w=20":>20s} {"global z":>20s} {"bigram-reuse":>13s}')
res = {}
for k, seqs in rows.items():
    a = [zwin(s, 10, rng) for s in seqs]; b = [zwin(s, 20, rng) for s in seqs]; c = [zglob(s, rng) for s in seqs]
    r = [repn(s, 2) for s in seqs]; res[k] = a
    print(f'{k:36s} {summ(a):>20s} {summ(b):>20s} {summ(c):>20s} {statistics.median(r):13.3f}')
coh = [z for k in res if '(10)' in k for z in res[k]]; g1 = res[[k for k in res if k.startswith('G1')][0]]; L = res['Loagaeth leaf 1, second half'][0]
ns = min(coh) <= statistics.median(g1) and min(g1) <= L <= max(g1)
print(f'\nDecision (w=10): G1 median {statistics.median(g1):.1f}, coherent min {min(coh):.1f}; Loagaeth {L:.1f} in G1 range {min(g1):.1f}..{max(g1):.1f}: '
      + ('H0 test NOT SPECIFIC: recycling without semantics reaches the language range' if ns else 'H0 test discriminates recycling from the coherent texts'))
