"""Which other letters are written/read in place of another in particular leaves? (generalising B38: u for a)
For every square leaf 2a-25a and every letter x:
  NOVEL = 4-letter sequences of this leaf that contain x and occur in NO other leaf (all rows, any length).
  For each other letter y, restore(y) = share of NOVEL occurrences that become a sequence attested elsewhere
  when x is replaced by y. A substitution candidate: >= 15 novel occurrences, best restore >= 60%,
  and best exceeds the second best by >= 10 points.
Also: letter-share shifts per leaf (percentage points vs the rest of the book), and the letter pairs Peterson names
as hard to tell apart in Kelley's hand (u/n, e/l, c/r, x/p, c/t)."""
import json, re
from collections import Counter, defaultdict
D = json.load(open('data/loagaeth/grids.json'))
def num(k): m = re.fullmatch(r'(\d+)([ab])', k); return int(m.group(1)) * 2 + (m.group(2) == 'b') if m else 999
ks = sorted([k for k in D['leaves'] if num('2a') <= num(k) <= num('25a')], key=num)
ROWS = {k: [r.replace('?', '') for r in D['leaves'][k]] for k in ks}
G = {k: Counter(r[i:i+4] for r in ROWS[k] for i in range(len(r) - 3)) for k in ks}
tot = Counter(); [tot.update(c) for c in G.values()]
AB = sorted(set(''.join(''.join(v) for v in ROWS.values())))
cands = []
for k in ks:
    other = tot - G[k]
    for x in AB:
        nov = {g: c for g, c in G[k].items() if x in g and other[g] == 0}
        n = sum(nov.values())
        if n < 15: continue
        rs = sorted(((sum(c for g, c in nov.items() if other[g.replace(x, y)] > 0) / n, y) for y in AB if y != x), reverse=True)
        (b, y1), (b2, y2) = rs[0], rs[1]
        if b >= 0.60 and b - b2 >= 0.10: cands.append((k, x, y1, n, b, y2, b2))
print('SUBSTITUTION CANDIDATES (leaf: x probably stands for y)')
for k, x, y, n, b, y2, b2 in cands: print(f'   {k:>4}: {x} -> {y}   novel occurrences {n:4d}, restored {100*b:5.1f}%  (next best {y2} {100*b2:4.1f}%)')
by = defaultdict(list); [by[(x, y)].append(k) for k, x, y, *_ in cands]
print('\nby letter pair:', '; '.join(f'{x}->{y}: {", ".join(v)}' for (x, y), v in sorted(by.items(), key=lambda z: -len(z[1]))))
# letter-share shifts
allt = ''.join(''.join(v) for v in ROWS.values()); g = Counter(allt); N = len(allt)
print('\nLEAVES WITH A LETTER SHIFTED BY >= 2.5 POINTS (vs the whole range):')
for k in ks:
    t = ''.join(ROWS[k]); c = Counter(t); n = len(t)
    sh = [(100 * (c[x] / n - g[x] / N), x) for x in AB]
    big = [f'{x} {d:+.1f}' for d, x in sorted(sh) if abs(d) >= 2.5]
    if big and n > 1000: print(f'   {k:>4}: {", ".join(big)}')
print("\nPETERSON'S HARD PAIRS: share of all 4-letter sequences containing x that are attested only in their y-version elsewhere")
for x, y in [('u', 'n'), ('n', 'u'), ('e', 'l'), ('l', 'e'), ('c', 'r'), ('r', 'c'), ('x', 'p'), ('p', 'x'), ('c', 't'), ('t', 'c'), ('u', 'v'), ('v', 'u')]:
    hits = defaultdict(int); tots = defaultdict(int)
    for k in ks:
        other = tot - G[k]
        for gr, c in G[k].items():
            if x in gr and other[gr] == 0:
                tots[k] += c
                if other[gr.replace(x, y)] > 0: hits[k] += c
    T, H = sum(tots.values()), sum(hits.values())
    top = sorted(((hits[k] / tots[k], k) for k in ks if tots[k] >= 10), reverse=True)[:3]
    print(f'   {x}->{y}: novel {T:5d}, restored {100*H/max(T,1):5.1f}%   highest leaves: ' + ', '.join(f'{k} {100*r:.0f}%' for r, k in top))
# the novel u-grams of 23a, e.g. dunt
other = tot - G['23a']
nov = [gr for gr in G['23a'] if 'u' in gr and other[gr] == 0]
print(f"\n23a: {len(nov)} novel u-sequences; with u read as a, {sum(other[gr.replace('u','a')] > 0 for gr in nov)} are attested elsewhere."
      f"  dunt -> dant: {other['dant']} times elsewhere")
