"""Leaf 7b image, part 2 (uses the grid fitted by leaf7b_image_register.py).
(a) per-row local refinement, then: do the image's letter shapes in rows 16-21 match Peterson's transcription?
    significance by a column-shift permutation null.
(b) y cells: extra ink at the TOP of the cell (a superscript e/t over y, as in ye/yt) in the block vs elsewhere?
(c) ruled lines: which row boundaries carry a long ruled line, and over which columns?"""
import sys, numpy as np, random
sys.argv = [sys.argv[0]]
sys.path.insert(0, 'scripts/loagaeth')
import leaf7b_image_register as R
x0, y0, dx, dy, rot = 6, 14, 14.8, 15.0, -0.006
page = R.page
def cell(r, c, oy=0, ox=0):
    cx = x0 + (c + .5) * dx + ox; cy = y0 + (r + .5) * dy + rot * (c - 24) * dx + oy
    ya, yb = int(round(cy - dy * .75)), int(round(cy + dy * .75)); xa, xb = int(round(cx - dx * .3)), int(round(cx + dx * .3))
    if ya < 0 or yb > page.shape[0] or xa < 0 or xb > page.shape[1]: return None
    return page[ya:yb, xa:xb]
def feats(r, oy=0, ox=0):
    T, M, B = [], [], []
    for c in range(49):
        b = cell(r, c, oy, ox)
        if b is None: T.append(np.nan); M.append(np.nan); B.append(np.nan); continue
        h = b.shape[0] // 3; T.append(b[:h].mean()); M.append(b[h:-h].mean()); B.append(b[-h:].mean())
    return np.array(T), np.array(M), np.array(B)
def rcorr(f, p):
    ok = ~np.isnan(f); return np.corrcoef(f[ok] - f[ok].mean(), p[ok])[0, 1]
P = {r: np.array([R.pred(ch) for ch in R.ROWS[r]]) for r in range(49) if len(R.ROWS[r]) == 49}
# (a) local refinement per row: best vertical/horizontal offset within +-4 px, chosen on the transcription itself
best = {}
for r in P:
    cand = []
    for oy in range(-4, 5):
        for ox in (-3, 0, 3):
            T, M, B = feats(r, oy, ox); cand.append((rcorr(T - B, P[r]), oy, ox))
    best[r] = max(cand)
def null(r, n=200):
    T, M, B = feats(r, best[r][1], best[r][2]); f = T - B; out = []
    for k in range(3, 46):                     # column-shifted transcription (shift >= 3, avoids near-alignment)
        out.append(rcorr(f, np.roll(P[r], k)))
    return out
print('row  fitted r   null (shifted) mean/max   letters')
blk, oth = [], []
for r in sorted(P):
    nl = null(r); rr = best[r][0]
    tag = ' <- block' if 15 <= r <= 20 else ''
    (blk if tag else oth).append(rr)
    print(f'{r+1:2d}   {rr:+.2f}     {np.mean(nl):+.2f} / {max(nl):+.2f}       {R.ROWS[r][:24]}{tag}')
print(f'\nmean fitted r: block rows {np.mean(blk):.3f} (n={len(blk)}), other rows {np.mean(oth):.3f} (n={len(oth)})')
print('note: fitting the offset on the row itself inflates every row equally; the shifted-null column shows the inflation level')
# (b) top ink of y cells
def top_rel(r, c):
    T, M, B = feats(r, best[r][1], best[r][2]); return (T[c] - np.nanmean(T)) if not np.isnan(T[c]) else np.nan
yb = [top_rel(r, c) for r in P if 15 <= r <= 20 for c in range(49) if R.ROWS[r][c] == 'y']
yo = [top_rel(r, c) for r in P if not 15 <= r <= 20 for c in range(49) if R.ROWS[r][c] == 'y']
xb = [top_rel(r, c) for r in P if 15 <= r <= 20 for c in range(49) if R.ROWS[r][c] in 'aceimnorsuvwxz']
print(f'\n(b) top-of-cell ink, relative to row mean: y in block {np.nanmean(yb):+.1f} (n={len(yb)}), y elsewhere {np.nanmean(yo):+.1f} (n={len(yo)}), x-height letters in block {np.nanmean(xb):+.1f}')
# (c) ruled lines along row boundaries
print('\n(c) row boundaries: darkness along the boundary line, by column (# = ruled, darker than the page median boundary by 1.5 sd)')
bd = np.zeros((50, 49))
for r in range(50):
    for c in range(49):
        cx = x0 + (c + .5) * dx; cy = y0 + r * dy + rot * (c - 24) * dx
        ya, xa = int(round(cy)), int(round(cx - dx / 2))
        if 1 <= ya < page.shape[0] - 2: bd[r, c] = page[ya - 1:ya + 2, xa:xa + int(dx)].max(0).mean()
med, sd = np.median(bd[1:49]), bd[1:49].std()
for r in range(50):
    s = ''.join('#' if v > med + 1.5 * sd else '.' for v in bd[r])
    print(f'above row {r+1:2d}: {s}  ({s.count("#")})')
