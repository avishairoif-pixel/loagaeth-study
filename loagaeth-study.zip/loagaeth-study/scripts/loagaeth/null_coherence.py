"""NULL HYPOTHESIS TEST: H0 = the running text of Loagaeth (leaf 1, written as words) is coherent language.
Coherent language has two properties that do not depend on knowing the language:
  (1) word ORDER carries information: the next word depends on the previous one (syntax), so adjacent-word
      mutual information drops when the same words are shuffled;
  (2) TOPICALITY: content words cluster where their subject is discussed (burstiness), so their counts vary
      between parts of the text more than in a shuffled text.
Reference: coherent texts in three languages and three registers (English prose: Casaubon 1659; Latin prose:
Erasmus; Hebrew narrative: Genesis, WLC), 10 samples each of the same length as Loagaeth leaf 1.
Gibberish reference: (a) Loagaeth's own words in random order; (b) i.i.d. pseudo-words from a letter-trigram model.
Decision rule fixed in advance: H0 is rejected if Loagaeth's order-information excess (z vs its own shuffles)
lies below the lowest of the 30 coherent samples AND within the range of the gibberish references.
Run from project root."""
import re, sys, math, random, glob, html, unicodedata, statistics
from collections import Counter
sys.path.insert(0, 'scripts/loagaeth')
exec(open('scripts/loagaeth/lexicon.py').read().split('# (B)')[0])          # -> leaf1 (ordered word list)
LOA = leaf1
N = len(LOA)
import leaf7b_transposition as T
eng = re.findall(r'[a-z]+', T._raw.lower())
lat = re.findall(r'[a-z]+', ' '.join(open(f, errors='replace').read() for f in sorted(glob.glob('/home/claude/dl_latin/ll/erasmus/*.txt'))).lower())
heb_raw = open('/home/claude/dl_latin/Gen.xml', encoding='utf-8').read()
heb = []
for w in re.findall(r'<w [^>]*>([^<]+)</w>', heb_raw):
    w = ''.join(c for c in unicodedata.normalize('NFD', w) if 'א' <= c <= 'ת')
    if w: heb.append(w)
def mi(seq):
    n = len(seq) - 1; uni = Counter(seq); bi = Counter(zip(seq, seq[1:])); M = len(seq)
    return sum(c / n * math.log2((c / n) / ((uni[a] / M) * (uni[b] / M))) for (a, b), c in bi.items())
def burst(seq, blocks=10, minc=5):
    c = Counter(seq); words = [w for w, k in c.items() if k >= minc]
    if not words: return float('nan')
    L = len(seq) // blocks; vals = []
    for w in words:
        cnt = [seq[i*L:(i+1)*L].count(w) for i in range(blocks)]; m = sum(cnt) / blocks
        vals.append(statistics.pvariance(cnt) / m if m else 0)
    return statistics.mean(vals)
def zscores(seq, rng, k=60):
    m0, b0 = mi(seq), burst(seq); ms, bs = [], []
    for _ in range(k):
        s = seq[:]; rng.shuffle(s); ms.append(mi(s)); bs.append(burst(s))
    zm = (m0 - statistics.mean(ms)) / statistics.pstdev(ms)
    zb = (b0 - statistics.mean(bs)) / statistics.pstdev(bs)
    return zm, zb, m0 - statistics.mean(ms), b0
rng = random.Random(5)
res = {}
res['Loagaeth leaf 1'] = [zscores(LOA, rng)]
for name, corp in (('English (Casaubon)', eng), ('Latin (Erasmus)', lat), ('Hebrew (Genesis)', heb)):
    starts = [rng.randrange(0, len(corp) - N) for _ in range(10)]
    res[name] = [zscores(corp[s:s+N], rng) for s in starts]
# gibberish references
sh = LOA[:]; rng.shuffle(sh); res['gibberish: Loagaeth words shuffled'] = [zscores(sh, rng)]
txt = ' ' + ' '.join(LOA) + ' '; tri = Counter(txt[i:i+3] for i in range(len(txt) - 2)); bi2 = Counter(txt[i:i+2] for i in range(len(txt) - 1))
def gen_word():
    s = ' '
    while True:
        if len(s) == 1: opts = [(t[1], c) for t, c in bi2.items() if t[0] == ' ' and t[1] != ' ']
        else: opts = [(t[2], c) for t, c in tri.items() if t[:2] == s[-2:]]
        ch = rng.choices([o for o, _ in opts], [c for _, c in opts])[0]
        if ch == ' ':
            if len(s) > 1: return s[1:]
            continue
        s += ch
        if len(s) > 15: return s[1:]
res['gibberish: trigram pseudo-words'] = [zscores([gen_word() for _ in range(N)], rng) for _ in range(3)]
print(f'sample length: {N} words (Loagaeth leaf 1)\n')
print(f'{"text":38s} {"order info z":>14s} {"excess MI (bits)":>17s} {"burstiness z":>13s}')
for k, v in res.items():
    zm = [x[0] for x in v]; zb = [x[1] for x in v]; ex = [x[2] for x in v]
    rngs = (lambda a: f'{min(a):6.1f}..{max(a):5.1f}' if len(a) > 1 else f'{a[0]:6.1f}')
    print(f'{k:38s} {rngs(zm):>14s} {rngs(ex):>17s} {rngs(zb):>13s}')
coh = [x[0] for k in ('English (Casaubon)', 'Latin (Erasmus)', 'Hebrew (Genesis)') for x in res[k]]
gib = [x[0] for k in res if k.startswith('gibberish') for x in res[k]]
z = res['Loagaeth leaf 1'][0][0]
print(f'\nDecision: Loagaeth order-info z = {z:.1f}; coherent samples min {min(coh):.1f}; gibberish range {min(gib):.1f}..{max(gib):.1f}')
print('H0 (coherent language) REJECTED' if z < min(coh) and min(gib) - 1 <= z <= max(gib) + 1 else 'H0 NOT rejected by the pre-set rule')

# ---------------------------------------------------------------------------------------------
# CONFOUND CHECK. A global shuffle also destroys LOCAL vocabulary reuse (episodes: the same few words
# recurring in one stretch), which raises adjacent-word MI and burstiness without any syntax.
# Stricter null: shuffle words only inside windows of w words (local vocabulary kept, order destroyed).
# Positive control for the confound: 'episodic gibberish' = every 20-word stretch draws i.i.d. from 8 words
# picked from Loagaeth's lexicon. Same decision rule, applied to the windowed test.
print('\n=== windowed shuffles (order destroyed, local vocabulary kept) ===')
def win_shuffle(seq, w, rng):
    out = []
    for i in range(0, len(seq), w):
        b = seq[i:i+w]; rng.shuffle(b); out += b
    return out
def zwin(seq, w, rng, k=60):
    m0 = mi(seq); ms = [mi(win_shuffle(seq[:], w, rng)) for _ in range(k)]
    return (m0 - statistics.mean(ms)) / statistics.pstdev(ms)
lexicon_words = list(Counter(LOA))
def episodic():
    out = []
    while len(out) < N:
        voc = rng.sample(lexicon_words, 8); out += [rng.choice(voc) for _ in range(20)]
    return out[:N]
texts = {'Loagaeth leaf 1': [LOA]}
for name, corp in (('English (Casaubon)', eng), ('Latin (Erasmus)', lat), ('Hebrew (Genesis)', heb)):
    texts[name] = [corp[s:s+N] for s in (rng.randrange(0, len(corp) - N) for _ in range(10))]
texts['gibberish: episodic (8 words / 20)'] = [episodic() for _ in range(3)]
texts['gibberish: trigram pseudo-words'] = [[gen_word() for _ in range(N)] for _ in range(2)]
gz = {}
for w in (10, 20):
    print(f'\nwindow = {w} words')
    for k, seqs in texts.items():
        zs = [zwin(s, w, rng) for s in seqs]; gz[(k, w)] = zs
        print(f'  {k:38s} order-info z {min(zs):6.1f}..{max(zs):6.1f}' if len(zs) > 1 else f'  {k:38s} order-info z {zs[0]:6.1f}')
    coh = [z for k in ('English (Casaubon)', 'Latin (Erasmus)', 'Hebrew (Genesis)') for z in gz[(k, w)]]
    gib = [z for k in texts if k.startswith('gibberish') for z in gz[(k, w)]]
    z = gz[('Loagaeth leaf 1', w)][0]
    verdict = 'H0 (coherent language) REJECTED' if z < min(coh) and min(gib) - 1 <= z <= max(gib) + 1 else 'H0 NOT rejected'
    print(f'  decision (w={w}): Loagaeth z={z:.1f}; coherent min {min(coh):.1f}; gibberish {min(gib):.1f}..{max(gib):.1f} -> {verdict}')
# global-shuffle z for the episodic control, to show the confound
print('\nglobal-shuffle order-info z of episodic gibberish:', [round(zscores(s, rng, 30)[0], 1) for s in texts['gibberish: episodic (8 words / 20)']])
