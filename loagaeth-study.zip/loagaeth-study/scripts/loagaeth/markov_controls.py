"""CONTROL for B50: the same protocol on real languages. A contiguous passage of Latin (Erasmus) and of English
(Casaubon 1659, Dee's own diary in print) is stripped of spaces and cut into pseudo-tables with EXACTLY the row
counts of the 45 Loagaeth sides (49 letters per row, no '?'). Then identical steps: 27/9/9 chronological split,
Markov order and alpha chosen by dev bits/letter, cache lam and memory chosen by dev bits/letter, 200 synthetic
test blocks per generator, same five measures, same repeat-distance map. Question: does real language exceed
the two generators in the same way as Loagaeth (excess concentrated at short distance, long copied segments)?"""
import sys, re, glob
sys.path.insert(0, 'scripts/loagaeth')
NS = {}
src_m = open('scripts/loagaeth/markov_tables.py').read().split('rng = np.random.default_rng(1583)')[0]
src_c = open('scripts/loagaeth/markov_cache_tables.py').read()
cache_defs = src_c.split("exec(open('scripts/loagaeth/markov_tables.py').read().split('rng = np.random.default_rng(1583)')[0])")[1].split('K0, A0 = 3, 10.0')[0]
gen_block_src = 'def gen_block' + src_c.split('def gen_block')[1].split('rng = np.random.default_rng(1584)')[0]
dm = open('scripts/loagaeth/repeat_distance_map.py').read()
dm_defs = 'def stream' + dm.split('def stream')[1].split('rng = np.random.default_rng(7)')[0]
exec(src_m, NS); exec(cache_defs, NS); exec(dm_defs, NS)
import leaf7b_transposition as T
texts = {'Latin (Erasmus)': re.sub(r'[^a-z]', '', ' '.join(open(f, errors='replace').read() for f in sorted(glob.glob('/home/claude/dl_latin/ll/erasmus/*.txt'))).lower())[5000:],
         'English (Casaubon)': re.sub(r'[^a-z]', '', T._raw.lower())[5000:]}
np = NS['np']; pages = NS['pages']; nrows = {p: len(NS['rows'][p]) for p in pages}
def report(title, real, sims):
    print(f'\n--- {title} (200 synthetic sets) ---')
    print(f'{"measure":7s} {"real":>9s} {"synthetic median":>17s} {"2.5-97.5%":>22s} {"p":>7s} {">=real":>7s} {"<=real":>7s}')
    for m in real:
        v = np.array([s[m] for s in sims]); b = min((v >= real[m]).sum(), (v <= real[m]).sum()); p = min(1.0, 2*(b+1)/201)
        print(f'{m:7s} {real[m]:9.4f} {np.median(v):17.4f} {np.percentile(v, 2.5):10.4f}..{np.percentile(v, 97.5):9.4f} {p:7.4f} {int((v >= real[m]).sum()):7d} {int((v <= real[m]).sum()):7d}')
for name, t in texts.items():
    pos = 0; R = {}
    for p in pages:
        R[p] = [t[pos + 49*i: pos + 49*(i+1)] for i in range(nrows[p])]; pos += 49*nrows[p]
    NS['rows'] = R; NS['REG'] = set()
    TR, DEV, TE = NS['TR'], NS['DEV'], NS['TE']
    trR = [r for p in TR for r in R[p]]; dvR = [r for p in DEV for r in R[p]]; NS['trR'] = trR; NS['dvR'] = dvR
    CM = NS['CM']
    cands = sorted((CM(k, a).fit(trR).bits(dvR), k, a) for k in (0, 1, 2, 3) for a in (0.1, 1.0, 10.0))
    _, K, A = cands[0]; NS['K0'], NS['A0'] = K, A
    grid = sorted((NS['dev_bits'](l, B), l, B) for l in (0.0, 0.1, 0.2, 0.3, 0.5) for B in (1000, 3000, 8000))
    _, LAM, BB = grid[0]; NS['LAM'], NS['BB'] = LAM, BB
    M = CM(K, A).fit(trR + dvR); NS['M'] = M; NS['seed'] = ''.join(NS['side_text'](R[p]) for p in DEV)
    exec(gen_block_src, NS)
    print(f'\n================ {name}: {pos} letters; Markov order {K}, alpha {A} (dev {cands[0][0]:.3f} bits); cache lam {LAM}, memory {BB} (dev {grid[0][0]:.3f}) ================')
    rng = np.random.default_rng(2001)
    real_sides = [R[p] for p in TE]; real = NS['battery'](real_sides, rng)
    report('G-M Markov', real, [NS['battery']([[M.gen(r, rng) for r in S] for S in real_sides], rng) for _ in range(200)])
    report('G-C Markov + cache', real, [NS['battery'](NS['gen_block'](real_sides, rng), rng) for _ in range(200)])
    pr = NS['profile'](real_sides); pc = [NS['profile'](NS['gen_block'](real_sides, rng)) for _ in range(50)]
    print('repeated 6-grams per 1000 letters by distance (real / G-C median, ratio):')
    for b, (nm, _) in enumerate(NS['BINS']):
        vc = np.median([x[0][b] for x in pc]); print(f'  {nm:28s} {pr[0][b]:7.1f} / {vc:6.1f}   x{pr[0][b]/vc:.2f}')
    print('maximal repeated segments by length (real / G-C median):', [(lab, NS['seglen'](pr[1])[k], float(np.median([NS['seglen'](x[1])[k] for x in pc]))) for k, lab in enumerate(('6-7', '8-10', '11-15', '16+'))])
