"""Is the change between the two halves of Loagaeth leaf 1 unusual? Same measures on the two halves of
10 random samples (same length) of Latin, English and Hebrew; and leaf 1 in quarters."""
import sys, random, statistics
sys.path.insert(0, 'scripts/loagaeth')
exec(open('scripts/loagaeth/generator_joint.py').read().split('rng = random.Random(31)')[0])
rng = random.Random(61); N = len(LOA)
def two(ws): A, B = ws[:N//2], ws[N//2:]; return [zwin(A,10,rng), zwin(B,10,rng), zglob(A,rng), zglob(B,rng), len(set(A))/len(A), len(set(B))/len(B)]
print(f'{"text":22s} {"window z 1st->2nd":>20s} {"global z 1st->2nd":>20s} {"type/tok 1st->2nd":>20s}')
r = two(LOA); print(f'{"Loagaeth leaf 1":22s} {r[0]:8.1f} -> {r[1]:5.1f}      {r[2]:8.1f} -> {r[3]:5.1f}      {r[4]:8.2f} -> {r[5]:5.2f}')
for name, corp in (('Latin', lat), ('English', eng), ('Hebrew', heb)):
    R = [two(corp[s:s+N]) for s in (rng.randrange(0, len(corp)-N) for _ in range(10))]
    ratio = [x[3]/x[2] for x in R]; dz = [x[1]-x[0] for x in R]; dt = [x[5]-x[4] for x in R]
    print(f'{name:22s} window z 1st half {min(x[0] for x in R):.1f}..{max(x[0] for x in R):.1f}; change {min(dz):+.1f}..{max(dz):+.1f}; '
          f'global z ratio 2nd/1st {min(ratio):.2f}..{max(ratio):.2f}; type/tok change {min(dt):+.2f}..{max(dt):+.2f}')
print(f'Loagaeth: window z change {r[1]-r[0]:+.1f}; global z ratio {r[3]/r[2]:.2f}; type/tok change {r[5]-r[4]:+.2f}')
q = N//4
print('Loagaeth leaf 1 in quarters, window z (w=10):', [round(zwin(LOA[i*q:(i+1)*q], 10, rng), 1) for i in range(4)],
      ' type/tok:', [round(len(set(LOA[i*q:(i+1)*q]))/q, 2) for i in range(4)])
