"""Transition structure across Markov orders. For order k = 0..5: held-out cross-entropy (bits/letter) of an
interpolated character model (CM from markov_tables.py, alpha chosen per k on dev) trained on the first 27 sides,
evaluated on the last 9 (test). A noise sequence gains nothing from longer context (flat curve); structured
text keeps gaining. Texts in the same format (45 pseudo-sides, Loagaeth row counts, 49 letters per row):
Loagaeth tables; Latin (Erasmus); English (Casaubon); Loagaeth letters shuffled (noise with the same letter
frequencies); Loagaeth rows shuffled within each row (local order destroyed, row composition kept)."""
import sys, re, glob, random
sys.path.insert(0, 'scripts/loagaeth')
exec(open('scripts/loagaeth/markov_tables.py').read().split('rng = np.random.default_rng(1583)')[0])
import leaf7b_transposition as T
L0 = rows
def cut(t):
    pos = 0; R = {}
    for p in pages:
        R[p] = [t[pos+49*i: pos+49*(i+1)] for i in range(len(L0[p]))]; pos += 49*len(L0[p])
    return R
loa = ''.join(side_text(L0[p]) for p in pages); rnd = random.Random(5)
sh = list(loa); rnd.shuffle(sh)
def rowshuf(R): return {p: [''.join(rnd.sample(r, len(r))) for r in v] for p, v in R.items()}
lat = re.sub(r'[^a-z]', '', ' '.join(open(f, errors='replace').read() for f in sorted(glob.glob('/home/claude/dl_latin/ll/erasmus/*.txt'))).lower())[5000:]
eng = re.sub(r'[^a-z]', '', T._raw.lower())[5000:]
LU = {p: [(r.replace('u', 'a') if p in REG else r) for r in v] for p, v in L0.items()}
corp = {'Loagaeth tables': L0, 'Loagaeth tables, u restored to a': LU, 'Latin (Erasmus)': cut(lat), 'English (Casaubon)': cut(eng),
        'noise: Loagaeth letters shuffled': cut(''.join(sh)), 'Loagaeth, letters shuffled within each row': rowshuf(L0)}
print(f'{"text":44s} ' + ' '.join(f'{"k="+str(k):>6s}' for k in range(6)) + '   gain k0->k3   gain k3->k5')
for name, R in corp.items():
    tr = [r for p in TR for r in R[p]]; dv = [r for p in DEV for r in R[p]]; te = [r for p in TE for r in R[p]]
    H = []
    for k in range(6):
        a = min((CM(k, a).fit(tr).bits(dv), a) for a in (0.1, 1.0, 10.0))[1]
        H.append(CM(k, a).fit(tr + dv).bits(te))
    print(f'{name:44s} ' + ' '.join(f'{h:6.3f}' for h in H) + f'   {H[0]-H[3]:10.3f}   {H[3]-H[5]:11.3f}')
