"""Robustness for markov_orders.py: is the drop after k=3 a drift effect of the chronological split?
Same models, sides assigned to train/dev/test at random (27/9/9), 3 random splits per text."""
import sys, random
sys.path.insert(0, 'scripts/loagaeth')
src = open('scripts/loagaeth/markov_orders.py').read()
exec(src.split("print(f'{\"text\":44s}")[0])
keep = ['Loagaeth tables, u restored to a', 'Latin (Erasmus)', 'English (Casaubon)']
print(f'{"text (random split)":36s} {"seed":>4s} ' + ' '.join(f'{"k="+str(k):>6s}' for k in range(6)) + '   best k')
for name in keep:
    R = corp[name]
    for sd in (1, 2, 3):
        ps = pages[:]; random.Random(sd).shuffle(ps); tr_, dv_, te_ = ps[:27], ps[27:36], ps[36:]
        tr = [r for p in tr_ for r in R[p]]; dv = [r for p in dv_ for r in R[p]]; te = [r for p in te_ for r in R[p]]
        H = []
        for k in range(6):
            a = min((CM(k, a).fit(tr).bits(dv), a) for a in (0.1, 1.0, 10.0))[1]; H.append(CM(k, a).fit(tr + dv).bits(te))
        print(f'{name:36s} {sd:4d} ' + ' '.join(f'{h:6.3f}' for h in H) + f'   {H.index(min(H))}')
