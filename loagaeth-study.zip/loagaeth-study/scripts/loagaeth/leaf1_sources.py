"""Leaf 1 = two sources produced by different methods (Peterson's notes): 1a from Sl. 3188, letters named one
by one by Kelley and written by Dee; 1b ('Oxar varmol ...') from Sl. 3189, written by Kelley himself on 6 April.
Is the within-leaf rise in word-order structure a drift in production, or a change of source/method?
Window z (w=10) on equal-length pieces, compared with equal-length samples of Latin, English, Hebrew."""
import sys, random, statistics
sys.path.insert(0, 'scripts/loagaeth')
exec(open('scripts/loagaeth/generator_joint.py').read().split('rng = random.Random(31)')[0])
rng = random.Random(71)
b = LOA.index('oxar'); A1, B1 = LOA[:b], LOA[b:]
print(f'1a (Sl. 3188): {len(A1)} words; 1b (Sl. 3189): {len(B1)} words; first words of 1b: {" ".join(B1[:8])}')
n = len(B1)
pieces = {'1a, first third': A1[:n], '1a, middle third': A1[len(A1)//2 - n//2: len(A1)//2 + n - n//2], '1a, last third': A1[-n:], '1b (Kelley, 6 Apr)': B1}
print(f'\npieces of {n} words; window z (w=10), global z, type/token')
for k, s in pieces.items(): print(f'  {k:22s} {zwin(s,10,rng):6.1f} {zglob(s,rng):6.1f} {len(set(s))/len(s):6.2f}')
for name, corp in (('Latin', lat), ('English', eng), ('Hebrew', heb)):
    z = [zwin(corp[s:s+n], 10, rng) for s in (rng.randrange(0, len(corp)-n) for _ in range(15))]
    print(f'  {name:22s} window z {min(z):.1f}..{max(z):.1f} (15 samples)')
