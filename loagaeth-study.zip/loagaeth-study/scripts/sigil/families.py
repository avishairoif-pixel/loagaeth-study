"""
Reconstruct Dee's four families of angel names from the 7x7 table of the Sigillum Dei Aemeth.
Hypothesis tested: each family = the 7 diagonals of lengths 1..7 cut from one corner of the table.
Cells may hold more than one letter (a letter plus a numeral read as a letter).
"""
BASE = [list("SAAIEME"), list("BTZKASE"), list("HEIDENE"), list("DEIMO#A"),
        list("IMEGCBE"), list("ILAOIVN"), list("IHRLAAP")]

FAMILIES = {
 "Filiae Bonitatis (upper-right, down-right)": ["E","ME","ESE","IANA","AKELE","AZDOBN","STIMCUL"],
 "Filii Lucis (lower-left, down-right)":       ["I","IH","ILR","DMAL","HEEOA","BEIGIA","STIMCUL"],
 "Filiae Filiarum (upper-left, down-left)":    ["S","AB","ATH","IZED","EKIEI","MADIMI","ESEMELI"],
 "Filii Filiorum (lower-right, up-right)":     ["E","AN","AUE","LIBA","ROCLE","HAGONEL","ILEMESE"],
}

def diag_cells():
    up_right   = [[(i, 7 - L + i) for i in range(L)] for L in range(1, 8)]          # from top row, down-right
    low_left   = [[(7 - L + i, i) for i in range(L)] for L in range(1, 8)]          # from left col, down-right
    up_left    = [[(i, L - 1 - i) for i in range(L)] for L in range(1, 8)]          # from top row, down-left
    low_right  = [[(6 - i, 7 - L + i) for i in range(L)] for L in range(1, 8)]      # from bottom row, up-right
    return dict(zip(FAMILIES, [up_right, low_left, up_left, low_right]))

def match(cellstr_list, name):
    """cells may hold several candidate letters; a multi-letter cell 'EL' may contribute 'E','L' or 'EL'."""
    def rec(i, pos):
        if i == len(cellstr_list): return pos == len(name)
        for opt in cellstr_list[i]:
            if name.startswith(opt, pos) and rec(i + 1, pos + len(opt)): return True
        return False
    return rec(0, 0)

def evaluate(table, label):
    print(f"\n=== {label}")
    D = diag_cells(); ok = 0
    for fam, names in FAMILIES.items():
        for path, name in zip(D[fam], names):
            opts = [table[r][c] for r, c in path]
            m = match(opts, name); ok += m
            shown = "".join("/".join(o) if len(o) > 1 else o[0] for o in opts)
            if not m: print(f"  MISS {fam[:16]:16} {name:8} cells read: {shown}  at {path}")
    print(f"  {ok} of 28 names reproduced")

def T(mods):
    t = [[[ch] for ch in row] for row in BASE]
    for (r, c), v in mods.items(): t[r][c] = v
    return t

evaluate(T({}), "Transcription as read from the image (# = numeral)")
evaluate(T({(3,5): ["L"]}), "Numeral 30 read as L (Hebrew lamed = 30)")
evaluate(T({(3,5): ["L"], (1,6): ["E", "EL"]}), "+ cell (1,6) E carries a 30 (E or EL)")
evaluate(T({(3,5): ["L"], (1,6): ["E", "EL"], (6,6): ["E", "L"]}), "+ cell (6,6) read as E with L, not P")

# Final model, confirmed against Whitby's redrawing of Sloane MS 3188 fol. 30a and the British Museum wax seal:
# V=U; the numeral 30 in DEIMO30A reads L; BTZKASE carries a 30 over its final E (E or EL);
# the last cell of IHRLAA is the numeral 21/8 (read L in Stimcul, El in the Filii Filiorum), not P.
evaluate(T({(5,5):['V','U'],(3,5):['L'],(1,6):['E','EL'],(6,6):['E','L']}), 'FINAL MODEL (confirmed in manuscript and wax)')
