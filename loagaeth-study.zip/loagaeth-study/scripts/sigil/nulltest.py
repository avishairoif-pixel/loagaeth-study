"""
Null-model test for the needle hypothesis on the Sigillum Dei Aemeth.
Lexicon fixed in advance: angel names that Dee derived from this table and wrote inside the seal
(length >= 3). Statistic: number of distinct lexicon names found as a contiguous window
(forward, backward, or as an anagram of the window) in a set of readings.
Null: the 49 cells of the table are shuffled at random (letter frequencies preserved), 20,000 times.
"""
import math, random
from collections import Counter
from needle import ray_hit, N

TABLE = ["SAAIEME", "BTZKASE", "HEIDENE", "DEIMO#A", "IMEGCBE", "ILAOIVN", "IHRLAAP"]
LEX = ["ESE","IANA","AKELE","AZDOBN","STIMCUL","ILR","DMAL","HEEOA","BEIGIA","AUE","LIBA",
       "ROCLE","HAGONEL","ILEMESE","ATH","IZED","EKIEI","MADIMI","ESEMELI"]

# precompute needle geometry once (cell coordinates per anchor and direction)
def needle_cells():
    paths = []
    for direction in (-1, 1):
        for k in range(N):
            base = 90 - 360 * k / N
            cells = []
            for j in range(1, 10):
                s, t = ray_hit(base + direction * 36 * j)
                cells.append((s, min(int(t * 7), 6)))
            paths.append(cells)
    opp = [(s, 3) for s in range(N)]
    return paths, [opp]

NEEDLE, OPP = needle_cells()
CONTROL = ([[(r, c) for c in range(7)] for r in range(7)] +                 # rows
           [[(r, c) for r in range(7)] for c in range(7)] +                 # columns
           [[(i, (i + d) % 7) for i in range(7)] for d in range(7)] +       # diagonals (wrapped)
           [[(i, (d - i) % 7) for i in range(7)] for d in range(7)])        # anti-diagonals

def strings(table, paths):
    return ["".join(table[s][c] for s, c in p) for p in paths]

def stat(strs):
    found = set()
    for s in strs:
        for w in LEX:
            L = len(w); cw = Counter(w)
            for i in range(len(s) - L + 1):
                win = s[i:i + L]
                if win == w or win[::-1] == w or Counter(win) == cw:
                    found.add(w); break
    return found

def run(name, paths, table, trials=20000, seed=1):
    obs = stat(strings(table, paths))
    cells = [ch for row in table for ch in row]
    rng = random.Random(seed); ge = 0
    for _ in range(trials):
        rng.shuffle(cells)
        t = ["".join(cells[i*7:(i+1)*7]) for i in range(7)]
        if len(stat(strings(t, paths))) >= len(obs):
            ge += 1
    print(f"{name}: observed {len(obs)} {sorted(obs)} | p = {(ge+1)/(trials+1):.4f}")

if __name__ == "__main__":
    run("Needle (both directions, 14 readings)", NEEDLE, TABLE)
    run("Opposite pole (middle column)", OPP, TABLE)
    run("Control: rows, columns, diagonals", CONTROL, TABLE)
