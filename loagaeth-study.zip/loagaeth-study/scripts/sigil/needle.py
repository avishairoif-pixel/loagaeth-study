"""
Needle decoding of the Sigillum Dei Aemeth (Dee, Sloane MS 3188).
Two pentagrams (one upright, one reversed) = 10 rays at 36 deg intervals.
One ray (the needle) is anchored at a vertex of the outer heptagon.
Each other ray is extended to the heptagon perimeter, and the letter cell it hits is read.
Heptagon: vertex 0 at top, sides numbered clockwise, each side holds one 7-cell name
(transcription from the image; cells marked # hold numbers in the manuscript).
"""
import math

NAMES = ["SAAIEME", "BTZKASE", "HEIDENE", "DEIMO#A", "IMEGCBE", "ILAOIVN", "IHRLAAP"]
N = 7

def vert(k):
    a = math.radians(90 - 360 * k / N)
    return (math.cos(a), math.sin(a))

def ray_hit(theta_deg):
    """Return (side, cell, t) where the ray from the centre at compass-free angle hits the perimeter."""
    d = (math.cos(math.radians(theta_deg)), math.sin(math.radians(theta_deg)))
    for s in range(N):
        p, q = vert(s), vert((s + 1) % N)
        e = (q[0] - p[0], q[1] - p[1])
        den = d[0] * (-e[1]) - d[1] * (-e[0])
        if abs(den) < 1e-12:
            continue
        # solve r*d = p + t*e
        r = (p[0] * (-e[1]) - p[1] * (-e[0])) / den
        t = (d[0] * p[1] - d[1] * p[0]) / den
        if r > 0 and -1e-9 <= t <= 1 + 1e-9:
            return s, t
    raise RuntimeError

def read(anchor_vertex, direction=-1):
    """direction -1 = rays stepped clockwise from the needle."""
    base = 90 - 360 * anchor_vertex / N
    out = []
    for j in range(10):
        th = base + direction * 36 * j
        s, t = ray_hit(th)
        if t < 1e-6 or t > 1 - 1e-6:
            out.append(("*", s, None, round(t, 3)))
            continue
        cell = min(int(t * 7), 6)
        out.append((NAMES[s][cell], s, cell, round(t, 3)))
    return out

if __name__ == "__main__":
    for k in range(N):
        r = read(k)
        letters = "".join(x[0] for x in r)
        detail = " ".join(f"{x[0]}(s{x[1]},c{x[2]},t={x[3]})" for x in r)
        print(f"needle at vertex {k}: {letters}")
        print("   ", detail)
