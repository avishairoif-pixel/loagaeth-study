"""
Outer ring of the Sigillum Dei Aemeth, 40 cells clockwise from the top (the T).
Read from Whitby's redrawing of Sloane MS 3188 fol. 30a.
(letter, number, pos): pos '+' = number over letter (move clockwise), '-' = under (anticlockwise), None = end.
"""
RING = [("T",4,"+"),("G",9,"+"),("n",7,"+"),("t",9,"-"),("h",22,"+"),("n",None,None),("m",6,"+"),
        ("o",22,"+"),("a",20,"+"),("n",14,"+"),("a",6,"+"),("h",None,None),("o",18,"+"),("l",26,"+"),
        ("l",30,"-"),("n",None,None),("l",8,"-"),("G",7,"+"),("r",13,"+"),("H",12,"-"),
        ("og",None,None),("y",14,"-"),("t",11,"-"),("o",8,"-"),("e",21,"-"),("b",10,"+"),("A",11,"+"),
        ("I",15,"+"),("a",8,"+"),("r",16,"-"),("n",None,None),("A",6,"+"),("o",10,"-"),("G",5,"+"),
        ("h",14,"-"),("o",17,"-"),("s",None,None),("a",5,"-"),("a",24,"-"),("w",6,"+")]
assert len(RING) == 40

def chain(start, cap=20):
    i, out, path = start, "", [start + 1]
    for _ in range(cap):
        L, n, p = RING[i]
        out += L
        if n is None: return out, path
        i = (i + n) % 40 if p == "+" else (i - n) % 40
        path.append(i + 1)
    return out + "...", path

if __name__ == "__main__":
    for i, (L, n, p) in enumerate(RING):
        if L[0].isupper():
            name, path = chain(i)
            print(f"start cell {i+1:2} {L}: {name:12} cells {path}")
